<?php
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/card.php';

$slug = is_string($_GET['slug'] ?? '') ? ($_GET['slug'] ?? '') : '';
$p = q('SELECT p.*, c.icon, c.name AS cat_name, c.slug AS cat_slug FROM products p JOIN categories c ON c.id = p.category_id
        WHERE p.slug = ? AND p.is_active = 1', [$slug])->fetch();
if ($p) {
    $_SESSION['recently_viewed'] = array_values(array_unique(array_merge([(int)$p['id']], $_SESSION['recently_viewed'] ?? [])));
    $_SESSION['recently_viewed'] = array_slice($_SESSION['recently_viewed'], 0, 12);
}
if (!$p) {
    http_response_code(404);
    $title = 'Product not found';
    require __DIR__ . '/includes/header.php';
    echo '<div class="empty"><h1>Product not found</h1><p>It may have been removed.</p><a class="btn" href="' . e(url('products.php')) . '">Back to shop</a></div>';
    require __DIR__ . '/includes/footer.php';
    exit;
}
$related = q('SELECT p.*, c.icon FROM products p JOIN categories c ON c.id = p.category_id
              WHERE p.category_id = ? AND p.id <> ? AND p.is_active = 1 ORDER BY p.is_featured DESC LIMIT 4', [$p['category_id'], $p['id']])->fetchAll();
$title = $p['name'];
$desc = mb_substr($p['description'], 0, 150);
$off = discount_pct($p);
$here = 'product.php';
require __DIR__ . '/includes/header.php';
?>
<nav class="crumbs" aria-label="Breadcrumb"><a href="<?= e(url('index.php')) ?>">Home</a> › <a href="<?= e(url('products.php?cat=' . $p['cat_slug'])) ?>"><?= e($p['cat_name']) ?></a> › <?= e($p['name']) ?></nav>
<section class="detail">
  <div class="detail-media"><?= product_media($p) ?></div>
  <div>
    <p class="brand-line"><?= e($p['brand']) ?> <?= energy_badge($p['energy_rating']) ?></p>
    <h1><?= e($p['name']) ?></h1>
    <p class="price big"><strong><?= e(money($p['price'])) ?></strong>
      <?php if ($off): ?><s><?= e(money($p['old_price'])) ?></s> <span class="badge sale">Save <?= $off ?>%</span><?php endif; ?></p>
    <p><?= nl2br(e($p['description'])) ?></p>
    <ul class="ticks">
      <li><svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 10H7v-2h10v2zm-3-4V3H8v3H6V5a1 1 0 1 1 2 0v2h8V5a1 1 0 1 1 2 0v2h-2V7h2V5c0-1.1-.9-2-2-2z"/></svg> <?= (int)$p['warranty_months'] ?>-month warranty</li>
      <li><svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M21 10V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14l7-3.73 7 3.73V10c0-1.1.9-2 2-2z"/></svg> Delivery from <?= e(money(ZONES['kampala'][1])) ?> in Kampala</li>
      <li><svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M5 5h14v12H5zm0-2h14c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H5c-1.1 0-2-.9-2-2V5c0-1.1.9-2 2-2zm0 14l4-4 4 4H5z"/></svg> 7-day returns for faulty items</li>
    </ul>
    <?php if ($p['stock'] < 1): ?>
      <p class="stock out">Out of stock</p>
      <a class="btn ghost" href="<?= e(url('contact.php?subject=' . rawurlencode('Restock: ' . $p['name']))) ?>">Ask when it's back</a>
    <?php else: ?>
      <p class="stock <?= $p['stock'] <= 5 ? 'low' : 'ok' ?>"><?= $p['stock'] <= 5 ? 'Only ' . (int)$p['stock'] . ' left in stock' : 'In stock' ?></p>
      <form class="buy" method="post" action="<?= e(url('cart.php')) ?>">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="add">
        <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
        <label>Qty <input type="number" name="qty" value="1" min="1" max="<?= min(20, (int)$p['stock']) ?>"></label>
        <button class="btn" type="submit">Add to cart</button>
      </form>
      <a class="btn small ghost" href="<?= e(url('wishlist.php?action=' . (is_wishlisted((int)$p['id']) ? 'remove' : 'add') . '&id=' . (int)$p['id'])) ?>"><?= is_wishlisted((int)$p['id']) ? 'Remove from wishlist' : 'Add to wishlist' ?></a>
    <?php endif; ?>
  </div>
</section>

<section class="specs">
  <h2>Specifications</h2>
  <table>
    <?php foreach (preg_split('/\R/', $p['specs']) as $line):
        if (trim($line) === '') continue;
        [$k, $v] = array_pad(explode(':', $line, 2), 2, ''); ?>
      <tr><th scope="row"><?= e(trim($k)) ?></th><td><?= e(trim($v)) ?></td></tr>
    <?php endforeach; ?>
    <tr><th scope="row">Warranty</th><td><?= (int)$p['warranty_months'] ?> months</td></tr>
  </table>
</section>

<?php if ($related): ?>
<section>
  <h2>You may also like</h2>
  <div class="grid"><?php foreach ($related as $r) product_card($r); ?></div>
</section>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
