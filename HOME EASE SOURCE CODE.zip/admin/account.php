<?php
$adminTitle = 'Account';
require __DIR__ . '/_top.php';
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $a = q('SELECT * FROM admins WHERE id = ?', [$_SESSION['admin_id']])->fetch();
    $cur = (string)($_POST['current'] ?? '');
    $new = (string)($_POST['new'] ?? '');
    $conf = (string)($_POST['confirm'] ?? '');
    if (!$a || !password_verify($cur, $a['password_hash'])) { $errors[] = 'Your current password is incorrect.'; }
    if (strlen($new) < 10) { $errors[] = 'New password must be at least 10 characters.'; }
    if ($new !== $conf) { $errors[] = 'New password and confirmation do not match.'; }
    if (!$errors) {
        q('UPDATE admins SET password_hash = ? WHERE id = ?', [password_hash($new, PASSWORD_DEFAULT), $a['id']]);
        he_regenerate_session();
        flash('success', 'Password changed.');
        redirect('admin/account.php');
    }
}
?>
<h1>Account</h1>
<?php if ($errors): ?><div class="alert error" role="alert"><ul><?php foreach ($errors as $er): ?><li><?= e($er) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<form method="post" class="panel narrow">
  <?= csrf_field() ?>
  <h2>Change password</h2>
  <label>Current password <input type="password" name="current" required autocomplete="current-password"></label>
  <label>New password (10+ characters) <input type="password" name="new" required minlength="10" autocomplete="new-password"></label>
  <label>Confirm new password <input type="password" name="confirm" required minlength="10" autocomplete="new-password"></label>
  <button class="btn" type="submit">Change password</button>
</form>
<?php require __DIR__ . '/_bottom.php'; ?>
