<?php
$adminTitle = 'Email settings';
require __DIR__ . '/_top.php';
require_once __DIR__ . '/../includes/email.php';
$smtpStatus = email_smtp_status();
$latestTest = table_exists('email_messages')
    ? q("SELECT status, created_at FROM email_messages
         WHERE direction = 'outgoing' AND subject = ?
         ORDER BY created_at DESC LIMIT 1", ['HomeEase email configuration test'])->fetch()
    : false;
$lastImapSync = false;
if (email_imap_configured() && table_exists('email_sync_state')) {
    $mailbox = '{' . EMAIL_IMAP_HOST . ':' . (int)EMAIL_IMAP_PORT
        . (EMAIL_IMAP_ENCRYPTION === 'ssl' ? '/imap/ssl' : '/imap/tls') . '}' . EMAIL_IMAP_MAILBOX;
    $lastImapSync = q('SELECT updated_at FROM email_sync_state WHERE mailbox = ?', [$mailbox])->fetchColumn();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $recipient = post('test_recipient', 160);
    if (!filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
        flash('error', 'Enter a valid address to receive the configuration test.');
        redirect('admin/email-settings.php');
    }
    $emailRecordId = null;
    if (table_exists('email_messages')) {
        q('INSERT INTO email_messages
            (direction, sender_email, sender_name, recipient_email, subject, body, status, admin_id)
            VALUES (?,?,?,?,?,?,?,?)',
            [
                'outgoing', EMAIL_FROM_ADDRESS, EMAIL_FROM_NAME, $recipient,
                'HomeEase email configuration test', 'This is a HomeEase SMTP configuration test.',
                'queued', (int)$_SESSION['admin_id'],
            ]);
        $emailRecordId = (int)db()->lastInsertId();
    }
    $result = send_store_email($recipient, '', 'HomeEase email configuration test', 'This is a HomeEase SMTP configuration test.');
    if ($emailRecordId !== null) {
        q('UPDATE email_messages SET status = ?, provider_message_id = ? WHERE id = ?', [
            $result['success'] ? 'sent_to_server' : $result['state'],
            $result['success'] ? ($result['message_id'] ?: null) : null,
            $emailRecordId,
        ]);
    }
    if (table_exists('email_messages')) {
        try {
            email_audit($result['success'] ? 'send_test' : 'send_test_failed', 'settings');
        } catch (PDOException $exception) {
            error_log('HomeEase email test audit entry could not be recorded: ' . $exception->getMessage());
        }
    }
    flash($result['success'] ? 'success' : 'error', $result['success']
        ? 'Gmail SMTP accepted the test email. This does not confirm delivery; sync the inbox to check for a returned failure notice.'
        : $result['error']);
    redirect('admin/email-settings.php');
}
$mailerAvailable = $smtpStatus['state'] !== 'mailer_unavailable' && email_mailer_available();
$smtpCredentialsConfigured = EMAIL_SMTP_USERNAME !== '' && email_secret_configured(EMAIL_SMTP_PASSWORD);
$imapCredentialsConfigured = EMAIL_IMAP_USERNAME !== '' && email_secret_configured(EMAIL_IMAP_PASSWORD);
$imapStatus = email_imap_configured() && function_exists('imap_open');
$smtpNeeds = [];
if (!$mailerAvailable) { $smtpNeeds[] = 'install PHPMailer with Composer'; }
if (!$smtpCredentialsConfigured) { $smtpNeeds[] = 'add your Google app password to config.local.php'; }
if ($smtpStatus['state'] === 'invalid_settings') { $smtpNeeds[] = 'check the sender address and SMTP settings'; }
$imapNeeds = [];
if (!$imapCredentialsConfigured) { $imapNeeds[] = 'add your Google app password to config.local.php'; }
if (!function_exists('imap_open')) { $imapNeeds[] = 'enable the PHP IMAP extension for the web server'; }
if (!email_imap_configured() && $imapCredentialsConfigured) { $imapNeeds[] = 'check the IMAP settings'; }
?>
<div class="section-head"><div><h1>Email settings</h1><p class="muted">Provider-neutral SMTP/IMAP configuration. Secrets are kept out of the admin UI and database.</p></div></div>
<nav class="email-folders" aria-label="Email folders">
  <a href="<?= e(url('admin/email.php')) ?>">Overview</a><a href="<?= e(url('admin/email-inbox.php')) ?>">Inbox</a>
  <a href="<?= e(url('admin/email-sent.php')) ?>">Sent emails</a><a class="on" href="<?= e(url('admin/email-settings.php')) ?>">Email settings</a>
</nav>
<div class="email-settings-grid">
  <section class="panel">
    <h2>Outgoing email (SMTP)</h2>
    <p>Status: <strong><?php
      echo match ($smtpStatus['state']) {
          'ready' => 'SMTP settings configured; PHPMailer available',
          'mailer_unavailable' => 'PHPMailer unavailable',
          'invalid_settings' => 'Invalid SMTP settings',
          default => 'SMTP settings missing',
      };
    ?></strong></p>
    <?php if ($latestTest): ?>
      <p class="muted small">Latest test:
        <?php if ($latestTest['status'] === 'sent_to_server'): ?>
          Gmail accepted it on <?= e(date('j M Y, H:i', strtotime($latestTest['created_at']))) ?>. Delivery is not confirmed.
        <?php elseif ($latestTest['status'] === 'delivery_failed'): ?>
          A delivery failure was reported for the test sent on <?= e(date('j M Y, H:i', strtotime($latestTest['created_at']))) ?>.
        <?php else: ?>
          <?= e(ucfirst(str_replace('_', ' ', $latestTest['status']))) ?> on <?= e(date('j M Y, H:i', strtotime($latestTest['created_at']))) ?>.
        <?php endif; ?>
      </p>
    <?php else: ?>
      <p class="muted small">No configuration test has been recorded yet.</p>
    <?php endif; ?>
    <?php if ($smtpNeeds): ?><p class="muted small">To enable sending: <?= e(implode('; ', $smtpNeeds)) ?>.</p><?php endif; ?>
    <dl class="email-config-list">
      <dt>Business sender address</dt><dd><?= e(EMAIL_FROM_ADDRESS) ?></dd>
      <dt>Sender display name</dt><dd><?= e(EMAIL_FROM_NAME) ?></dd>
      <dt>SMTP host</dt><dd><?= EMAIL_SMTP_HOST !== '' ? e(EMAIL_SMTP_HOST . ':' . EMAIL_SMTP_PORT . ' (' . EMAIL_SMTP_ENCRYPTION . ')') : 'Not configured' ?></dd>
      <dt>SMTP credentials</dt><dd><?= $smtpCredentialsConfigured ? 'Configured (value hidden)' : 'App password missing' ?></dd>
      <dt>Contact notifications</dt><dd><?= EMAIL_NOTIFY_CONTACT ? 'Enabled' : 'Disabled' ?></dd>
    </dl>
    <form method="post" class="email-test-form">
      <?= csrf_field() ?>
      <label>Send a configuration test to <input type="email" name="test_recipient" required maxlength="160" placeholder="you@example.com"></label>
      <button class="btn" type="submit">Send test email</button>
    </form>
  </section>
  <section class="panel">
    <h2>Incoming email (IMAP)</h2>
    <p>Status: <strong><?= $imapStatus ? 'Ready for manual synchronization' : 'Not configured' ?></strong></p>
    <?php if ($lastImapSync): ?><p class="muted small">Last synchronized: <?= e(date('j M Y, H:i', strtotime((string)$lastImapSync))) ?>.</p><?php endif; ?>
    <?php if (!$imapStatus): ?><p class="muted small">To enable inbox sync: <?= e(implode('; ', $imapNeeds)) ?>.</p><?php endif; ?>
    <dl class="email-config-list">
      <dt>IMAP server</dt><dd><?= EMAIL_IMAP_HOST !== '' ? e(EMAIL_IMAP_HOST . ':' . EMAIL_IMAP_PORT . ' (' . EMAIL_IMAP_ENCRYPTION . ')') : 'Not configured' ?></dd>
      <dt>Mailbox</dt><dd><?= e(EMAIL_IMAP_MAILBOX) ?></dd>
      <dt>IMAP credentials</dt><dd><?= EMAIL_IMAP_USERNAME !== '' && EMAIL_IMAP_PASSWORD !== '' ? 'Configured (value hidden)' : 'Not configured' ?></dd>
      <dt>PHP IMAP extension</dt><dd><?= function_exists('imap_open') ? 'Enabled' : 'Not enabled in this WAMP PHP build' ?></dd>
    </dl>
    <?php if ($imapStatus): ?>
      <form method="post" action="<?= e(url('admin/email-sync.php')) ?>"><?= csrf_field() ?><button class="btn" type="submit">Sync inbox now</button></form>
    <?php endif; ?>
    <p class="muted small">Inbox sync runs manually here and automatically every minute while a customer views their email page. Synchronization imports message metadata and plain text only. Confirmed delivery-failure notices are matched to sent emails; no failure notice does not prove delivery. Attachments are not downloaded; remote HTML content is not rendered.</p>
  </section>
</div>
<section class="panel email-settings-instructions">
  <h2>Configure Gmail on WAMP</h2>
  <ol>
    <li>Run <code>composer install</code> from the project directory to install PHPMailer. Sending remains unavailable until Composer completes successfully.</li>
    <li>Set <code>EMAIL_FROM_ADDRESS</code> and <code>EMAIL_SMTP_USERNAME</code> to your full Gmail address. Use <code>smtp.gmail.com</code>, port <code>587</code>, and <code>tls</code> for SMTP; set <code>EMAIL_SMTP_PASSWORD</code> to the account's app password, not its normal sign-in password.</li>
    <li>For incoming mail, use <code>imap.gmail.com</code>, port <code>993</code>, and <code>ssl</code>. Set <code>EMAIL_IMAP_USERNAME</code> to the same full Gmail address and <code>EMAIL_IMAP_PASSWORD</code> to its app password. Gmail personal accounts have IMAP enabled; confirm access policies with your administrator for Google Workspace accounts.</li>
    <li>Put these settings in the ignored <code>config.local.php</code> beside <code>config.php</code>. An app password requires 2-Step Verification and may not be available for every managed account. Google recommends “Sign in with Google” where supported; this mailer currently uses SMTP/IMAP credentials. Never enter email passwords in this page or send them in chat.</li>
    <li>Contact-form notifications are optional; set <code>EMAIL_NOTIFY_CONTACT</code> to <code>true</code> after SMTP works. Sync the inbox manually using the button above, or let customer inboxes check for new mail automatically while those pages are open.</li>
  </ol>
  <pre><code>define('EMAIL_FROM_ADDRESS', 'your-full-address@gmail.com');
define('EMAIL_FROM_NAME', 'HomeEase');
define('EMAIL_SMTP_HOST', 'smtp.gmail.com');
define('EMAIL_SMTP_PORT', 587);
define('EMAIL_SMTP_ENCRYPTION', 'tls');
define('EMAIL_SMTP_USERNAME', 'your-full-address@gmail.com');
define('EMAIL_SMTP_PASSWORD', 'your-16-character-app-password');
define('EMAIL_IMAP_HOST', 'imap.gmail.com');
define('EMAIL_IMAP_PORT', 993);
define('EMAIL_IMAP_ENCRYPTION', 'ssl');
define('EMAIL_IMAP_USERNAME', 'your-full-address@gmail.com');
define('EMAIL_IMAP_PASSWORD', 'your-16-character-app-password');</code></pre>
  <p>SMTP confirmation means Gmail accepted the message, not that it was delivered. Inbox synchronization can mark a sent email as failed when Gmail returns a matching delivery-failure notice; it cannot confirm successful delivery. See Google's <a href="https://support.google.com/accounts/answer/185833" target="_blank" rel="noopener noreferrer">app password guidance</a>. Never commit <code>config.local.php</code>.</p>
</section>
<?php require __DIR__ . '/_bottom.php'; ?>
