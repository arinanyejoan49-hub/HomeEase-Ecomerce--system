<?php
$adminTitle = 'Order';
require __DIR__ . '/_top.php';
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$o = q('SELECT * FROM orders WHERE id = ?', [$id])->fetch();
if (!$o) { flash('error', 'Order not found.'); redirect('admin/orders.php'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (post('action', 20) === 'pesajet_refresh') {
        $r = pesajet_refresh_order($o['order_no']);
        flash('success', $r === 'ignored' ? 'Nothing to check for this order.' : 'Payment status refreshed from PesaJet.');
        redirect('admin/order.php?id=' . $id);
    }
    $new = post('status', 20);
    if (isset(order_statuses()[$new]) && $new !== $o['status']) {
        $pdo = db();
        $pdo->beginTransaction();
        // Cancelling returns the items to stock (once).
        if ($new === 'cancelled' && $o['status'] !== 'cancelled') {
            foreach (q('SELECT product_id, qty FROM order_items WHERE order_id = ?', [$id])->fetchAll() as $it) {
                if ($it['product_id']) { q('UPDATE products SET stock = stock + ? WHERE id = ?', [$it['qty'], $it['product_id']]); }
            }
        }
        // Re-opening a cancelled order takes the stock again.
        if ($o['status'] === 'cancelled' && $new !== 'cancelled') {
            foreach (q('SELECT product_id, qty FROM order_items WHERE order_id = ?', [$id])->fetchAll() as $it) {
                if ($it['product_id']) { q('UPDATE products SET stock = CASE WHEN stock >= ? THEN stock - ? ELSE 0 END WHERE id = ?', [$it['qty'], $it['qty'], $it['product_id']]); }
            }
        }
        $pay = $o['payment_status'];
        if ($new === 'delivered' && $o['payment_method'] === 'cod') { $pay = 'paid on delivery'; }
        q('UPDATE orders SET status = ?, payment_status = ? WHERE id = ?', [$new, $pay, $id]);
        $pdo->commit();
        flash('success', 'Order status updated.');
    }
    redirect('admin/order.php?id=' . $id);
}
$items = q('SELECT * FROM order_items WHERE order_id = ?', [$id])->fetchAll();
?>
<p><a href="<?= e(url('admin/orders.php')) ?>">← All orders</a></p>
<h1>Order <?= e($o['order_no']) ?></h1>
<div class="two-col">
  <section class="panel">
    <h2>Customer</h2>
    <p><b><?= e($o['customer_name']) ?></b><br><?= e($o['email']) ?><br><?= e($o['phone']) ?></p>
    <p><b>Delivery:</b> <?= e(ZONES[$o['zone']][0] ?? $o['zone']) ?><br><?= e($o['address']) ?></p>
    <?php if ($o['notes']): ?><p><b>Notes:</b> <?= e($o['notes']) ?></p><?php endif; ?>
    <p><b>Placed:</b> <?= e(date('j M Y, H:i', strtotime($o['created_at']))) ?></p>
    <p><b>Payment:</b> <?= e($o['payment_method']) ?> · <?= e(payment_status_label($o['payment_status'])) ?><?= $o['payment_ref'] ? ' · ' . e(payment_reference_label($o['payment_ref'])) : '' ?><?= $o['card_last4'] ? ' · •••• ' . e($o['card_last4']) : '' ?></p>
  </section>
  <section class="panel">
    <h2>Status</h2>
    <p>Current: <span class="pill <?= e($o['status']) ?>"><?= e(order_statuses()[$o['status']] ?? $o['status']) ?></span></p>
    <form method="post" class="inline-form">
      <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$id ?>">
      <label>Change status
        <select name="status"><?php foreach (order_statuses() as $k => $lbl): ?><option value="<?= e($k) ?>" <?= $o['status'] === $k ? 'selected' : '' ?>><?= e($lbl) ?></option><?php endforeach; ?></select>
      </label>
      <button class="btn small" type="submit">Update</button>
    </form>
    <?php if ($o['payment_method'] === 'momo' && $o['payment_status'] === 'awaiting payment' && pesajet_enabled()): ?>
    <form method="post" class="inline-form">
      <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$id ?>"><input type="hidden" name="action" value="pesajet_refresh">
      <button class="btn small ghost" type="submit">Check payment status with PesaJet</button>
    </form>
    <?php endif; ?>
  </section>
</div>
<section class="panel">
  <h2>Items</h2>
  <table class="data">
    <thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Line total</th></tr></thead>
    <tbody>
    <?php foreach ($items as $i): ?>
      <tr><td><?= e($i['name']) ?></td><td><?= e(money($i['price'])) ?></td><td><?= (int)$i['qty'] ?></td><td><?= e(money($i['price'] * $i['qty'])) ?></td></tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <dl class="totals">
    <div><dt>Subtotal</dt><dd><?= e(money($o['subtotal'])) ?></dd></div>
    <?php if ($o['discount']): ?><div class="good"><dt>Discount (<?= e($o['coupon']) ?>)</dt><dd>-<?= e(money($o['discount'])) ?></dd></div><?php endif; ?>
    <div><dt>Delivery</dt><dd><?= e(money($o['delivery_fee'])) ?></dd></div>
    <div class="grand"><dt>Total</dt><dd><?= e(money($o['total'])) ?></dd></div>
  </dl>
</section>
<?php require __DIR__ . '/_bottom.php'; ?>
