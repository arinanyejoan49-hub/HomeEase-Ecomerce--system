<?php
require __DIR__ . '/_top.php';
require_once __DIR__ . '/../includes/email.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}
csrf_verify();
if (!table_exists('email_messages') || !table_exists('email_sync_state')) {
    flash('error', 'Install the email management migration before synchronizing mail.');
    redirect('admin/email-settings.php');
}
$result = email_sync_imap();
if ($result['success']) {
    email_audit('sync', 'imap');
    $added = (int)$result['added'];
    $summary = $added === 0
        ? 'Inbox synchronization completed. No new messages were found.'
        : $added . ' new message(s) synchronized.';
    $deliveryFailures = (int)($result['delivery_failures'] ?? 0);
    if ($deliveryFailures > 0) {
        $summary .= ' ' . $deliveryFailures . ' confirmed delivery failure(s) matched to sent email(s).';
    } else {
        $summary .= ' No matching delivery-failure notice was found; delivery is not confirmed.';
    }
    flash('success', $summary);
} else {
    email_audit('sync_failed', 'imap');
    flash('error', $result['error']);
}
redirect('admin/email-settings.php');
