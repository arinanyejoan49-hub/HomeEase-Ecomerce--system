<?php
$adminTitle = 'Sent emails';
require __DIR__ . '/_top.php';
if (!table_exists('email_messages')) {
    flash('error', 'Install the email management migration first.');
    redirect('admin/email.php');
}
$page = max(1, min(100000, (int)($_GET['page'] ?? 1)));
$perPage = 25;
$total = (int)q("SELECT COUNT(*) FROM email_messages WHERE direction = 'outgoing'")->fetchColumn();
$lastPage = max(1, (int)ceil($total / $perPage));
$page = min($page, $lastPage);
$sent = q("SELECT * FROM email_messages WHERE direction = 'outgoing'
           ORDER BY created_at DESC LIMIT $perPage OFFSET " . (($page - 1) * $perPage))->fetchAll();
?>
<div class="section-head"><div><h1>Sent emails</h1><p class="muted">SMTP acceptance does not confirm delivery. Sync the inbox to check for returned failure notices; no failure notice does not prove delivery.</p></div><a class="btn" href="<?= e(url('admin/email-compose.php')) ?>">Compose email</a></div>
<nav class="email-folders" aria-label="Email folders">
  <a href="<?= e(url('admin/email.php')) ?>">Overview</a><a href="<?= e(url('admin/email-inbox.php')) ?>">Inbox</a>
  <a href="<?= e(url('admin/messages.php')) ?>">Website enquiries</a><a class="on" href="<?= e(url('admin/email-sent.php')) ?>">Sent emails</a>
  <a href="<?= e(url('admin/email-settings.php')) ?>">Email settings</a>
</nav>
<?php if (!$sent): ?><p class="empty">No outgoing emails have been recorded.</p><?php else: ?>
<div class="table-wrap"><table class="data">
  <thead><tr><th>Recipient</th><th>Subject</th><th>Message preview</th><th>Sent by</th><th>Status</th><th>Date</th></tr></thead>
  <tbody><?php foreach ($sent as $item): ?>
    <tr>
      <td><?= e($item['recipient_email']) ?></td>
      <td><?= e($item['subject']) ?></td>
      <td><?= e(mb_substr($item['body'], 0, 100)) ?></td>
      <td><?= e($item['sender_name']) ?></td>
      <td><?php
        $statusLabels = [
            'sent_to_server' => 'Accepted by mail server',
            'delivery_failed' => 'Delivery failure reported',
            'failed' => 'Send failed',
            'authentication_failed' => 'Authentication failed',
            'connection_failed' => 'Connection failed',
            'missing_settings' => 'SMTP settings missing',
            'invalid_settings' => 'SMTP settings invalid',
            'mailer_unavailable' => 'PHPMailer unavailable',
        ];
        echo e($statusLabels[$item['status']] ?? ucfirst(str_replace('_', ' ', $item['status'])));
      ?></td>
      <td><?= e(date('j M Y, H:i', strtotime($item['created_at']))) ?></td>
    </tr>
  <?php endforeach; ?></tbody>
</table></div>
<?php if ($lastPage > 1): ?><nav class="email-pagination"><span>Page <?= $page ?> of <?= $lastPage ?></span><?php if ($page > 1): ?><a class="btn small ghost" href="<?= e(url('admin/email-sent.php?page=' . ($page - 1))) ?>">Previous</a><?php endif; ?><?php if ($page < $lastPage): ?><a class="btn small ghost" href="<?= e(url('admin/email-sent.php?page=' . ($page + 1))) ?>">Next</a><?php endif; ?></nav><?php endif; ?>
<?php endif; ?>
<?php require __DIR__ . '/_bottom.php'; ?>
