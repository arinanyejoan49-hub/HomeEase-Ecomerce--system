<?php
$adminTitle = 'Emails';
require __DIR__ . '/_top.php';
require_once __DIR__ . '/../includes/email.php';

$emailTableReady = table_exists('email_messages');
$inquiries = (int)q("SELECT COUNT(*) FROM messages WHERE status <> 'archived'")->fetchColumn();
$unreadWeb = (int)q("SELECT COUNT(*) FROM messages WHERE status = 'new'")->fetchColumn();
$unreadMailbox = $emailTableReady
    ? (int)q("SELECT COUNT(*) FROM email_messages WHERE direction = 'incoming' AND is_read = 0 AND status <> 'archived'")->fetchColumn()
    : 0;
$sentCount = $emailTableReady
    ? (int)q("SELECT COUNT(*) FROM email_messages WHERE direction = 'outgoing' AND status = 'sent_to_server'")->fetchColumn()
    : 0;
$awaitingReply = $emailTableReady
    ? (int)q("SELECT COUNT(*) FROM messages m
        WHERE m.status <> 'archived'
        AND NOT EXISTS (
          SELECT 1 FROM email_messages e
          WHERE e.contact_message_id = m.id AND e.direction = 'outgoing' AND e.status = 'sent_to_server'
        )")->fetchColumn()
    : $inquiries;

$recentSql = "SELECT 'website' AS source, id, name AS sender_name, email AS sender_email,
                     subject, message AS body, status, created_at
              FROM messages";
if ($emailTableReady) {
    $recentSql .= " UNION ALL
                    SELECT 'email' AS source, id, sender_name, sender_email, subject, body,
                           CASE WHEN is_read = 1 THEN 'read' ELSE 'new' END AS status, created_at
                    FROM email_messages WHERE direction = 'incoming'";
}
$recent = q($recentSql . ' ORDER BY created_at DESC LIMIT 8')->fetchAll();
?>
<div class="section-head">
  <div><h1>Email management</h1><p class="muted">Website enquiries and messages from your configured business mailbox.</p></div>
  <a class="btn" href="<?= e(url('admin/email-compose.php')) ?>">Compose email</a>
</div>
<nav class="email-folders" aria-label="Email folders">
  <a class="on" href="<?= e(url('admin/email.php')) ?>">Overview</a>
  <a href="<?= e(url('admin/email-inbox.php')) ?>">Inbox <span><?= $unreadWeb + $unreadMailbox ?></span></a>
  <a href="<?= e(url('admin/messages.php')) ?>">Website enquiries</a>
  <a href="<?= e(url('admin/email-sent.php')) ?>">Sent emails</a>
  <a href="<?= e(url('admin/email-settings.php')) ?>">Email settings</a>
</nav>
<?php if (!$emailTableReady): ?>
  <div class="alert error" role="alert">Email storage is not installed yet. Apply <code>database/migrations/add_email_management.sql</code> to the existing database; this preserves website enquiries.</div>
<?php endif; ?>
<div class="email-stat-grid">
  <a class="email-stat" href="<?= e(url('admin/email-inbox.php?source=website')) ?>"><span>Total website enquiries</span><strong><?= $inquiries ?></strong></a>
  <a class="email-stat" href="<?= e(url('admin/email-inbox.php?status=unread')) ?>"><span>Unread messages</span><strong><?= $unreadWeb + $unreadMailbox ?></strong></a>
  <a class="email-stat" href="<?= e(url('admin/email-sent.php')) ?>"><span>Accepted by mail server</span><strong><?= $sentCount ?></strong></a>
  <a class="email-stat" href="<?= e(url('admin/email-inbox.php?source=website&status=unread')) ?>"><span>Enquiries awaiting a reply</span><strong><?= $awaitingReply ?></strong></a>
</div>
<section class="panel email-panel">
  <div class="section-head"><h2>Recently received</h2><a href="<?= e(url('admin/email-inbox.php')) ?>">Open inbox</a></div>
  <?php if (!$recent): ?>
    <p class="empty">No messages have been received yet.</p>
  <?php else: ?>
    <div class="email-list">
      <?php foreach ($recent as $message): ?>
        <a class="email-list-row <?= $message['status'] === 'new' ? 'unread' : '' ?>" href="<?= e(url('admin/email-view.php?source=' . $message['source'] . '&id=' . (int)$message['id'])) ?>">
          <span class="email-list-main">
            <strong><?= e($message['sender_name'] ?: $message['sender_email']) ?></strong>
            <span><?= e($message['subject']) ?></span>
            <small><?= e(mb_substr(trim((string)$message['body']), 0, 120)) ?></small>
          </span>
          <time datetime="<?= e(date(DATE_ATOM, strtotime($message['created_at']))) ?>"><?= e(date('j M, H:i', strtotime($message['created_at']))) ?></time>
        </a>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>
<section class="email-setup-note">
  <div><strong>Mail-server status</strong><span>SMTP <?= email_smtp_configured() && email_mailer_available() ? 'configured' : 'needs configuration' ?> · IMAP <?= email_imap_configured() && function_exists('imap_open') ? 'ready' : 'needs configuration' ?></span></div>
  <a class="btn small ghost" href="<?= e(url('admin/email-settings.php')) ?>">Configure email</a>
</section>
<?php require __DIR__ . '/_bottom.php'; ?>
