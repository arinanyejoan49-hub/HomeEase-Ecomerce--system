<?php
$adminTitle = 'Calendar';
require __DIR__ . '/_top.php';

// Current month view
$month = isset($_GET['month']) && preg_match('/^\d{4}-\d{2}$/', $_GET['month']) ? $_GET['month'] : date('Y-m');
$start = date('Y-m-01', strtotime($month));
$end   = date('Y-m-t', strtotime($start));
$prev  = date('Y-m', strtotime($start . ' -1 month'));
$next  = date('Y-m', strtotime($start . ' +1 month'));

$ordersByDay = [];
$rows = q("SELECT DATE(created_at) AS d, COUNT(*) AS c, COALESCE(SUM(total),0) AS t FROM orders WHERE created_at BETWEEN ? AND ? GROUP BY DATE(created_at)", [$start, $end])->fetchAll();
foreach ($rows as $r) { $ordersByDay[$r['d']] = ['count' => (int)$r['c'], 'total' => (int)$r['t']]; }

$dayNames = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
$first    = new DateTime($start);
$firstDay = (int)$first->format('N'); // 1=Mon ... 7=Sun
$daysInMonth = (int)date('t', strtotime($start));
?>
<h1>Calendar</h1>
<p>Orders by date for <?= e(date('F Y', strtotime($start))) ?>.</p>
<div class="panel">
  <div class="section-head" style="margin-bottom:12px;">
    <div>
      <a class="btn small" href="<?= e(url('admin/calendar.php?month=' . $prev)) ?>">&larr; Prev</a>
      <strong><?= e(date('F Y', strtotime($start))) ?></strong>
      <a class="btn small" href="<?= e(url('admin/calendar.php?month=' . $next)) ?>">Next &rarr;</a>
    </div>
    <span class="muted small"><?= (int)q('SELECT COUNT(*) FROM orders WHERE created_at BETWEEN ? AND ?', [$start, $end])->fetchColumn() ?> orders this month</span>
  </div>
  <table class="data">
    <thead>
      <tr><?php foreach ($dayNames as $dn): ?><th style="width:14%"><?= e($dn) ?></th><?php endforeach; ?></tr>
    </thead>
    <tbody>
    <?php
    $d = 1;
    for ($w = 0; $w < 6 && $d <= $daysInMonth; $w++):
      echo '<tr>';
      for ($wd = 1; $wd <= 7; $wd++):
        $date = $start . '-' . str_pad($d, 2, '0', STR_PAD_LEFT);
        $isToday = $date === date('Y-m-d');
        if (($w === 0 && $wd < $firstDay) || $d > $daysInMonth) {
          echo '<td></td>';
        } else {
          $info = $ordersByDay[$date] ?? null;
          echo '<td class="' . ($isToday ? 'on' : '') . '" style="vertical-align:top; min-height:70px; position:relative;">';
          echo '<div style="font-weight:700">' . (int)$d . '</div>';
          if ($info): ?>
            <div style="font-size:.78rem; color:var(--army-dark); margin-top:4px;"><?= $info['count'] ?> order<?= $info['count']>1?'s':'' ?></div>
            <div style="font-size:.75rem; color:var(--muted); margin-top:1px;"><?= e(money($info['total'])) ?></div>
          <?php endif;
          echo '</td>';
          $d++;
        }
      endfor;
      echo '</tr>';
    endfor;
    ?>
    </tbody>
  </table>
  <p class="muted small">Days with orders show the order count and total. Click an order on the <a href="<?= e(url('admin/orders.php')) ?>">Orders</a> page to view details.</p>
</div>
<?php require __DIR__ . '/_bottom.php'; ?>
