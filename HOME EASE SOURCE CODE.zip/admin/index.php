<?php
$adminTitle = 'Dashboard';
require __DIR__ . '/_top.php';

$totalProducts = (int)q('SELECT COUNT(*) FROM products WHERE is_active = 1')->fetchColumn();
$totalOrders   = (int)q('SELECT COUNT(*) FROM orders')->fetchColumn();
$customerAccountsAvailable = table_exists('users');
$totalCustomers = $customerAccountsAvailable
    ? (int)q("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn()
    : (int)q('SELECT COUNT(DISTINCT email) FROM orders')->fetchColumn();
$totalSales    = (int)q("SELECT COALESCE(SUM(total),0) FROM orders WHERE status <> 'cancelled'")->fetchColumn();
$low           = q('SELECT id, name, stock FROM products WHERE is_active = 1 AND stock <= 5 ORDER BY stock, name')->fetchAll();
$recent        = q('SELECT * FROM orders ORDER BY id DESC LIMIT 8')->fetchAll();

// Chart data: order status distribution (donut)
$statusRows = q("SELECT status, COUNT(*) AS c FROM orders GROUP BY status")->fetchAll();
$statusMap  = [];
$statusTotal= 0;
foreach ($statusRows as $r) {
    $statusMap[$r['status']] = (int)$r['c'];
    $statusTotal += (int)$r['c'];
}
$statusColors = [
    'pending'   => '#d97706',
    'confirmed' => '#2563eb',
    'dispatched'=> '#7c3aed',
    'delivered' => '#46512a',
    'cancelled' => '#b91c1c',
];

// Chart data: products per category (bar)
$catRows = q('SELECT c.name AS cat, COUNT(p.id) AS n FROM categories c LEFT JOIN products p ON p.category_id = c.id AND p.is_active = 1 GROUP BY c.id, c.name ORDER BY n DESC, c.name')->fetchAll();
$maxCat = 1;
foreach ($catRows as $cr) { if ((int)$cr['n'] > $maxCat) { $maxCat = (int)$cr['n']; } }

// Chart data: monthly sales (last 6 months)
$months = [];
for ($i = 5; $i >= 0; $i--) {
    $m = date('Y-m', strtotime("-$i months"));
    $months[$m] = ['label' => date('M y', strtotime($m . '-01')), 'sales' => 0];
}
if (DB_DRIVER === 'sqlite') {
    $saleRows = q("SELECT strftime('%Y-%m', created_at) AS m, COALESCE(SUM(total),0) AS s
                   FROM orders WHERE status <> 'cancelled' AND created_at >= datetime('now', '-5 months')
                   GROUP BY m")->fetchAll();
} else {
    $saleRows = q("SELECT DATE_FORMAT(created_at, '%Y-%m') AS m, COALESCE(SUM(total),0) AS s
                   FROM orders WHERE status <> 'cancelled'
                     AND created_at >= DATE_SUB((SELECT MAX(created_at) FROM orders), INTERVAL 5 MONTH)
                   GROUP BY m")->fetchAll();
}
foreach ($saleRows as $sr) {
    if (isset($months[$sr['m']])) { $months[$sr['m']]['sales'] = (int)$sr['s']; }
}
$maxSale = 1;
foreach ($months as $mo) { if ($mo['sales'] > $maxSale) { $maxSale = $mo['sales']; } }
?>
<h1>Dashboard</h1>
<p>Welcome back, <?= e($_SESSION['admin_name'] ?? 'admin') ?>. Here&rsquo;s an overview of your store.</p>
<?php if (!$customerAccountsAvailable): ?>
  <div class="alert error" role="alert">
    Customer account tables are missing. The customer count below uses order email addresses until you import <code>database.sql</code> in phpMyAdmin to enable customer account management.
  </div>
<?php endif; ?>

<div class="stat-grid">
  <div class="stat products">
    <div class="stat-icon">📦</div>
    <div class="stat-body"><span>Total Products</span><b><?= e($totalProducts) ?></b></div>
  </div>
  <div class="stat orders">
    <div class="stat-icon">🛒</div>
    <div class="stat-body"><span>Total Orders</span><b><?= e($totalOrders) ?></b></div>
  </div>
  <div class="stat customers">
    <div class="stat-icon">👥</div>
    <div class="stat-body"><span>Total Customers</span><b><?= e($totalCustomers) ?></b></div>
  </div>
  <div class="stat sales">
    <div class="stat-icon">💰</div>
    <div class="stat-body"><span>Total Sales</span><b><?= e(money($totalSales)) ?></b></div>
  </div>
</div>

<?php if ($customerAccountsAvailable): ?>
<section class="panel">
  <div class="panel-head">
    <div>
      <h2>Customer accounts</h2>
      <p class="muted">Create new customer accounts or update existing profiles.</p>
    </div>
    <div class="actions">
      <a class="btn small ghost" href="<?= e(url('admin/customers.php')) ?>">Manage users</a>
      <a class="btn small" href="<?= e(url('admin/customer-form.php')) ?>">Add user</a>
    </div>
  </div>
</section>
<?php endif; ?>
<section class="panel wide">
  <div class="panel-head"><h2>Store Overview</h2></div>
  <div class="charts-row">
    <div class="chart-card">
      <div class="panel-head" style="border:none; margin:0 0 12px 0; padding:0;"><h3 style="margin:0;">Orders by Status</h3></div>
      <div class="donut-wrap" style="position:relative; width:220px; height:220px; margin:0 auto;">
        <svg width="220" height="220" viewBox="0 0 220 220">
          <?php
          $cx = 110; $cy = 110; $r = 90; $inner = 60;
          $start = -90;
          $arcColor = '#e5e7eb';
          $arcColorInner = '#e5e7eb';
          // background ring
          echo '<circle cx="'.$cx.'" cy="'.$cy.'" r="'.$r.'" fill="none" stroke="'.$arcColor.'" stroke-width="22"/>';
          $angle = $start;
          foreach ($statusMap as $st => $cnt) {
              $pct = $statusTotal ? ($cnt / $statusTotal) : 0;
              $sweep = $pct * 360;
              if ($sweep <= 0) continue;
              $color = $statusColors[$st] ?? '#6b7280';
              $rad1 = deg2rad($angle);
              $rad2 = deg2rad($angle + $sweep);
              $x1 = $cx + $r * cos($rad1); $y1 = $cy + $r * sin($rad1);
              $x2 = $cx + $r * cos($rad2); $y2 = $cy + $r * sin($rad2);
              $large = $sweep > 180 ? 1 : 0;
              echo '<path d="M '.$x1.' '.$y1.' A '.$r.' '.$r.' 0 '.$large.' 1 '.$x2.' '.$y2.'" fill="none" stroke="'.$color.'" stroke-width="22" stroke-linecap="round"/>';
              $angle += $sweep;
          }
          // center text
          echo '<text x="'.$cx.'" y="'.$cy.'" text-anchor="middle" dy=".35em" font-size="18" font-weight="800" fill="#1b2528">'.($statusTotal ? $statusTotal : 0).'</text>';
          echo '<text x="'.$cx.'" y="'.($cy + 22).'" text-anchor="middle" dy=".35em" font-size="11" fill="#5f6b70">orders</text>';
          ?>
        </svg>
      </div>
      <div class="donut-legend" style="margin-top:10px; display:flex; flex-wrap:wrap; gap:8px 14px; justify-content:center;">
        <?php foreach ($statusMap as $st => $cnt): $color = $statusColors[$st] ?? '#6b7280'; $lbl = order_statuses()[$st] ?? $st; $pct = $statusTotal ? round(($cnt/$statusTotal)*100) : 0; ?>
          <span style="display:flex; align-items:center; gap:6px; font-size:.85rem;"><span style="display:inline-block; width:10px; height:10px; border-radius:50%; background:<?= e($color) ?>;"></span><?= e($lbl) ?> <span class="muted">(<?= e($pct) ?>%)</span></span>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="chart-card">
      <div class="panel-head" style="border:none; margin:0 0 12px 0; padding:0;"><h3 style="margin:0;">Products by Category</h3></div>
      <div class="bar-wrap" style="height:200px; padding:10px 0;">
        <?php foreach ($catRows as $cr): $n = (int)$cr['n']; $h = $maxCat ? round(($n/$maxCat)*140) : 0; ?>
          <div class="bar-item" style="--h:<?= $h ?>px;">
            <div class="bar" style="height:<?= $h ?>px;" title="<?= e($cr['cat']) ?>: <?= $n ?>"><?= $n ?></div>
            <div class="bar-label" style="font-size:.75rem; color:var(--muted); writing-mode:vertical-rl; text-orientation:mixed; padding:6px 2px;"><?= e($cr['cat']) ?></div>
          </div>
        <?php endforeach; ?>
      </div>
      <p class="muted small" style="text-align:center; margin-top:8px;">Active products per category.</p>
    </div>
  </div>
</section>

<div class="dashboard-grid">
  <section class="panel wide">
    <div class="panel-head">
      <h2>Recent Orders</h2>
      <a class="btn small" href="<?= e(url('admin/orders.php')) ?>">View all &rarr;</a>
    </div>
    <?php if (!$recent): ?>
      <p class="muted">No orders yet.</p>
    <?php else: ?>
    <table class="data">
      <thead><tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th></tr></thead>
      <tbody>
      <?php foreach ($recent as $o): ?>
        <tr>
          <td><a href="<?= e(url('admin/order.php?id=' . $o['id'])) ?>"><?= e($o['order_no']) ?></a></td>
          <td><?= e($o['customer_name']) ?><br><small class="muted"><?= e($o['phone']) ?></small></td>
          <td><?= e(money($o['total'])) ?></td>
          <td><span class="pill <?= e($o['status']) ?>"><?= e(order_statuses()[$o['status']] ?? $o['status']) ?></span></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </section>

  <section class="panel">
    <div class="panel-head">
      <h2>Low-Stock Products</h2>
      <a class="btn small" href="<?= e(url('admin/products.php')) ?>">Manage stock &rarr;</a>
    </div>
    <?php if (!$low): ?>
      <p class="muted">All products are well stocked.</p>
    <?php else: ?>
    <ul class="mini-items">
      <?php foreach ($low as $l): ?>
        <li>
          <span><?= e($l['name']) ?></span>
          <b class="<?= $l['stock'] < 1 ? 'bad' : '' ?>"><?= (int)$l['stock'] ?></b>
          <a class="btn small" href="<?= e(url('admin/product_form.php?id=' . $l['id'])) ?>">Restock</a>
        </li>
      <?php endforeach; ?>
    </ul>
    <?php endif; ?>
  </section>
</div>

<?php require __DIR__ . '/_bottom.php'; ?>
