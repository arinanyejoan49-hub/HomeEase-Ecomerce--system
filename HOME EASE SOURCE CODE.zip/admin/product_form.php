<?php
$adminTitle = 'Product';
require __DIR__ . '/_top.php';

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$cats = q('SELECT * FROM categories ORDER BY sort_order')->fetchAll();
$p = ['name' => '', 'brand' => '', 'category_id' => $cats[0]['id'] ?? 1, 'description' => '', 'specs' => '', 'price' => '', 'old_price' => '', 'stock' => 0,
      'energy_rating' => '', 'warranty_months' => 12, 'image' => '', 'is_featured' => 0, 'is_active' => 1];
if ($id) {
    $row = q('SELECT * FROM products WHERE id = ?', [$id])->fetch();
    if (!$row) { flash('error', 'Product not found.'); redirect('admin/products.php'); }
    $p = $row;
}
$oldImage = (string)$p['image'];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $p['name'] = post('name', 160);
    $p['brand'] = post('brand', 80);
    $p['category_id'] = (int)($_POST['category_id'] ?? 0);
    $p['description'] = post('description', 3000);
    $p['specs'] = post('specs', 2000);
    $p['price'] = (int)($_POST['price'] ?? 0);
    $oldp = trim((string)($_POST['old_price'] ?? ''));
    $p['old_price'] = $oldp === '' ? null : (int)$oldp;
    $p['stock'] = (int)($_POST['stock'] ?? 0);
    $p['energy_rating'] = post('energy_rating', 4);
    $p['warranty_months'] = max(0, (int)($_POST['warranty_months'] ?? 12));
    $p['is_featured'] = isset($_POST['is_featured']) ? 1 : 0;
    $p['is_active'] = isset($_POST['is_active']) ? 1 : 0;

    if ($p['name'] === '') { $errors[] = 'Name is required.'; }
    if ($p['price'] < 1) { $errors[] = 'Price must be greater than 0.'; }
    if ($p['old_price'] !== null && $p['old_price'] <= $p['price']) { $errors[] = 'Old price must be higher than the price (or leave it empty).'; }
    if ($p['stock'] < 0) { $errors[] = 'Stock cannot be negative.'; }
    if (!q('SELECT 1 FROM categories WHERE id = ?', [$p['category_id']])->fetch()) { $errors[] = 'Choose a valid category.'; }

    // Image upload: strict type, size and content checks; saved under a random name.
    $newImage = '';
    if (!empty($_FILES['image']['name']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
        $f = $_FILES['image'];
        if ($f['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'Image upload failed.';
        } elseif ($f['size'] > 2 * 1024 * 1024) {
            $errors[] = 'Image must be 2 MB or smaller.';
        } else {
            $info = @getimagesize($f['tmp_name']);
            $allowed = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'];
            if (!$info || !isset($allowed[$info[2]])) {
                $errors[] = 'Only JPG, PNG or WebP images are allowed.';
            } else {
                do {
                    $newImage = bin2hex(random_bytes(16)) . '.' . $allowed[$info[2]];
                } while (file_exists(__DIR__ . '/../assets/uploads/' . $newImage));
            }
        }
    }

    if (!$errors) {
        if ($newImage !== '') {
            if (!move_uploaded_file($_FILES['image']['tmp_name'], __DIR__ . '/../assets/uploads/' . $newImage)) {
                $errors[] = 'Could not save the image. Check that assets/uploads is writable.';
            } else {
                $p['image'] = $newImage;
            }
        }
    }
    if (!$errors) {
        $fields = [$p['category_id'], $p['name'], $p['brand'], $p['description'], $p['specs'], $p['price'], $p['old_price'], $p['stock'], $p['energy_rating'], $p['warranty_months'], $p['image'], $p['is_featured'], $p['is_active']];
        if ($id) {
            q('UPDATE products SET category_id=?, name=?, brand=?, description=?, specs=?, price=?, old_price=?, stock=?, energy_rating=?, warranty_months=?, image=?, is_featured=?, is_active=? WHERE id=?', array_merge($fields, [$id]));
            flash('success', 'Product updated.');
        } else {
            $slug = slugify($p['name']);
            $n = 1; $base = $slug;
            while (q('SELECT 1 FROM products WHERE slug = ?', [$slug])->fetch()) { $slug = $base . '-' . (++$n); }
            q('INSERT INTO products (category_id, name, brand, description, specs, price, old_price, stock, energy_rating, warranty_months, image, is_featured, is_active, slug) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)', array_merge($fields, [$slug]));
            flash('success', 'Product added.');
        }
        if ($newImage !== '' && $oldImage !== '' && basename($oldImage) === $oldImage) {
            $oldUpload = __DIR__ . '/../assets/uploads/' . $oldImage;
            if (is_file($oldUpload) && !unlink($oldUpload)) {
                error_log('HomeEase could not remove a replaced product image upload.');
            }
        }
        redirect('admin/products.php');
    }
}
?>
<h1><?= $id ? 'Edit product' : 'Add product' ?></h1>
<?php if ($errors): ?><div class="alert error" role="alert"><ul><?php foreach ($errors as $er): ?><li><?= e($er) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<form method="post" enctype="multipart/form-data" class="panel form-grid" action="<?= e(url('admin/product_form.php' . ($id ? '?id=' . $id : ''))) ?>">
  <?= csrf_field() ?>
  <input type="hidden" name="id" value="<?= (int)$id ?>">
  <label>Name <input name="name" required maxlength="160" value="<?= e($p['name']) ?>"></label>
  <label>Brand <input name="brand" maxlength="80" value="<?= e($p['brand']) ?>"></label>
  <label>Category
    <select name="category_id"><?php foreach ($cats as $c): ?><option value="<?= (int)$c['id'] ?>" <?= (int)$p['category_id'] === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select>
  </label>
  <label>Price (UGX) <input type="number" name="price" min="1" required value="<?= e($p['price']) ?>"></label>
  <label>Old price (UGX, optional) <input type="number" name="old_price" min="1" value="<?= e($p['old_price'] ?? '') ?>"></label>
  <label>Stock <input type="number" name="stock" min="0" required value="<?= e($p['stock']) ?>"></label>
  <label>Energy rating (A+, A, B…) <input name="energy_rating" maxlength="4" value="<?= e($p['energy_rating']) ?>"></label>
  <label>Warranty (months) <input type="number" name="warranty_months" min="0" value="<?= e($p['warranty_months']) ?>"></label>
  <label class="full">Description <textarea name="description" rows="4"><?= e($p['description']) ?></textarea></label>
  <label class="full">Specifications (one per line, as <code>Label: value</code>) <textarea name="specs" rows="5"><?= e($p['specs']) ?></textarea></label>
  <label class="full">Image (JPG, PNG or WebP, max 2 MB)
    <input type="file" name="image" accept="image/jpeg,image/png,image/webp">
    <small class="muted">Current image: <?= e($p['image'] ?: 'matched automatically from product name') ?>. Upload a new file to replace it.</small>
    <span class="product-preview"><?= product_media($p) ?></span>
  </label>
  <label class="check"><input type="checkbox" name="is_featured" <?= $p['is_featured'] ? 'checked' : '' ?>> Featured on home page</label>
  <label class="check"><input type="checkbox" name="is_active" <?= $p['is_active'] ? 'checked' : '' ?>> Visible in shop</label>
  <div class="full"><button class="btn" type="submit">Save product</button> <a class="btn ghost" href="<?= e(url('admin/products.php')) ?>">Cancel</a></div>
</form>
<?php require __DIR__ . '/_bottom.php'; ?>
