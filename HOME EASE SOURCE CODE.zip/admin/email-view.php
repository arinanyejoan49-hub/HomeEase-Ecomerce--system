<?php
$adminTitle = 'Read email';
require __DIR__ . '/_top.php';
require_once __DIR__ . '/../includes/email.php';

$id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
$source = is_string($_GET['source'] ?? null) ? $_GET['source'] : '';
if (!$id || !in_array($source, ['website', 'email'], true)) {
    flash('error', 'Message not found.');
    redirect('admin/email-inbox.php');
}
if ($source === 'website') {
    $customerColumn = column_exists('messages', 'customer_id') ? 'customer_id' : 'NULL AS customer_id';
    $message = q('SELECT id, name AS sender_name, email AS sender_email, subject, message AS body, ' . $customerColumn . ',
                         created_at, status, NULL AS provider_message_id
                  FROM messages WHERE id = ?', [$id])->fetch();
    if ($message && $message['status'] === 'new') {
        q("UPDATE messages SET status = 'read' WHERE id = ?", [$id]);
        email_audit('read', $source, $id);
    }
    $conversation = $message
        ? q("SELECT * FROM email_messages WHERE contact_message_id = ? AND direction = 'outgoing' ORDER BY created_at", [$id])->fetchAll()
        : [];
} else {
    $message = q("SELECT id, sender_name, sender_email, recipient_email, subject, body,
                         created_at, status, is_read, has_attachments, provider_message_id, rfc_message_id, in_reply_to
                  FROM email_messages WHERE id = ? AND direction = 'incoming'", [$id])->fetch();
    if ($message && !(int)$message['is_read']) {
        q('UPDATE email_messages SET is_read = 1 WHERE id = ?', [$id]);
        email_audit('read', $source, $id);
    }
    $conversation = [];
    if ($message && $message['rfc_message_id']) {
        $conversation = q("SELECT * FROM email_messages
            WHERE direction = 'outgoing' AND in_reply_to = ?
            ORDER BY created_at", [$message['rfc_message_id']])->fetchAll();
    }
}
if (!$message) {
    flash('error', 'Message not found.');
    redirect('admin/email-inbox.php');
}
$replyHref = url('admin/email-compose.php?reply_source=' . $source . '&reply_id=' . (int)$id);
?>
<div class="section-head"><div><h1><?= e($message['subject']) ?></h1><p class="muted"><?= $source === 'website' ? 'Website enquiry' : 'Received from business mailbox' ?></p></div><a class="btn ghost" href="<?= e(url('admin/email-inbox.php')) ?>">Back to inbox</a></div>
<article class="panel email-reader">
  <div class="email-reader-meta">
    <div><strong><?= e($message['sender_name'] ?: $message['sender_email']) ?></strong><br><a href="mailto:<?= e($message['sender_email']) ?>"><?= e($message['sender_email']) ?></a></div>
    <time datetime="<?= e(date(DATE_ATOM, strtotime($message['created_at']))) ?>"><?= e(date('j M Y, H:i', strtotime($message['created_at']))) ?></time>
  </div>
  <?php if ($source === 'website'): ?><p class="email-source-note"><?= !empty($message['customer_id']) ? 'This message was sent from a signed-in customer account. Replies also appear in that customer’s dashboard.' : 'This message was submitted through the HomeEase website contact form. It was not retrieved from an external email inbox.' ?></p><?php endif; ?>
  <?php if ($source === 'email' && !empty($message['has_attachments'])): ?><p class="email-source-note">This email included attachment(s). Attachments are not downloaded or opened by this system.</p><?php endif; ?>
  <div class="email-body"><?= nl2br(e($message['body'])) ?></div>
  <div class="email-reader-actions">
    <a class="btn" href="<?= e($replyHref) ?>">Reply</a>
    <a class="btn ghost" href="<?= e(url('admin/email-compose.php?forward_source=' . $source . '&forward_id=' . (int)$id)) ?>">Forward</a>
  </div>
</article>
<?php if ($conversation): ?>
  <h2>Conversation history</h2>
  <?php foreach ($conversation as $reply): ?>
    <article class="panel email-reader">
      <div class="email-reader-meta"><div><strong><?= e($reply['sender_name'] ?: EMAIL_FROM_NAME) ?></strong> → <?= e($reply['recipient_email']) ?><br><span class="muted">Sent to mail server · <?= e($reply['status']) ?></span></div><time><?= e(date('j M Y, H:i', strtotime($reply['created_at']))) ?></time></div>
      <h3><?= e($reply['subject']) ?></h3>
      <div class="email-body"><?= nl2br(e($reply['body'])) ?></div>
    </article>
  <?php endforeach; ?>
<?php endif; ?>
<?php require __DIR__ . '/_bottom.php'; ?>
