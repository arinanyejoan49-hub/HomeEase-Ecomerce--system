<?php
$adminTitle = 'Customer Details';
require __DIR__ . '/_top.php';

if (!table_exists('users')) {
    flash('error', 'Customer account tables are missing. Import database.sql in phpMyAdmin before managing customer accounts.');
    redirect('admin/customers.php');
}

$id = (int)($_GET['id'] ?? 0);
$user = q('SELECT * FROM users WHERE id = ?', [$id])->fetch();
if (!$user) {
    flash('error', 'Customer not found.');
    redirect('admin/customers.php');
}

$orderCount = (int)q('SELECT COUNT(*) FROM orders WHERE email = ?', [$user['email']])->fetchColumn();
$totalSpent = (int)q('SELECT COALESCE(SUM(total),0) FROM orders WHERE email = ? AND status <> "cancelled"', [$user['email']])->fetchColumn();
$recentOrders = q('SELECT order_no, total, status, created_at FROM orders WHERE email = ? ORDER BY created_at DESC LIMIT 5', [$user['email']])->fetchAll();
?>
<h1>Customer Details</h1>
<p><?= e($user['first_name'] . ' ' . $user['last_name']) ?></p>
<p><a class="btn small" href="<?= e(url('admin/customer-form.php?id=' . (int)$user['id'])) ?>">Edit customer</a></p>

<div class="two-col">
  <section class="panel">
    <h2>Profile</h2>
    <table class="data">
      <tbody>
        <tr><td style="width:30%"><b>ID</b></td><td><?= (int)$user['id'] ?></td></tr>
        <tr><td><b>Name</b></td><td><?= e($user['first_name'] . ' ' . $user['last_name']) ?></td></tr>
        <tr><td><b>Username</b></td><td><?= e($user['username']) ?></td></tr>
        <tr><td><b>Email</b></td><td><a href="mailto:<?= e($user['email']) ?>"><?= e($user['email']) ?></a></td></tr>
        <tr><td><b>Phone</b></td><td><?= e($user['phone']) ?></td></tr>
        <tr><td><b>Country</b></td><td><?= e($user['country']) ?></td></tr>
        <tr><td><b>District / City</b></td><td><?= e($user['district'] ?? '-') ?></td></tr>
        <tr><td><b>Delivery Address</b></td><td><?= e($user['address'] ?? '-') ?></td></tr>
        <tr><td><b>Role</b></td><td><?= e(ucfirst($user['role'])) ?></td></tr>
        <tr><td><b>Status</b></td><td><span class="pill <?= $user['status'] ?>"><?= ucfirst($user['status']) ?></span></td></tr>
        <tr><td><b>Joined</b></td><td><?= e(date('j M Y, H:i', strtotime($user['created_at']))) ?></td></tr>
        <tr><td><b>Last Updated</b></td><td><?= e(date('j M Y, H:i', strtotime($user['updated_at']))) ?></td></tr>
      </tbody>
    </table>
  </section>

  <section class="panel">
    <h2>Orders (<?= $orderCount ?>)</h2>
    <p>Total spent: <?= e(money($totalSpent)) ?></p>
    <?php if (!$recentOrders): ?>
      <p class="muted">No orders yet.</p>
    <?php else: ?>
    <table class="data">
      <thead><tr><th>Order</th><th>Total</th><th>Status</th><th>Date</th></tr></thead>
      <tbody>
      <?php foreach ($recentOrders as $o): ?>
        <tr>
          <td><a href="<?= e(url('admin/order.php?id=' . (int)q('SELECT id FROM orders WHERE order_no = ?', [$o['order_no']])->fetchColumn() ?? 0)) ?>"><?= e($o['order_no']) ?></a></td>
          <td><?= e(money($o['total'])) ?></td>
          <td><span class="pill <?= $o['status'] ?>"><?= ucfirst($o['status']) ?></span></td>
          <td><?= e(date('j M Y', strtotime($o['created_at']))) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </section>
</div>

<p>
  <a class="btn small" href="<?= e(url('admin/customers.php')) ?>">Back to customer list</a>
  <?php if ($user['status'] === 'active'): ?>
    <form method="post" action="<?= e(url('admin/toggle-customer.php')) ?>" class="inline" data-confirm="Suspend this account?">
      <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$user['id'] ?>"><input type="hidden" name="status" value="suspended">
      <button class="btn small danger" type="submit">Suspend Account</button>
    </form>
  <?php else: ?>
    <form method="post" action="<?= e(url('admin/toggle-customer.php')) ?>" class="inline" data-confirm="Reactivate this account?">
      <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$user['id'] ?>"><input type="hidden" name="status" value="active">
      <button class="btn small" type="submit">Activate Account</button>
    </form>
  <?php endif; ?>
</p>

<?php require __DIR__ . '/_bottom.php'; ?>