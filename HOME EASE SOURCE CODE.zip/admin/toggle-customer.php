<?php
$adminTitle = 'Update Customer Status';
require __DIR__ . '/_top.php';

if (!table_exists('users')) {
    flash('error', 'Customer account tables are missing. Import database.sql in phpMyAdmin before managing customer accounts.');
    redirect('admin/customers.php');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    flash('error', 'Customer status changes must be submitted from the admin panel.');
    redirect('admin/customers.php');
}

csrf_verify();
$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
$status = post('status', 20);
if (!$id || !in_array($status, ['active', 'suspended'], true)) {
    flash('error', 'Invalid customer status request.');
    redirect('admin/customers.php');
}

$user = q("SELECT id FROM users WHERE id = ? AND role = 'customer'", [$id])->fetch();
if (!$user) {
    flash('error', 'Customer not found.');
    redirect('admin/customers.php');
}

q('UPDATE users SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', [$status, $id]);
flash('success', 'Customer status updated to ' . ucfirst($status) . '.');
redirect('admin/customers.php');
