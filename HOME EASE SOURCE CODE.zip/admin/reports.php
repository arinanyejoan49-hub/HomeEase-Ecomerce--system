<?php
$adminTitle = 'Reports';
require __DIR__ . '/_top.php';

$from = is_string($_GET['from'] ?? '') ? ($_GET['from'] ?? '') : '';
$to = is_string($_GET['to'] ?? '') ? ($_GET['to'] ?? '') : '';
if ($from === '') { $from = date('Y-m-01'); }
if ($to === '') { $to = date('Y-m-d'); }

// Daily sales
$daily = q("SELECT DATE(created_at) AS d, COUNT(*) AS orders, COALESCE(SUM(total),0) AS sales
            FROM orders WHERE status <> 'cancelled' AND DATE(created_at) BETWEEN ? AND ?
            GROUP BY DATE(created_at) ORDER BY d", [$from, $to])->fetchAll();

$totals = q("SELECT COUNT(*) AS orders, COALESCE(SUM(total),0) AS sales, COALESCE(SUM(CASE WHEN payment_status LIKE 'paid%' THEN total ELSE 0 END),0) AS paid
             FROM orders WHERE status <> 'cancelled' AND DATE(created_at) BETWEEN ? AND ?", [$from, $to])->fetch();

$best = q("SELECT oi.name, SUM(oi.qty) AS qty, SUM(oi.price*oi.qty) AS rev
           FROM order_items oi JOIN orders o ON o.id = oi.order_id
           WHERE o.status <> 'cancelled' AND DATE(o.created_at) BETWEEN ? AND ?
           GROUP BY oi.name ORDER BY qty DESC LIMIT 10", [$from, $to])->fetchAll();

$byStatus = q("SELECT status, COUNT(*) AS c FROM orders WHERE DATE(created_at) BETWEEN ? AND ? GROUP BY status", [$from, $to])->fetchAll();

$low = q('SELECT name, stock FROM products WHERE is_active = 1 AND stock <= 5 ORDER BY stock, name')->fetchAll();
$out = q('SELECT name, stock FROM products WHERE is_active = 1 AND stock = 0 ORDER BY name')->fetchAll();

$customers = table_exists('users') ? (int)q("SELECT COUNT(*) FROM users WHERE role='customer' AND DATE(created_at) BETWEEN ? AND ?", [$from, $to])->fetchColumn() : 0;

// CSV export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="sales-report.csv"');
    $outf = fopen('php://output', 'w');
    fputcsv($outf, ['Date', 'Orders', 'Sales (UGX)']);
    foreach ($daily as $d) { fputcsv($outf, [$d['d'], $d['orders'], $d['sales']]); }
    fputcsv($outf, []);
    fputcsv($outf, ['Total orders', $totals['orders']]);
    fputcsv($outf, ['Total sales', $totals['sales']]);
    fputcsv($outf, ['Paid (received)', $totals['paid']]);
    fclose($outf);
    exit;
}
?>
<h1>Reports & analytics</h1>
<form method="get" class="panel" style="margin-bottom:18px; display:flex; gap:12px; flex-wrap:wrap; align-items:end;">
  <label>From <input type="date" name="from" value="<?= e($from) ?>"></label>
  <label>To <input type="date" name="to" value="<?= e($to) ?>"></label>
  <button class="btn" type="submit">Apply</button>
  <a class="btn small ghost" href="<?= e(url('admin/reports.php?from=' . urlencode($from) . '&to=' . urlencode($to) . '&export=csv')) ?>">Export CSV</a>
</form>

<div class="stat-grid" style="margin-bottom:18px;">
  <div class="stat orders"><div class="stat-body"><span>Orders</span><b><?= (int)$totals['orders'] ?></b></div></div>
  <div class="stat products"><div class="stat-body"><span>Gross sales</span><b><?= e(money($totals['sales'])) ?></b></div></div>
  <div class="stat customers"><div class="stat-body"><span>Paid (received)</span><b><?= e(money($totals['paid'])) ?></b></div></div>
  <div class="stat"><div class="stat-body"><span>New customers</span><b><?= (int)$customers ?></b></div></div>
</div>

<div class="dashboard-grid">
  <section class="panel wide">
    <h2>Sales by day</h2>
    <?php if (!$daily): ?><p class="muted">No sales in this period.</p><?php else: ?>
    <div class="table-wrap">
    <table class="data">
      <thead><tr><th>Date</th><th>Orders</th><th>Sales</th></tr></thead>
      <tbody>
      <?php foreach ($daily as $d): ?>
        <tr><td><?= e($d['d']) ?></td><td><?= (int)$d['orders'] ?></td><td><?= e(money($d['sales'])) ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
    <?php endif; ?>
  </section>
  <section class="panel">
    <h2>Orders by status</h2>
    <ul class="mini-items">
      <?php foreach ($byStatus as $s): ?>
        <li><span><?= e(order_statuses()[$s['status']] ?? $s['status']) ?></span><b><?= (int)$s['c'] ?></b></li>
      <?php endforeach; ?>
    </ul>
  </section>
</div>

<section class="panel" style="margin-top:18px;">
  <h2>Best-selling products</h2>
  <?php if (!$best): ?><p class="muted">No sales in this period.</p><?php else: ?>
  <div class="table-wrap">
  <table class="data">
    <thead><tr><th>Product</th><th>Qty sold</th><th>Revenue</th></tr></thead>
    <tbody>
    <?php foreach ($best as $b): ?>
      <tr><td><?= e($b['name']) ?></td><td><?= (int)$b['qty'] ?></td><td><?= e(money($b['rev'])) ?></td></tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>
</section>

<div class="dashboard-grid" style="margin-top:18px;">
  <section class="panel">
    <h2>Low-stock products</h2>
    <?php if (!$low): ?><p class="muted">None.</p><?php else: ?>
    <ul class="mini-items"><?php foreach ($low as $l): ?><li><span><?= e($l['name']) ?></span><b><?= (int)$l['stock'] ?></b></li><?php endforeach; ?></ul>
    <?php endif; ?>
  </section>
  <section class="panel">
    <h2>Out-of-stock products</h2>
    <?php if (!$out): ?><p class="muted">None.</p><?php else: ?>
    <ul class="mini-items"><?php foreach ($out as $o): ?><li><span><?= e($o['name']) ?></span><b>0</b></li><?php endforeach; ?></ul>
    <?php endif; ?>
  </section>
</div>

<?php require __DIR__ . '/_bottom.php'; ?>