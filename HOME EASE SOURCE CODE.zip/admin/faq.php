<?php
$adminTitle = 'FAQ';
require __DIR__ . '/_top.php';

if (!table_exists('faqs')) {
    q("CREATE TABLE IF NOT EXISTS faqs (
      id INT AUTO_INCREMENT PRIMARY KEY,
      question VARCHAR(255) NOT NULL,
      answer TEXT NOT NULL,
      sort_order INT NOT NULL DEFAULT 0,
      is_published TINYINT(1) NOT NULL DEFAULT 1,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    // seed defaults
    $defaults = [
        ['Are your appliances genuine?', 'Yes. We source from authorised distributors and every appliance comes with a manufacturer or store warranty of 12 to 24 months, stated on each product page.', 1],
        ['How long does delivery take?', 'Within Kampala 1 to 2 working days, Greater Kampala 2 to 3 days and upcountry 3 to 6 days. See the Delivery page for fees and details.', 2],
        ['What payment methods do you accept?', (pesajet_enabled() ? 'MTN or Airtel mobile money, or cash on delivery. For mobile money you approve a prompt sent to your phone.' : 'MTN or Airtel mobile money, card, or cash on delivery. Card and mobile-money payments are simulated; no real money is taken.'), 3],
        ['Can I return an item?', 'Yes. Faulty or wrong items can be returned within 7 days of delivery. Unused items in original packaging can be returned within 7 days for a refund or exchange minus delivery cost. See Returns & warranty.', 4],
        ['Do appliances work with Uganda power supply?', 'All items are rated for 220 to 240 V, 50 Hz, the Ugandan standard. We also sell surge-protected extensions and solar lamps for outages.', 5],
        ['Is there a student discount?', 'Yes. Use code STUDENT10 in your cart for 10% off. Our Student Starter Bundle is also reduced.', 6],
        ['Do you keep my card details?', 'No. Card details are checked and discarded. We keep only the last four digits for your receipt.', 7],
    ];
    foreach ($defaults as [$q,$a,$s]) {
        q('INSERT INTO faqs (question, answer, sort_order, is_published) VALUES (?,?,?,1)', [$q,$a,$s]);
    }
}

$editId = (int)($_GET['edit'] ?? $_POST['id'] ?? 0);
$qv = '';
$av = '';
$sortv = 0;
$pubv = 1;
if ($editId) {
    $row = q('SELECT * FROM faqs WHERE id = ?', [$editId])->fetch();
    if ($row) {
        $qv = $row['question'];
        $av = $row['answer'];
        $sortv = (int)$row['sort_order'];
        $pubv = (int)$row['is_published'];
    } else {
        $editId = 0;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = post('action', 20);
    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        q('DELETE FROM faqs WHERE id = ?', [$id]);
        flash('success', 'FAQ deleted.');
        redirect('admin/faq.php');
    }
    if ($action === 'toggle') {
        $id = (int)($_POST['id'] ?? 0);
        q('UPDATE faqs SET is_published = IF(is_published=1,0,1) WHERE id = ?', [$id]);
        redirect('admin/faq.php');
    }
    $qv = post('question', 255);
    $av = post('answer', 5000);
    $sortv = (int)($_POST['sort_order'] ?? 0);
    $pubv = isset($_POST['is_published']) ? 1 : 0;
    $id = (int)($_POST['id'] ?? 0);
    $errs = [];
    if ($qv === '') { $errs[] = 'Question is required.'; }
    if ($av === '') { $errs[] = 'Answer is required.'; }
    if (!$errs) {
        if ($id > 0) {
            q('UPDATE faqs SET question=?, answer=?, sort_order=?, is_published=? WHERE id=?', [$qv, $av, $sortv, $pubv, $id]);
            flash('success', 'FAQ updated.');
        } else {
            q('INSERT INTO faqs (question, answer, sort_order, is_published) VALUES (?,?,?,?)', [$qv, $av, $sortv, $pubv]);
            flash('success', 'FAQ added.');
        }
        redirect('admin/faq.php');
    } else {
        foreach ($errs as $er) { flash('error', $er); }
    }
}

$faqs = q('SELECT * FROM faqs ORDER BY sort_order, id')->fetchAll();
?>
<h1>FAQ management</h1>
<p>Manage frequently asked questions shown on the public FAQ page.</p>

<div class="panel" style="margin-bottom:18px;">
  <h2><?= $editId ? 'Edit FAQ' : 'Add FAQ' ?></h2>
  <form method="post" class="form-grid">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?= (int)$editId ?>">
    <label class="full">Question <input type="text" name="question" maxlength="255" required value="<?= e($qv) ?>"></label>
    <label class="full">Answer <textarea name="answer" rows="4" required><?= e($av) ?></textarea></label>
    <label>Sort order <input type="number" name="sort_order" value="<?= (int)$sortv ?>"></label>
    <label class="check"><input type="checkbox" name="is_published" <?= $pubv ? 'checked' : '' ?>> Published</label>
    <div class="full"><button class="btn" type="submit"><?= $editId ? 'Update' : 'Add' ?></button>
      <?php if ($editId): ?><a class="btn ghost" href="<?= e(url('admin/faq.php')) ?>">Cancel</a><?php endif; ?></div>
  </form>
</div>

<?php if (!$faqs): ?>
  <p class="empty">No FAQs yet.</p>
<?php else: ?>
<div class="table-wrap">
<table class="data">
  <thead><tr><th>#</th><th>Question</th><th>Status</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($faqs as $f): ?>
    <tr>
      <td><?= (int)$f['sort_order'] ?></td>
      <td><b><?= e($f['question']) ?></b><br><small class="muted"><?= e(mb_substr($f['answer'], 0, 80)) ?>…</small></td>
      <td><span class="pill <?= $f['is_published'] ? 'delivered' : 'cancelled' ?>"><?= $f['is_published'] ? 'Published' : 'Hidden' ?></span></td>
      <td>
        <a class="btn small" href="<?= e(url('admin/faq.php?edit=' . $f['id'])) ?>">Edit</a>
        <form method="post" class="inline" style="display:inline;">
          <?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$f['id'] ?>">
          <button class="btn small ghost" type="submit"><?= $f['is_published'] ? 'Hide' : 'Publish' ?></button>
        </form>
        <form method="post" class="inline" style="display:inline;" onsubmit="return confirm('Delete this FAQ?')">
          <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$f['id'] ?>">
          <button class="btn small danger" type="submit">Delete</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php endif; ?>

<?php require __DIR__ . '/_bottom.php'; ?>
