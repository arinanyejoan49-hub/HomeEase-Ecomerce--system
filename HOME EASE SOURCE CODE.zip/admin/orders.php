<?php
$adminTitle = 'Orders';
require __DIR__ . '/_top.php';
$filter = is_string($_GET['status'] ?? '') ? ($_GET['status'] ?? '') : '';
$sql = 'SELECT * FROM orders';
$params = [];
if (isset(order_statuses()[$filter])) { $sql .= ' WHERE status = ?'; $params[] = $filter; }
$orders = q($sql . ' ORDER BY id DESC LIMIT 200', $params)->fetchAll();
?>
<h1>Orders</h1>
<p class="chips">
  <a class="chip <?= $filter === '' ? 'on' : '' ?>" href="<?= e(url('admin/orders.php')) ?>">All</a>
  <?php foreach (order_statuses() as $k => $lbl): ?>
    <a class="chip <?= $filter === $k ? 'on' : '' ?>" href="<?= e(url('admin/orders.php?status=' . $k)) ?>"><?= e($lbl) ?></a>
  <?php endforeach; ?>
</p>
<?php if (!$orders): ?><p class="empty">No orders found.</p><?php else: ?>
<div class="table-wrap">
<table class="data">
  <thead><tr><th>Order</th><th>Date</th><th>Customer</th><th>Payment</th><th>Total</th><th>Status</th></tr></thead>
  <tbody>
  <?php foreach ($orders as $o): ?>
    <tr>
      <td><a href="<?= e(url('admin/order.php?id=' . $o['id'])) ?>"><?= e($o['order_no']) ?></a></td>
      <td><?= e(date('j M, H:i', strtotime($o['created_at']))) ?></td>
      <td><?= e($o['customer_name']) ?><br><small class="muted"><?= e($o['phone']) ?></small></td>
      <td><?= e($o['payment_method']) ?><br><small class="muted"><?= e(payment_status_label($o['payment_status'])) ?></small></td>
      <td><?= e(money($o['total'])) ?></td>
      <td><span class="pill <?= e($o['status']) ?>"><?= e(order_statuses()[$o['status']] ?? $o['status']) ?></span></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php endif; ?>
<?php require __DIR__ . '/_bottom.php'; ?>
