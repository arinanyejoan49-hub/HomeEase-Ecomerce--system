<?php
$adminTitle = 'Products';
require __DIR__ . '/_top.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $id = (int)($_POST['id'] ?? 0);
    $act = post('action', 12);
    if ($act === 'toggle') {
        q('UPDATE products SET is_active = 1 - is_active WHERE id = ?', [$id]);
        flash('success', 'Product visibility changed.');
    } elseif ($act === 'delete') {
        // Products already sold are kept in order history (order_items keeps its own copy of the name and price).
        $img = q('SELECT image FROM products WHERE id = ?', [$id])->fetchColumn();
        q('UPDATE order_items SET product_id = NULL WHERE product_id = ?', [$id]);
        q('DELETE FROM products WHERE id = ?', [$id]);
        if ($img && is_file(__DIR__ . '/../assets/uploads/' . basename($img))) {
            @unlink(__DIR__ . '/../assets/uploads/' . basename($img));
        }
        flash('success', 'Product deleted.');
    }
    redirect('admin/products.php');
}
$search = is_string($_GET['q'] ?? null) ? trim($_GET['q']) : '';
$categoryId = filter_var($_GET['category'] ?? '', FILTER_VALIDATE_INT);
$status = is_string($_GET['status'] ?? null) ? $_GET['status'] : 'all';
$categories = q('SELECT id, name FROM categories ORDER BY sort_order, name')->fetchAll();
$where = [];
$params = [];
if ($search !== '') {
    $where[] = '(p.name LIKE ? OR p.brand LIKE ?)';
    $like = '%' . $search . '%';
    array_push($params, $like, $like);
}
if ($categoryId !== false && $categoryId !== null && $categoryId > 0) {
    $where[] = 'p.category_id = ?';
    $params[] = $categoryId;
}
if ($status === 'visible' || $status === 'hidden') {
    $where[] = 'p.is_active = ?';
    $params[] = $status === 'visible' ? 1 : 0;
}
$sql = 'SELECT p.*, c.name AS cat FROM products p JOIN categories c ON c.id = p.category_id';
if ($where) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$products = q($sql . ' ORDER BY p.name', $params)->fetchAll();
?>
<div class="section-head"><h1>Products (<?= count($products) ?>)</h1><a class="btn" href="<?= e(url('admin/product_form.php')) ?>">+ Add product</a></div>
<form class="filters" method="get" action="<?= e(url('admin/products.php')) ?>" role="search">
  <label>Product name or brand
    <input type="search" name="q" value="<?= e($search) ?>" placeholder="Search products">
  </label>
  <label>Category
    <select name="category">
      <option value="">All categories</option>
      <?php foreach ($categories as $category): ?>
        <option value="<?= (int)$category['id'] ?>" <?= $categoryId === (int)$category['id'] ? 'selected' : '' ?>><?= e($category['name']) ?></option>
      <?php endforeach; ?>
    </select>
  </label>
  <label>Visibility
    <select name="status">
      <option value="all" <?= $status === 'all' ? 'selected' : '' ?>>All products</option>
      <option value="visible" <?= $status === 'visible' ? 'selected' : '' ?>>Visible</option>
      <option value="hidden" <?= $status === 'hidden' ? 'selected' : '' ?>>Hidden</option>
    </select>
  </label>
  <button class="btn small" type="submit">Filter</button>
  <a class="btn small ghost" href="<?= e(url('admin/products.php')) ?>">Reset</a>
</form>
<?php if (!$products): ?>
  <div class="empty"><p>No products match these filters.</p><a class="btn small ghost" href="<?= e(url('admin/products.php')) ?>">Clear filters</a></div>
<?php else: ?>
<div class="table-wrap">
<table class="data">
  <thead><tr><th>Image</th><th>ID</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($products as $p): ?>
    <tr class="<?= $p['is_active'] ? '' : 'dim' ?>">
      <td><?= product_media($p, 'admin-product-image') ?></td>
      <td><?= (int)$p['id'] ?></td>
      <td><?= e($p['name']) ?><br><small class="muted"><?= e($p['brand']) ?></small></td>
      <td><?= e($p['cat']) ?></td>
      <td><?= e(money($p['price'])) ?></td>
      <td class="<?= $p['stock'] <= 5 ? 'bad' : '' ?>"><?= (int)$p['stock'] ?></td>
      <td><?= $p['is_active'] ? 'Visible' : 'Hidden' ?></td>
      <td class="actions">
        <a class="btn small ghost" href="<?= e(url('admin/product_form.php?id=' . $p['id'])) ?>">Edit</a>
        <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><input type="hidden" name="action" value="toggle"><button class="btn small ghost" type="submit"><?= $p['is_active'] ? 'Hide' : 'Show' ?></button></form>
        <form method="post" class="inline" data-confirm="Delete this product permanently?"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><input type="hidden" name="action" value="delete"><button class="btn small danger" type="submit">Delete</button></form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php endif; ?>
<?php require __DIR__ . '/_bottom.php'; ?>
