<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_admin();
header('Cache-Control: no-store');

if (!table_exists('users')) {
    flash('error', 'Customer account tables are missing. Import database.sql before managing customer accounts.');
    redirect('admin/customers.php');
}

$id = max(0, (int)($_GET['id'] ?? $_POST['id'] ?? 0));
$isEdit = $id > 0;
$user = $isEdit
    ? q('SELECT * FROM users WHERE id = ? AND role = "customer"', [$id])->fetch()
    : null;

if ($isEdit && !$user) {
    flash('error', 'Customer not found.');
    redirect('admin/customers.php');
}

$adminTitle = $isEdit ? 'Edit Customer' : 'Add Customer';
$errors = [];
$values = $user ? [
    'first_name' => $user['first_name'],
    'last_name' => $user['last_name'],
    'username' => $user['username'],
    'email' => $user['email'],
    'phone' => $user['phone'],
    'gender' => $user['gender'] ?? '',
    'date_of_birth' => $user['date_of_birth'] ?? '',
    'country' => $user['country'] ?? 'Uganda',
    'district' => $user['district'] ?? '',
    'address' => $user['address'] ?? '',
    'status' => $user['status'],
] : [
    'first_name' => '',
    'last_name' => '',
    'username' => '',
    'email' => '',
    'phone' => '',
    'gender' => '',
    'date_of_birth' => '',
    'country' => 'Uganda',
    'district' => '',
    'address' => '',
    'status' => 'active',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    foreach (['first_name', 'last_name', 'username', 'email', 'phone', 'gender', 'date_of_birth', 'country', 'district', 'address'] as $field) {
        $input = $_POST[$field] ?? '';
        $values[$field] = is_string($input) ? trim($input) : '';
    }
    $values['email'] = mb_strtolower($values['email']);
    $statusInput = $_POST['status'] ?? '';
    $values['status'] = is_string($statusInput) && in_array($statusInput, ['active', 'suspended'], true)
        ? $statusInput
        : '';
    $passwordInput = $_POST['password'] ?? '';
    $password = is_string($passwordInput) ? $passwordInput : '';

    foreach (['first_name' => 'First name', 'last_name' => 'Last name'] as $field => $label) {
        if (mb_strlen($values[$field]) < 2 || mb_strlen($values[$field]) > 100) {
            $errors[$field] = $label . ' must be between 2 and 100 characters.';
        }
    }
    if (!preg_match('/^[a-zA-Z0-9_]{3,50}$/', $values['username'])) {
        $errors['username'] = 'Username must be 3-50 characters (letters, numbers, underscore only).';
    } elseif (q('SELECT 1 FROM users WHERE username = ? AND id <> ?', [$values['username'], $id])->fetch()) {
        $errors['username'] = 'This username is already in use.';
    }

    if (!filter_var($values['email'], FILTER_VALIDATE_EMAIL) || mb_strlen($values['email']) > 150) {
        $errors['email'] = 'Enter a valid email address (maximum 150 characters).';
    } elseif (q('SELECT 1 FROM users WHERE email = ? AND id <> ?', [$values['email'], $id])->fetch()
        || (table_exists('admins') && q('SELECT 1 FROM admins WHERE email = ?', [$values['email']])->fetch())) {
        $errors['email'] = 'This email address is already in use.';
    }
    if (!preg_match('/^\+?[0-9\s\-()]{7,20}$/', $values['phone'])) {
        $errors['phone'] = 'Enter a valid phone number.';
    }
    if (!in_array($values['gender'], ['', 'male', 'female', 'other', 'prefer_not_to_say'], true)) {
        $errors['gender'] = 'Select a valid gender.';
    }
    if ($values['date_of_birth'] !== '') {
        $date = DateTime::createFromFormat('!Y-m-d', $values['date_of_birth']);
        if (!$date || $date->format('Y-m-d') !== $values['date_of_birth'] || $date > new DateTime('today')) {
            $errors['date_of_birth'] = 'Enter a valid date of birth that is not in the future.';
        }
    }
    if ($values['country'] === '' || mb_strlen($values['country']) > 100) {
        $errors['country'] = 'Country is required and must be 100 characters or fewer.';
    }
    if (mb_strlen($values['district']) > 100) {
        $errors['district'] = 'District must be 100 characters or fewer.';
    }
    if (mb_strlen($values['address']) > 255) {
        $errors['address'] = 'Address must be 255 characters or fewer.';
    }
    if ($values['status'] === '') {
        $errors['status'] = 'Select a valid account status.';
    }
    if (!$isEdit || $password !== '') {
        if (strlen($password) < 8
            || !preg_match('/[A-Z]/', $password)
            || !preg_match('/[a-z]/', $password)
            || !preg_match('/[0-9]/', $password)) {
            $errors['password'] = 'Password must be at least 8 characters and contain uppercase, lowercase, and numeric characters.';
        }
    }

    if (!$errors) {
        try {
            if ($isEdit) {
                q(
                    'UPDATE users
                     SET first_name = ?, last_name = ?, username = ?, email = ?, phone = ?,
                         gender = ?, date_of_birth = ?, country = ?, district = ?, address = ?,
                         status = ?, updated_at = CURRENT_TIMESTAMP
                     WHERE id = ? AND role = "customer"',
                    [
                        $values['first_name'], $values['last_name'], $values['username'],
                        $values['email'], $values['phone'], $values['gender'] ?: null,
                        $values['date_of_birth'] ?: null, $values['country'],
                        $values['district'] ?: null, $values['address'] ?: null,
                        $values['status'], $id,
                    ]
                );
                if ($password !== '') {
                    q(
                        'UPDATE users SET password_hash = ?, remember_token = NULL, remember_expires = NULL WHERE id = ? AND role = "customer"',
                        [password_hash($password, PASSWORD_DEFAULT), $id]
                    );
                }
                flash('success', 'Customer account updated.');
            } else {
                q(
                    'INSERT INTO users
                     (first_name, last_name, username, email, phone, password_hash, gender, date_of_birth,
                      country, district, address, role, status, created_at, updated_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "customer", ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)',
                    [
                        $values['first_name'], $values['last_name'], $values['username'],
                        $values['email'], $values['phone'], password_hash($password, PASSWORD_DEFAULT),
                        $values['gender'] ?: null, $values['date_of_birth'] ?: null, $values['country'],
                        $values['district'] ?: null, $values['address'] ?: null, $values['status'],
                    ]
                );
                flash('success', 'Customer account created.');
            }
            redirect('admin/customers.php');
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                $errors['_general'] = 'That username or email address is already in use.';
            } else {
                error_log('Admin customer save failed: ' . $e->getMessage());
                $errors['_general'] = 'Could not save this customer. Please try again.';
            }
        }
    }
}
?>
<?php require __DIR__ . '/_top.php'; ?>
<h1><?= $isEdit ? 'Edit Customer' : 'Add Customer' ?></h1>
<p>Customer accounts only. This form cannot grant administrator access.</p>

<?php if (!empty($errors['_general'])): ?>
  <div class="alert error" role="alert"><?= e($errors['_general']) ?></div>
<?php endif; ?>

<form method="post" action="<?= e(url('admin/customer-form.php' . ($isEdit ? '?id=' . $id : ''))) ?>" class="panel narrow">
  <?= csrf_field() ?>
  <input type="hidden" name="id" value="<?= $id ?>">
  <div class="form-grid">
    <label>First name <input name="first_name" required maxlength="100" value="<?= e($values['first_name']) ?>" autocomplete="given-name"><?php if (isset($errors['first_name'])): ?><span class="field-error"><?= e($errors['first_name']) ?></span><?php endif; ?></label>
    <label>Last name <input name="last_name" required maxlength="100" value="<?= e($values['last_name']) ?>" autocomplete="family-name"><?php if (isset($errors['last_name'])): ?><span class="field-error"><?= e($errors['last_name']) ?></span><?php endif; ?></label>
    <label>Username <input name="username" required maxlength="50" value="<?= e($values['username']) ?>" autocomplete="username"><?php if (isset($errors['username'])): ?><span class="field-error"><?= e($errors['username']) ?></span><?php endif; ?></label>
    <label>Email <input type="email" name="email" required maxlength="150" value="<?= e($values['email']) ?>" autocomplete="email"><?php if (isset($errors['email'])): ?><span class="field-error"><?= e($errors['email']) ?></span><?php endif; ?></label>
    <label>Phone <input type="tel" name="phone" required maxlength="20" value="<?= e($values['phone']) ?>" autocomplete="tel"><?php if (isset($errors['phone'])): ?><span class="field-error"><?= e($errors['phone']) ?></span><?php endif; ?></label>
    <label>Account status
      <select name="status" required>
        <option value="active" <?= $values['status'] === 'active' ? 'selected' : '' ?>>Active</option>
        <option value="suspended" <?= $values['status'] === 'suspended' ? 'selected' : '' ?>>Suspended</option>
      </select>
      <?php if (isset($errors['status'])): ?><span class="field-error"><?= e($errors['status']) ?></span><?php endif; ?>
    </label>
    <label>Gender
      <select name="gender">
        <option value="">Prefer not to say</option>
        <?php foreach (['male' => 'Male', 'female' => 'Female', 'other' => 'Other', 'prefer_not_to_say' => 'Prefer not to say'] as $value => $label): ?>
          <option value="<?= e($value) ?>" <?= $values['gender'] === $value ? 'selected' : '' ?>><?= e($label) ?></option>
        <?php endforeach; ?>
      </select>
      <?php if (isset($errors['gender'])): ?><span class="field-error"><?= e($errors['gender']) ?></span><?php endif; ?>
    </label>
    <label>Date of birth <input type="date" name="date_of_birth" value="<?= e($values['date_of_birth']) ?>"><?php if (isset($errors['date_of_birth'])): ?><span class="field-error"><?= e($errors['date_of_birth']) ?></span><?php endif; ?></label>
    <label>Country <input name="country" required maxlength="100" value="<?= e($values['country']) ?>"><?php if (isset($errors['country'])): ?><span class="field-error"><?= e($errors['country']) ?></span><?php endif; ?></label>
    <label>District / city <input name="district" maxlength="100" value="<?= e($values['district']) ?>"><?php if (isset($errors['district'])): ?><span class="field-error"><?= e($errors['district']) ?></span><?php endif; ?></label>
    <label class="full">Address <input name="address" maxlength="255" value="<?= e($values['address']) ?>"><?php if (isset($errors['address'])): ?><span class="field-error"><?= e($errors['address']) ?></span><?php endif; ?></label>
    <label class="full">Password <?= $isEdit ? '(leave blank to keep the current password)' : '' ?>
      <input type="password" name="password" <?= $isEdit ? '' : 'required' ?> minlength="8" autocomplete="new-password">
      <?php if (isset($errors['password'])): ?><span class="field-error"><?= e($errors['password']) ?></span><?php endif; ?>
    </label>
  </div>
  <p class="form-actions">
    <button class="btn" type="submit"><?= $isEdit ? 'Save changes' : 'Create customer' ?></button>
    <a class="btn small ghost" href="<?= e(url('admin/customers.php')) ?>">Cancel</a>
  </p>
</form>
<?php require __DIR__ . '/_bottom.php'; ?>
