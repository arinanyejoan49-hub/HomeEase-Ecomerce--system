<?php
// Shared admin layout (top). Every admin page except login requires an authenticated admin.
require_once __DIR__ . '/../includes/bootstrap.php';
require_admin();
header('Cache-Control: no-store');
$adminPage = basename($_SERVER['SCRIPT_NAME'] ?? '');
$newMsgs = (int)q("SELECT COUNT(*) FROM messages WHERE status = 'new'")->fetchColumn();
$newExternalEmails = table_exists('email_messages')
    ? (int)q("SELECT COUNT(*) FROM email_messages WHERE direction = 'incoming' AND is_read = 0 AND status <> 'archived'")->fetchColumn()
    : 0;
$unreadEmailCount = $newMsgs + $newExternalEmails;
$pendingOrders = (int)q("SELECT COUNT(*) FROM orders WHERE status = 'pending'")->fetchColumn();
$openTickets = table_exists('support_tickets') ? (int)q("SELECT COUNT(*) FROM support_tickets WHERE status = 'open'")->fetchColumn() : 0;
$requestedReturns = table_exists('return_requests') ? (int)q("SELECT COUNT(*) FROM return_requests WHERE status = 'requested'")->fetchColumn() : 0;
ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e($adminTitle ?? 'Admin') ?> | <?= e(SITE_NAME) ?> Admin</title>
<link rel="stylesheet" href="<?= e(url('assets/css/style.css?v=' . filemtime(__DIR__ . '/../assets/css/style.css'))) ?>">
</head>
<body class="admin">
<header class="admin-bar">
  <div class="wrap">
    <div class="admin-brand">
      <svg width="20" height="20" fill="none" stroke="#e87924" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" aria-hidden="true"><path d="M3 10h18M3 14h18m-9-4v8m-7 0h18a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2z"/></svg>
      <strong><?= e(SITE_NAME) ?> Admin</strong>
    </div>
  </div>
</header>
<div class="admin-layout">
  <aside class="admin-sidebar">
    <div class="admin-brand mobile">
      <svg width="20" height="20" fill="none" stroke="#e87924" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" aria-hidden="true"><path d="M3 10h18M3 14h18m-9-4v8m-7 0h18a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2z"/></svg>
      <strong><?= e(SITE_NAME) ?> Admin</strong>
    </div>
    <nav>
      <a href="<?= e(url('admin/index.php')) ?>" class="<?= $adminPage === 'index.php' ? 'on' : '' ?>"><svg width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><path d="M9 9V3.5A2.5 2.5 0 0 1 12 1h7"/><circle cx="9" cy="19" r="2"/></svg> Dashboard</a>
      <a href="<?= e(url('admin/products.php')) ?>" class="<?= in_array($adminPage, ['products.php', 'product_form.php'], true) ? 'on' : '' ?>"><svg width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" aria-hidden="true"><line x1="21" y1="15" x2="3" y2="15"/><line x1="7" y1="10" x2="21" y2="10"/><line x1="3" y1="5" x2="21" y2="5"/><line x1="7" y1="15" x2="7" y2="15"/></svg> Products</a>
      <a href="<?= e(url('admin/inventory.php')) ?>" class="<?= $adminPage === 'inventory.php' ? 'on' : '' ?>"><svg width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" aria-hidden="true"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg> Inventory</a>
<a href="<?= e(url('admin/categories.php')) ?>" class="<?= $adminPage === 'categories.php' ? 'on' : '' ?>"><svg width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" aria-hidden="true"><path d="M20 13V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12m8 0V6m0 0l8 8-8-8m8 8H4m0 0l8-8"/></svg> Categories</a>
      <a href="<?= e(url('admin/orders.php')) ?>" class="<?= in_array($adminPage, ['orders.php', 'order.php'], true) ? 'on' : '' ?>"><svg width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" aria-hidden="true"><path d="M3 3v2l8 9V3L3 3z"/><path d="M19 3v2l-8 9V3l11-5z"/><path d="M22 18v2a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-2z"/></svg> Orders<?= $pendingOrders ? ' <span class="badge pending" style="font-size:.65rem; margin-left:6px;">' . $pendingOrders . '</span>' : '' ?></a>
      <a href="<?= e(url('admin/customers.php')) ?>" class="<?= in_array($adminPage, ['customers.php', 'customer-form.php', 'customer-details.php'], true) ? 'on' : '' ?>"><svg width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" aria-hidden="true"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M7 16.3A23.1 23.1 0 0 1 5 15c0-1.1.9-2 2-2 1 .1 2 .3 2.87 1M19 16v3m-1-1h6m-7-3v4m-7-3h6"/></svg> Customers</a>
      <a href="<?= e(url('admin/messages.php')) ?>" class="<?= $adminPage === 'messages.php' ? 'on' : '' ?>"><svg width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg> Enquiries<?= $newMsgs ? ' <span class="badge" style="background:#dbeafe; color:#1e40af; font-size:.65rem; margin-left:6px;">' . $newMsgs . '</span>' : '' ?></a>
      <a href="<?= e(url('admin/support.php')) ?>" class="<?= $adminPage === 'support.php' ? 'on' : '' ?>"><svg width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" aria-hidden="true"><path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8A8.5 8.5 0 0 1 8.7 3.9a8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8z"/></svg> Support<?= $openTickets ? ' <span class="badge pending" style="font-size:.65rem; margin-left:6px;">' . $openTickets . '</span>' : '' ?></a>
      <a href="<?= e(url('admin/returns.php')) ?>" class="<?= $adminPage === 'returns.php' ? 'on' : '' ?>"><svg width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" aria-hidden="true"><path d="M3 7v6h6"/><path d="M21 17a9 9 0 0 0-15-6.7L3 13"/><path d="M21 17v-6h-6"/></svg> Returns<?= $requestedReturns ? ' <span class="badge pending" style="font-size:.65rem; margin-left:6px;">' . $requestedReturns . '</span>' : '' ?></a>
      <a href="<?= e(url('admin/email.php')) ?>" class="<?= in_array($adminPage, ['email.php', 'email-inbox.php', 'email-view.php', 'email-compose.php', 'email-sent.php', 'email-settings.php'], true) ? 'on' : '' ?>"><svg width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg> Emails<?= $unreadEmailCount ? ' <span class="badge" style="background:#dbeafe; color:#1e40af; font-size:.65rem; margin-left:6px;">' . $unreadEmailCount . '</span>' : '' ?></a>
      <a href="<?= e(url('admin/reports.php')) ?>" class="<?= $adminPage === 'reports.php' ? 'on' : '' ?>"><svg width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" aria-hidden="true"><path d="M3 3v18h18"/><path d="M7 16l4-6 4 4 4-8"/></svg> Reports</a>
<a href="<?= e(url('admin/payments.php')) ?>" class="<?= $adminPage === 'payments.php' ? 'on' : '' ?>"><svg width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" aria-hidden="true"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg> Payments</a>
<a href="<?= e(url('admin/calendar.php')) ?>" class="<?= $adminPage === 'calendar.php' ? 'on' : '' ?>"><svg width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg> Calendar</a>
      <a href="<?= e(url('admin/faq.php')) ?>" class="<?= $adminPage === 'faq.php' ? 'on' : '' ?>"><svg width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" aria-hidden="true"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg> FAQ</a>
      <a href="<?= e(url('admin/profile.php')) ?>" class="<?= $adminPage === 'profile.php' ? 'on' : '' ?>"><svg width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="18" y1="8" x2="23" y2="4"/><line x1="8" y1="1" x2="1" y2="1"/><line x1="1" y2="8" x2="8" y2="8"/></svg> Profile</a>
      <a href="<?= e(url('admin/account.php')) ?>" class="<?= $adminPage === 'account.php' ? 'on' : '' ?>"><svg width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 6v6m4 6v6m-4-6v6"/></svg> Account Settings</a>
      <a href="<?= e(url('index.php')) ?>" target="_blank"  rel="noopener"><svg width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" aria-hidden="true"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-.54-7.54l-4-4a5 5 0 0 0-7.54 7.54z"/><polyline points="15 11 11 15"/><path d="M18 20a5 5 0 0 0 7.54-.54l-3-3a5 5 0 0 0-.54-7.54l-4-4a5 5 0 0 0-7.54 7.54z"/></svg> View site ↗</a>
      <form method="post" action="<?= e(url('admin/logout.php')) ?>"><?= csrf_field() ?><button type="submit"><svg width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.6" aria-hidden="true"><path d="M22 10v-2a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2"/><path d="m15 7-3-3m3 3-3 3"/></svg> Log out</button></form>
    </nav>
  </aside>
  <main class="wrap admin-main">
<?php foreach (flashes() as [$type, $msg]): ?>
  <div class="alert <?= e($type) ?>" role="alert"><?= e($msg) ?></div>
<?php endforeach; ?>
