-- Link inbox and sent email records to customer accounts for private dashboard access.
-- Apply after add_email_management.sql; existing email records remain unchanged.
ALTER TABLE email_messages
  ADD COLUMN customer_id INT NULL AFTER contact_message_id,
  ADD INDEX idx_email_customer_created (customer_id, created_at),
  ADD CONSTRAINT fk_email_messages_customer
    FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE SET NULL;

UPDATE email_messages e
JOIN users u ON u.role = 'customer' AND LOWER(u.email) = LOWER(e.sender_email)
SET e.customer_id = u.id
WHERE e.direction = 'incoming' AND e.customer_id IS NULL;

UPDATE email_messages e
JOIN users u ON u.role = 'customer' AND LOWER(u.email) = LOWER(e.recipient_email)
SET e.customer_id = u.id
WHERE e.direction = 'outgoing' AND e.customer_id IS NULL;
