-- Add email inbox, sent-message, synchronization, and audit storage.
-- Safe to apply to an existing installation; existing enquiries are preserved.
CREATE TABLE IF NOT EXISTS email_messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  direction VARCHAR(12) NOT NULL,
  sender_email VARCHAR(160) NOT NULL,
  sender_name VARCHAR(120) NOT NULL DEFAULT '',
  recipient_email VARCHAR(160) NOT NULL,
  subject VARCHAR(255) NOT NULL,
  body TEXT NOT NULL,
  status VARCHAR(24) NOT NULL DEFAULT 'received',
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  has_attachments TINYINT(1) NOT NULL DEFAULT 0,
  contact_message_id INT NULL,
  admin_id INT NULL,
  provider_message_id VARCHAR(255) NULL,
  rfc_message_id VARCHAR(255) NULL,
  in_reply_to VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (contact_message_id) REFERENCES messages(id) ON DELETE SET NULL,
  FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE SET NULL,
  UNIQUE KEY uniq_email_provider_message (provider_message_id),
  INDEX idx_email_direction_created (direction, created_at),
  INDEX idx_email_contact_message (contact_message_id),
  INDEX idx_email_status_read (status, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS email_sync_state (
  id INT AUTO_INCREMENT PRIMARY KEY,
  mailbox VARCHAR(255) NOT NULL UNIQUE,
  last_uid BIGINT NOT NULL DEFAULT 0,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS email_audit_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  admin_id INT NULL,
  action VARCHAR(40) NOT NULL,
  message_source VARCHAR(12) NOT NULL DEFAULT '',
  message_id INT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE SET NULL,
  INDEX idx_email_audit_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
