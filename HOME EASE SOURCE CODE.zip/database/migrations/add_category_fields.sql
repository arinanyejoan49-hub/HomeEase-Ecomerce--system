-- Add description and image columns to categories (safe for existing installs)
ALTER TABLE categories ADD COLUMN IF NOT EXISTS description VARCHAR(255) NOT NULL DEFAULT '';
ALTER TABLE categories ADD COLUMN IF NOT EXISTS image VARCHAR(255) NULL;