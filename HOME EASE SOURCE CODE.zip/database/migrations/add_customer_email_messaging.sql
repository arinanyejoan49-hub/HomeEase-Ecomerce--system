-- Link authenticated customer dashboard messages to the customer account.
-- Apply once to an existing installation after customer accounts are installed.
ALTER TABLE messages
  ADD COLUMN customer_id INT NULL AFTER status,
  ADD INDEX idx_messages_customer_created (customer_id, created_at),
  ADD CONSTRAINT fk_messages_customer
    FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE SET NULL;
