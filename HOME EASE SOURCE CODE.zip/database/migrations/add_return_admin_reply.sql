-- Apply once to an existing MySQL/MariaDB database that already has return_requests.
-- Existing return requests are preserved and start with no administrator reply.
ALTER TABLE return_requests
  ADD COLUMN admin_reply TEXT NULL;
