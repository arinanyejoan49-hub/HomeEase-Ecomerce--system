</main>
<footer class="site-footer">
  <div class="wrap footer-grid">
    <div>
      <h3><?= e(SITE_NAME) ?></h3>
      <p>Affordable, genuine kitchen and home appliances for students and families across Uganda.</p>
      <p><svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M6.62 10.79c1.44-2.83 3.75-4.81 6.59-4.81 1.94 0 3.57 1.1 4.5 2.78.93-1.68 2.56-2.78 4.5-2.78 2.84 0 5.15 1.98 6.59 4.81L20 15H4zM12 17a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/></svg> <?= e(SITE_PHONE) ?><br><svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M22 6c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16l5-6-5-6v-6zM12 20a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm8-9h-2V5c0-1.1-.9-2-2-2h-4V3c0-1.1-.9-2-2-2H8c-1.1 0-2 .9-2 2v2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c-1.1 0-2-.9-2-2z"/></svg> <?= e(SITE_EMAIL) ?></p>
    </div>
    <div>
      <h3>Shop</h3>
      <?php foreach ($cats as $c): ?>
        <a href="<?= e(url('products.php?cat=' . $c['slug'])) ?>"><?= e($c['name']) ?></a>
      <?php endforeach; ?>
    </div>
    <div>
      <h3>Help</h3>
      <a href="<?= e(url('contact.php')) ?>">Contact us</a>
      <a href="<?= e(url('faq.php')) ?>">FAQ</a>
      <a href="<?= e(url('track.php')) ?>">Track your order</a>
      <a href="<?= e(url('delivery.php')) ?>">Delivery information</a>
      <a href="<?= e(url('returns.php')) ?>">Returns &amp; warranty</a>
    </div>
    <div>
      <h3>About</h3>
      <a href="<?= e(url('about.php')) ?>">About <?= e(SITE_NAME) ?></a>
      <a href="<?= e(url('sustainability.php')) ?>">Sustainability &amp; ethics</a>
      <a href="<?= e(url('privacy.php')) ?>">Privacy policy</a>
      <a href="<?= e(url('terms.php')) ?>">Terms &amp; conditions</a>
    </div>
  </div>
  <div class="wrap legal">
    <span>© <?= date('Y') ?> <?= e(SITE_NAME) ?>. All rights reserved.</span>
  </div>
</footer>

<?php if ($here === 'products.php'): ?>
<button class="back-to-top" type="button" aria-label="Back to top" title="Back to top" hidden>
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" aria-hidden="true"><path d="m18 15-6-6-6 6"/><path d="M12 9v12"/></svg>
</button>
<?php endif; ?>
<a class="wa-float" href="https://wa.me/<?= e(SITE_WHATSAPP) ?>?text=Hello%20<?= e(rawurlencode(SITE_NAME)) ?>%2C%20I%20need%20help%20with%20an%20appliance" target="_blank" rel="noopener" aria-label="Chat on WhatsApp"><svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M20.66 6.03c-1.83-1.83-4.19-2.83-6.65-2.83-2.55 0-4.94 1-6.8 2.86C5.27 7.29 4.27 9.67 2.95 12.16c-1.41 2.68-.24 5.79 2.05 7.6 1.28.99 2.77 1.45 4.33 1.45 1.77 0 3.48-.53 4.9-1.52l.19-.13c1.57-1.09 2.74-2.46 3.36-4.06.52-1.36.74-2.75.74-4.16 0-2.45-1-4.72-2.75-6.41l-.13-.19c-.99-1.42-1.45-3.13-1.52-4.9 0-1.56.46-3.05 1.45-4.33 1.81-2.29 4.9-3.46 7.6-2.05 2.49 1.32 4.87 2.32 7.16 2.93 1.86 1.86 2.86 4.25 2.86 6.8 0 2.46-1 4.82-2.83 6.65z"/></svg> <span>Chat</span></a>

<div id="consent" class="consent" hidden>
  <p>We use cookies for the cart and, if you agree, Google Analytics to understand how the site is used. See our <a href="<?= e(url('privacy.php')) ?>">privacy policy</a>.</p>
  <div><button type="button" class="btn small" data-consent="yes">Accept</button> <button type="button" class="btn small ghost" data-consent="no">Decline</button></div>
</div>
<nav class="bottom-nav">
  <a href="<?= e(url('index.php')) ?>" class="<?= $here === 'index.php' ? 'on' : '' ?>" aria-label="Home">
    <svg aria-hidden="true"><path d="M3 12l2-2m0 0l7-7 7 7M3 12v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V12z"/></svg>
    <span>Home</span>
  </a>
  <a href="<?= e(url('categories.php')) ?>" class="<?= $here === 'categories.php' ? 'on' : '' ?>" aria-label="Categories">
    <svg aria-hidden="true"><path d="M20 13V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12m8 0V6m0 0l8 8-8-8m8 8H4m0 0l8-8"/></svg>
    <span>Categories</span>
  </a>
  <a href="<?= e(url('cart.php')) ?>" class="<?= $here === 'cart.php' ? 'on' : '' ?>" aria-label="Cart">
    <svg aria-hidden="true"><circle cx="1" cy="5" r="1"/><circle cx="4" cy="5" r="1"/><path d="M5 19H2l1-3.5A2 2 0 0 1 4.5 15H18a2 2 0 0 1 1.61.85l1.78 3.57A2 2 0 0 1 20.83 21H6.12"/></svg>
    <span>Cart</span>
    <?php if ($cartN > 0): ?><span class="cart-badge" style="font-size:.62rem;"><?= (int)$cartN ?></span><?php endif; ?>
  </a>
  <a href="<?= e(url('wishlist.php')) ?>" class="<?= $here === 'wishlist.php' ? 'on' : '' ?>" aria-label="Wishlist">
    <svg aria-hidden="true"><path d="M19 14c1.49-1.46 3 3.21 3 5.5 0 5.5-9 9-9 9s-9-3.5-9-9c0-2.3 1.5-4.05 3-5.53L12 7l3 3.47z"/></svg>
    <span>Wishlist</span>
  </a>
  <?php if (is_customer()): ?>
    <a href="<?= e(url('customer/dashboard.php')) ?>" class="<?= $here === 'customer/dashboard.php' ? 'on' : '' ?>" aria-label="My Account">
      <svg aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 6v6m4 6v6m-4-6v6"/></svg>
      <span>Account</span>
    </a>
  <?php else: ?>
    <a href="<?= e(url('login.php')) ?>" class="<?= $here === 'login.php' ? 'on' : '' ?>" aria-label="Login">
      <svg aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 6v6m4 6v6m-4-6v6"/></svg>
      <span>Login</span>
    </a>
  <?php endif; ?>
</nav>
<script src="<?= e(url('assets/js/app.js?v=' . filemtime(__DIR__ . '/../assets/js/app.js'))) ?>"></script>
</body>
</html>
