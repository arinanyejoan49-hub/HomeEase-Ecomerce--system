<?php
// Usage: $title = 'Page title'; $desc = '...'; require 'includes/header.php';
$title = $title ?? SITE_NAME;
$desc = $desc ?? 'Affordable kitchen and home appliances for students and families in Uganda. Genuine warranty, fast Kampala delivery, pay with mobile money or on delivery.';
$cats = q('SELECT * FROM categories ORDER BY sort_order')->fetchAll();
$cartN = cart_count();
$here = basename($_SERVER['SCRIPT_NAME'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title === SITE_NAME ? SITE_NAME . ' | Affordable Home Appliances Uganda' : $title . ' | ' . SITE_NAME) ?></title>
<meta name="description" content="<?= e($desc) ?>">
<meta name="theme-color" content="#FF7900">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cpath d='M50 10 L90 90 L10 90 Z' fill='%23e87924'/%3E%3C/svg%3E">
<link rel="stylesheet" href="<?= e(url('assets/css/style.css?v=' . filemtime(__DIR__ . '/../assets/css/style.css'))) ?>">
</head>
<body class="<?= $here === 'login.php' ? 'login-shell' : '' ?>" data-ga="<?= e(GA_ID) ?>">
<a class="skip" href="#main">Skip to content</a>
<div class="topbar">
  <div class="wrap">
    <span><svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" style="vertical-align:-2px;"><path d="M21 10V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14l7-3.73 7 3.73V10c0-1.1.9-2 2-2z"/></svg> Free Kampala delivery over <?= e(money(FREE_DELIVERY_FROM)) ?></span>
    <span class="hide-sm"><svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" style="vertical-align:-2px;"><path d="M20 13H4v-2h16v2zm0-4H4v-2h16v2zm0-6v2H4V3h16z"/></svg> Students: use code <strong>STUDENT10</strong> for 10% off</span>
    <span><svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" style="vertical-align:-1px;"><path d="M6.62 10.79c1.44-2.83 3.75-4.81 6.59-4.81 1.94 0 3.57 1.1 4.5 2.78.93-1.68 2.56-2.78 4.5-2.78 2.84 0 5.15 1.98 6.59 4.81L20 15H4zM12 17a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/></svg> <?= e(SITE_PHONE) ?></span>
  </div>
</div>
<header class="site-header">
  <div class="wrap header-row">
    <a class="brand" href="<?= e(url('index.php')) ?>"><span class="logo"><svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg></span><?= e(SITE_NAME) ?></a>
    <form class="search" action="<?= e(url('products.php')) ?>" method="get" role="search">
      <label class="sr" for="q">Search products</label>
      <input id="q" type="search" name="q" placeholder="Search kettle, fridge, blender…" value="<?= e($_GET['q'] ?? '') ?>">
      <button type="submit" aria-label="Search"><svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 1 16 9.5 6.5 6.5 0 1 1 9.5 16c-1.61 0-3.09-.59-4.23-1.57l-.27-.28v-.79l5.49-5.49c1.39 1.39 3.16 1.39 4.55 0s1.39-3.16 0-4.55l-5.49-5.49v-.79l.27-.27A6.471 6.471 0 0 1 14.5 4c3.58 0 6.5 2.92 6.5 6.5 0 1.61-.59 3.09-1.57 4.23z"/></svg></button>
    </form>
    <a class="nav-icon" href="<?= e(url('wishlist.php')) ?>" aria-label="Wishlist"><svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg></a>
    <?php if (is_customer()): ?>
      <a class="nav-icon" href="<?= e(url('customer/dashboard.php')) ?>" aria-label="My Account"><svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M12 12c2.2 0 4-1.8 4-4s-1.8-4-4-4-4 1.8-4 4 1.8 4 4 4zm0 2c-2.6 0-5 1.4-5 4v2h10v-2c0-2.6-2.4-4-5-4z"/></svg></a>
    <?php else: ?>
      <a class="nav-icon" href="<?= e(url('login.php')) ?>" aria-label="Login"><svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M12 12c2.2 0 4-1.8 4-4s-1.8-4-4-4-4 1.8-4 4 1.8 4 4 4zm0 2c-2.6 0-5 1.4-5 4v2h10v-2c0-2.6-2.4-4-5-4z"/></svg></a>
    <?php endif; ?>
    <a class="cart-link" href="<?= e(url('cart.php')) ?>" aria-label="Cart, <?= $cartN ?> items"><svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><circle cx="1" cy="5" r="1"/><circle cx="4" cy="5" r="1"/><path d="M5 19H2l1-3.5A2 2 0 0 1 4.5 15H18a2 2 0 0 1 1.61.85l1.78 3.57A2 2 0 0 1 20.83 21H6.12"/></svg> <span>Cart</span><b class="cart-badge"><?= $cartN ?></b></a>
    <button class="menu-btn" type="button" aria-expanded="false" aria-controls="nav" aria-label="Menu"><svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M3 4h18v2H3V4zm0 7h18v2H3v-2zm0 7h18v2H3v-2z"/></svg></button>
  </div>
  <nav id="nav" class="main-nav" aria-label="Main">
    <div class="wrap">
      <a href="<?= e(url('index.php')) ?>" class="<?= $here === 'index.php' ? 'on' : '' ?>">Home</a>
      <a href="<?= e(url('categories.php')) ?>" class="<?= $here === 'categories.php' ? 'on' : '' ?>">Categories</a>
      <a href="<?= e(url('products.php')) ?>" class="<?= $here === 'products.php' && empty($_GET['cat']) ? 'on' : '' ?>">All products</a>
      <?php if (is_customer()): ?>
        <a href="<?= e(url('customer/dashboard.php')) ?>" class="<?= $here === 'customer/dashboard.php' ? 'on' : '' ?>">My Account</a>
        <a href="<?= e(url('logout.php')) ?>" class="<?= $here === 'logout.php' ? 'on' : '' ?>">Logout</a>
      <?php else: ?>
        <a href="<?= e(url('wishlist.php')) ?>" class="<?= $here === 'wishlist.php' ? 'on' : '' ?>">Wishlist</a>
        <a href="<?= e(url('login.php')) ?>" class="<?= $here === 'login.php' ? 'on' : '' ?>">Login</a>
      <?php endif; ?>
    </div>
  </nav>
</header>
<main id="main" class="wrap">
<?php foreach (flashes() as [$type, $msg]): ?>
  <div class="alert <?= e($type) ?>" role="alert"><?= e($msg) ?></div>
<?php endforeach; ?>
