<?php
declare(strict_types=1);

/**
 * PesaJet mobile-money integration (MTN / Airtel collections).
 *
 * Plain PHP + cURL, no Composer needed. Secrets live in config.local.php:
 *   define('PESAJET_API_KEY', 'pk_...');
 *   define('PESAJET_WEBHOOK_SECRET', 'whsec_...');
 * Based on PesaJet's official reference SDK (github.com/pesajet/pesajet-pay-demo).
 */

function pesajet_enabled(): bool
{
    return PESAJET_API_KEY !== '';
}

/** Call the PesaJet API. Returns decoded JSON or throws RuntimeException. */
function pesajet_request(string $method, string $path, ?array $body = null, array $headers = []): array
{
    $ch = curl_init(rtrim(PESAJET_BASE_URL, '/') . $path);
    $h = ['Content-Type: application/json', 'Accept: application/json', 'X-API-Key: ' . PESAJET_API_KEY];
    foreach ($headers as $k => $v) { $h[] = $k . ': ' . $v; }
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 25,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_HTTPHEADER => $h,
    ]);
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body ?? new stdClass()));
    }
    $resp = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);

    if ($resp === false) {
        throw new RuntimeException('PesaJet network error: ' . $err);
    }
    $data = json_decode((string)$resp, true);
    if ($code >= 400 || !is_array($data)) {
        $msg = is_array($data) ? ($data['error']['message'] ?? $data['message'] ?? '') : '';
        throw new RuntimeException('PesaJet HTTP ' . $code . ($msg !== '' ? ': ' . $msg : ''));
    }
    return $data;
}

/** Ask PesaJet to send a mobile-money prompt to the customer's phone. */
function pesajet_create_collection(array $order, string $phoneE164, string $network): array
{
    $params = [
        'amount' => (int)$order['total'],
        'currency' => 'UGX',
        'phoneNumber' => $phoneE164,
        'provider' => strtolower($network) === 'airtel' ? 'airtel' : 'mtn',
        'type' => 'COLLECTION',
        'reference' => $order['order_no'],
        'description' => SITE_NAME . ' order ' . $order['order_no'],
        'idempotencyKey' => $order['order_no'],
        'metadata' => ['orderId' => $order['order_no'], 'customerEmail' => $order['email']],
    ];
    return pesajet_request('POST', '/payments', $params, ['Idempotency-Key' => $order['order_no']]);
}

function pesajet_fetch(string $transactionId): array
{
    return pesajet_request('GET', '/payments/' . rawurlencode($transactionId));
}

/**
 * Verify X-Webhook-Signature (hex HMAC-SHA256). PesaJet's docs sign the raw body;
 * their PHP SDK re-encodes the JSON without the "signature" field, so accept both.
 */
function pesajet_verify_signature(string $rawBody, string $signature): bool
{
    if (PESAJET_WEBHOOK_SECRET === '' || $signature === '') {
        return false;
    }
    $sig = strtolower(trim($signature));
    if (hash_equals(hash_hmac('sha256', $rawBody, PESAJET_WEBHOOK_SECRET), $sig)) {
        return true;
    }
    $parsed = json_decode($rawBody, true);
    if (is_array($parsed)) {
        unset($parsed['signature']);
        $alt = hash_hmac('sha256', (string)json_encode($parsed, JSON_UNESCAPED_SLASHES), PESAJET_WEBHOOK_SECRET);
        return hash_equals($alt, $sig);
    }
    return false;
}

/** Cancel an unpaid order and return its items to stock. Only acts on 'awaiting payment'. */
function pesajet_fail_order(string $orderNo, string $paymentStatus): bool
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $upd = q("UPDATE orders SET payment_status = ?, status = 'cancelled' WHERE order_no = ? AND payment_status = 'awaiting payment'", [$paymentStatus, $orderNo]);
        if ($upd->rowCount() === 1) {
            $oid = (int)q('SELECT id FROM orders WHERE order_no = ?', [$orderNo])->fetchColumn();
            foreach (q('SELECT product_id, qty FROM order_items WHERE order_id = ?', [$oid])->fetchAll() as $it) {
                if ($it['product_id']) { q('UPDATE products SET stock = stock + ? WHERE id = ?', [$it['qty'], $it['product_id']]); }
            }
            $pdo->commit();
            return true;
        }
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) { $pdo->rollBack(); }
        error_log('pesajet_fail_order: ' . $e->getMessage());
    }
    return false;
}

/**
 * Apply a PesaJet transaction status to an order. Safe to call repeatedly (webhook retries, polling).
 * Returns: paid | failed | expired | pending | ignored | mismatch
 */
function pesajet_apply_status(string $orderNo, string $status, string $txnId = '', ?int $amount = null): string
{
    $order = q('SELECT id, total, payment_status, payment_ref, status FROM orders WHERE order_no = ? AND payment_method = ?', [$orderNo, 'momo'])->fetch();
    if (!$order) { return 'ignored'; }
    if ($txnId !== '' && $order['payment_ref'] !== '' && $order['payment_ref'] !== $txnId) {
        error_log("PesaJet: transaction mismatch on $orderNo ($txnId vs {$order['payment_ref']})");
        return 'mismatch';
    }

    switch (strtoupper($status)) {
        case 'COMPLETED':
            if ($amount !== null && $amount !== (int)$order['total']) {
                error_log("PesaJet: amount mismatch on $orderNo (paid $amount, expected {$order['total']})");
                return 'mismatch';
            }
            $upd = q("UPDATE orders SET payment_status = 'paid', status = CASE WHEN status = 'pending' THEN 'confirmed' ELSE status END, payment_ref = CASE WHEN payment_ref = '' THEN ? ELSE payment_ref END
                      WHERE order_no = ? AND payment_status IN ('awaiting payment','payment failed','payment expired')", [$txnId, $orderNo]);
            if ($upd->rowCount() === 1 && $order['status'] === 'cancelled') {
                error_log("PesaJet: order $orderNo was cancelled but a payment arrived. Review it in admin.");
            }
            return 'paid';
        case 'FAILED':
            pesajet_fail_order($orderNo, 'payment failed');
            return 'failed';
        case 'EXPIRED':
            pesajet_fail_order($orderNo, 'payment expired');
            return 'expired';
        default:
            return 'pending';
    }
}

/** Query PesaJet for the current state of an order's transaction and apply it. */
function pesajet_refresh_order(string $orderNo): string
{
    $o = q('SELECT payment_status, payment_ref FROM orders WHERE order_no = ? AND payment_method = ?', [$orderNo, 'momo'])->fetch();
    if (!$o || $o['payment_status'] !== 'awaiting payment' || $o['payment_ref'] === '') {
        return 'ignored';
    }
    try {
        $tx = pesajet_fetch($o['payment_ref']);
    } catch (Throwable $e) {
        error_log('pesajet_refresh_order: ' . $e->getMessage());
        return 'pending';
    }
    return pesajet_apply_status($orderNo, (string)($tx['status'] ?? ''), (string)($tx['transactionId'] ?? $o['payment_ref']), isset($tx['amount']) ? (int)$tx['amount'] : null);
}
