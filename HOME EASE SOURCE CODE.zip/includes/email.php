<?php

function email_mailer_available(): bool
{
    $autoload = __DIR__ . '/../vendor/autoload.php';
    if (is_file($autoload)) {
        require_once $autoload;
    }
    return class_exists(\PHPMailer\PHPMailer\PHPMailer::class);
}

function email_smtp_configured(): bool
{
    return email_smtp_status()['state'] === 'ready';
}

function email_secret_configured(string $secret): bool
{
    $secret = trim($secret);
    return $secret !== ''
        && preg_match('/^(?:your(?:[-_\s]|$)|<[^>]+>|change[-_\s]?me|placeholder)/i', $secret) !== 1;
}

function email_smtp_status(): array
{
    $missing = [];
    foreach ([
        'EMAIL_FROM_ADDRESS' => EMAIL_FROM_ADDRESS,
        'EMAIL_SMTP_HOST' => EMAIL_SMTP_HOST,
        'EMAIL_SMTP_USERNAME' => EMAIL_SMTP_USERNAME,
        'EMAIL_SMTP_PASSWORD' => EMAIL_SMTP_PASSWORD,
    ] as $setting => $value) {
        if ($setting === 'EMAIL_SMTP_PASSWORD'
            ? !email_secret_configured($value)
            : trim($value) === '') {
            $missing[] = $setting;
        }
    }
    if ($missing) {
        return ['state' => 'missing_settings', 'missing' => $missing];
    }
    if (filter_var(EMAIL_FROM_ADDRESS, FILTER_VALIDATE_EMAIL) === false
        || filter_var(EMAIL_SMTP_USERNAME, FILTER_VALIDATE_EMAIL) === false
        || filter_var(EMAIL_SMTP_HOST, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME) === false
        || (int)EMAIL_SMTP_PORT < 1 || (int)EMAIL_SMTP_PORT > 65535
        || !in_array(EMAIL_SMTP_ENCRYPTION, ['tls', 'ssl'], true)
        || (EMAIL_SMTP_CA_FILE !== '' && !is_readable(EMAIL_SMTP_CA_FILE))) {
        return ['state' => 'invalid_settings', 'missing' => []];
    }
    if (!email_mailer_available()) {
        return ['state' => 'mailer_unavailable', 'missing' => []];
    }
    return ['state' => 'ready', 'missing' => []];
}

function email_imap_configured(): bool
{
    return preg_match('/^[A-Za-z0-9.-]+$/', EMAIL_IMAP_HOST) === 1
        && (int)EMAIL_IMAP_PORT >= 1 && (int)EMAIL_IMAP_PORT <= 65535
        && in_array(EMAIL_IMAP_ENCRYPTION, ['ssl', 'tls'], true)
        && EMAIL_IMAP_USERNAME !== ''
        && email_secret_configured(EMAIL_IMAP_PASSWORD)
        && EMAIL_IMAP_MAILBOX !== '';
}

function email_smtp_failure_state(string $message): string
{
    return preg_match('/authentication|authenticat|credentials|username|password|535|5\.7\./i', $message) === 1
        ? 'authentication_failed'
        : 'connection_failed';
}

function email_audit(string $action, string $source = '', ?int $messageId = null): void
{
    q('INSERT INTO email_audit_log (admin_id, action, message_source, message_id) VALUES (?,?,?,?)', [
        (int)($_SESSION['admin_id'] ?? 0) ?: null,
        $action,
        $source,
        $messageId,
    ]);
}

function email_customer_id_for_address(string $address): ?int
{
    if (!filter_var($address, FILTER_VALIDATE_EMAIL)) {
        return null;
    }
    $customerId = q("SELECT id FROM users WHERE role = 'customer' AND LOWER(email) = LOWER(?) LIMIT 1", [$address])->fetchColumn();
    return $customerId === false ? null : (int)$customerId;
}

function send_store_email(string $recipient, string $recipientName, string $subject, string $body, ?string $replyTo = null, ?string $inReplyTo = null): array
{
    if (!filter_var($recipient, FILTER_VALIDATE_EMAIL)
        || ($replyTo !== null && !filter_var($replyTo, FILTER_VALIDATE_EMAIL))
        || preg_match('/[\r\n]/', $subject)) {
        return ['success' => false, 'state' => 'invalid_recipient', 'error' => 'Check the recipient address and subject.'];
    }
    $configuration = email_smtp_status();
    if ($configuration['state'] === 'missing_settings') {
        $missing = $configuration['missing'];
        $needsPassword = in_array('EMAIL_SMTP_PASSWORD', $missing, true);
        return [
            'success' => false,
            'state' => 'missing_settings',
            'error' => $needsPassword
                ? 'SMTP settings are incomplete. Add your Gmail app password as EMAIL_SMTP_PASSWORD in config.local.php.'
                : 'SMTP settings are incomplete. Check the required Gmail sender and server settings in config.local.php.',
        ];
    }
    if ($configuration['state'] === 'invalid_settings') {
        return ['success' => false, 'state' => 'invalid_settings', 'error' => 'SMTP settings are present but invalid. Check the sender address, host, port, and encryption mode.'];
    }
    if ($configuration['state'] === 'mailer_unavailable') {
        return ['success' => false, 'state' => 'mailer_unavailable', 'error' => 'SMTP settings are present, but PHPMailer is unavailable. Run Composer install in the project directory.'];
    }

    try {
        $mailer = new \PHPMailer\PHPMailer\PHPMailer(true);
        $mailer->isSMTP();
        $mailer->Host = EMAIL_SMTP_HOST;
        $mailer->Port = (int)EMAIL_SMTP_PORT;
        $mailer->SMTPAuth = true;
        $mailer->SMTPAutoTLS = false;
        $mailer->Username = EMAIL_SMTP_USERNAME;
        $mailer->Password = EMAIL_SMTP_PASSWORD;
        $mailer->SMTPSecure = EMAIL_SMTP_ENCRYPTION === 'ssl'
            ? \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS
            : \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $sslOptions = [
            'verify_peer' => true,
            'verify_peer_name' => true,
            'allow_self_signed' => false,
        ];
        if (EMAIL_SMTP_CA_FILE !== '') {
            $sslOptions['cafile'] = EMAIL_SMTP_CA_FILE;
        }
        $mailer->SMTPOptions = ['ssl' => $sslOptions];
        $mailer->Timeout = 15;
        $mailer->CharSet = 'UTF-8';
        $mailer->setFrom(EMAIL_FROM_ADDRESS, EMAIL_FROM_NAME);
        $mailer->addAddress($recipient, $recipientName);
        if ($replyTo !== null) {
            $mailer->addReplyTo($replyTo);
        }
        if ($inReplyTo !== null && preg_match('/^<[^<>\r\n]+>$/', $inReplyTo)) {
            $mailer->addCustomHeader('In-Reply-To', $inReplyTo);
            $mailer->addCustomHeader('References', $inReplyTo);
        }
        $mailer->Subject = $subject;
        $mailer->isHTML(false);
        $mailer->Body = $body;
        $mailer->send();
        return ['success' => true, 'state' => 'accepted', 'message_id' => $mailer->getLastMessageID()];
    } catch (Throwable $exception) {
        $technicalMessage = str_replace(
            [EMAIL_SMTP_PASSWORD, EMAIL_SMTP_USERNAME],
            ['[redacted]', '[redacted]'],
            $exception->getMessage()
        );
        error_log('HomeEase SMTP send failed (' . get_class($exception) . '): ' . $technicalMessage);
        $failureState = email_smtp_failure_state($exception->getMessage());
        return [
            'success' => false,
            'state' => $failureState,
            'error' => $failureState === 'authentication_failed'
                ? 'Gmail rejected SMTP authentication. Check the Gmail address and app password in config.local.php, and confirm 2-Step Verification is enabled.'
                : 'Could not connect securely to Gmail SMTP. Check the network, smtp.gmail.com, port 587, and TLS settings. Technical details are recorded in the server log.',
        ];
    }
}

function email_plain_body(string $body): string
{
    $body = html_entity_decode(strip_tags($body), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    return trim(preg_replace("/\r\n?/", "\n", $body) ?? '');
}

function email_decode_header(string $value): string
{
    if (!function_exists('imap_mime_header_decode')) {
        return $value;
    }
    $parts = imap_mime_header_decode($value);
    if (!is_array($parts)) {
        return $value;
    }
    $decoded = '';
    foreach ($parts as $part) {
        $charset = $part->charset !== 'default' ? $part->charset : 'UTF-8';
        $text = (string)$part->text;
        $decoded .= function_exists('iconv') ? (iconv($charset, 'UTF-8//IGNORE', $text) ?: $text) : $text;
    }
    return $decoded;
}

function email_imap_part_body($connection, int $messageNumber, object $part, string $partNumber = ''): array
{
    $attachments = !empty($part->disposition)
        && in_array(strtolower($part->disposition), ['attachment', 'inline'], true);
    if (($part->type ?? -1) === 0 && !$attachments) {
        $body = imap_fetchbody($connection, $messageNumber, $partNumber !== '' ? $partNumber : '1', FT_PEEK);
        $encoding = (int)($part->encoding ?? 0);
        if ($encoding === 3) {
            $body = base64_decode($body, true) ?: '';
        } elseif ($encoding === 4) {
            $body = quoted_printable_decode($body);
        }
        $charset = 'UTF-8';
        foreach (($part->parameters ?? []) as $parameter) {
            if (strtolower((string)$parameter->attribute) === 'charset') {
                $charset = (string)$parameter->value;
            }
        }
        if (function_exists('iconv')) {
            $body = iconv($charset, 'UTF-8//IGNORE', $body) ?: $body;
        }
        return ['body' => email_plain_body($body), 'attachments' => false];
    }

    $body = '';
    $hasAttachments = $attachments;
    foreach (($part->parts ?? []) as $index => $child) {
        $childNumber = $partNumber === '' ? (string)($index + 1) : $partNumber . '.' . ($index + 1);
        $result = email_imap_part_body($connection, $messageNumber, $child, $childNumber);
        if ($body === '' && $result['body'] !== '') {
            $body = $result['body'];
        }
        $hasAttachments = $hasAttachments || $result['attachments'];
    }
    return ['body' => $body, 'attachments' => $hasAttachments];
}

function email_imap_delivery_failure_references($connection, int $messageNumber, object $part, string $partNumber = '', bool $root = true): array
{
    $failed = false;
    $messageIds = [];
    $subtype = strtoupper((string)($part->subtype ?? ''));
    $sectionNumber = $partNumber !== '' ? $partNumber : '1';

    if ($subtype === 'DELIVERY-STATUS') {
        $report = imap_fetchbody($connection, $messageNumber, $sectionNumber, FT_PEEK);
        $report = is_string($report) ? $report : '';
        $encoding = (int)($part->encoding ?? 0);
        if ($encoding === 3) {
            $report = base64_decode($report, true) ?: '';
        } elseif ($encoding === 4) {
            $report = quoted_printable_decode($report);
        }
        $failed = preg_match('/^Action:\s*failed\s*$/im', $report) === 1;
        if ($failed && preg_match_all('/^Original-Message-ID:\s*(<[^<>\r\n]+>)/im', $report, $matches)) {
            $messageIds = $matches[1];
        }
    } elseif (($part->type ?? -1) === 2 && $subtype === 'RFC822') {
        $original = imap_fetchbody($connection, $messageNumber, $sectionNumber, FT_PEEK);
        $original = is_string($original) ? $original : '';
        if (preg_match('/^Message-ID:\s*(<[^<>\r\n]+>)/im', $original, $match)) {
            $messageIds[] = $match[1];
        }
    }

    foreach (($part->parts ?? []) as $index => $child) {
        $childNumber = $partNumber === '' ? (string)($index + 1) : $partNumber . '.' . ($index + 1);
        $childResult = email_imap_delivery_failure_references($connection, $messageNumber, $child, $childNumber, false);
        $failed = $failed || $childResult['failed'];
        $messageIds = array_merge($messageIds, $childResult['message_ids']);
    }

    return [
        'failed' => $failed,
        'message_ids' => $failed || !$root ? array_values(array_unique($messageIds)) : [],
    ];
}

function email_sync_imap_if_due(int $intervalSeconds = 60): array
{
    $encryption = EMAIL_IMAP_ENCRYPTION === 'ssl' ? '/imap/ssl' : '/imap/tls';
    $mailbox = '{' . EMAIL_IMAP_HOST . ':' . (int)EMAIL_IMAP_PORT . $encryption . '}' . EMAIL_IMAP_MAILBOX;
    $intervalSeconds = max(30, $intervalSeconds);
    $recentSyncSql = DB_DRIVER === 'sqlite'
        ? "SELECT updated_at >= datetime('now', '-{$intervalSeconds} seconds')
           FROM email_sync_state WHERE mailbox = ?"
        : "SELECT updated_at >= DATE_SUB(CURRENT_TIMESTAMP, INTERVAL {$intervalSeconds} SECOND)
           FROM email_sync_state WHERE mailbox = ?";
    if ((bool)q($recentSyncSql, [$mailbox])->fetchColumn()) {
        return ['success' => true, 'skipped' => true, 'added' => 0, 'delivery_failures' => 0];
    }

    return email_sync_imap();
}

function email_sync_imap(): array
{
    if (!email_imap_configured()) {
        return ['success' => false, 'error' => 'Incoming email is not configured in the protected local configuration.'];
    }
    if (!function_exists('imap_open')) {
        return ['success' => false, 'error' => 'The PHP IMAP extension is not enabled. Enable it in the active WAMP PHP configuration and restart Apache.'];
    }

    $encryption = EMAIL_IMAP_ENCRYPTION === 'ssl' ? '/imap/ssl' : '/imap/tls';
    $mailbox = '{' . EMAIL_IMAP_HOST . ':' . (int)EMAIL_IMAP_PORT . $encryption . '}' . EMAIL_IMAP_MAILBOX;
    imap_timeout(IMAP_OPENTIMEOUT, 10);
    imap_timeout(IMAP_READTIMEOUT, 15);
    imap_timeout(IMAP_WRITETIMEOUT, 15);
    $connection = @imap_open($mailbox, EMAIL_IMAP_USERNAME, EMAIL_IMAP_PASSWORD, OP_READONLY, 1);
    if (!$connection) {
        error_log('HomeEase IMAP connection failed: ' . imap_last_error());
        return ['success' => false, 'error' => 'Could not connect to the configured mailbox. Check its IMAP settings and server log.'];
    }

    try {
        $state = q('SELECT last_uid FROM email_sync_state WHERE mailbox = ?', [$mailbox])->fetchColumn();
        $lastUid = $state === false ? 0 : (int)$state;
        $uids = imap_search($connection, 'ALL', SE_UID) ?: [];
        sort($uids, SORT_NUMERIC);
        $uids = array_values(array_filter($uids, static function ($uid) use ($lastUid): bool {
            return (int)$uid > $lastUid;
        }));
        $added = 0;
        $deliveryFailures = 0;
        $largestUid = $lastUid;
        foreach (array_slice($uids, 0, 100) as $uid) {
            $uid = (int)$uid;
            $largestUid = max($largestUid, $uid);
            $messageNumber = imap_msgno($connection, $uid);
            if ($messageNumber < 1) {
                continue;
            }
            $overview = imap_fetch_overview($connection, (string)$uid, FT_UID)[0] ?? null;
            $header = imap_headerinfo($connection, $messageNumber);
            if (!$overview || !$header) {
                continue;
            }
            $from = $header->from[0] ?? null;
            $sender = is_object($from)
                ? (string)($from->mailbox ?? '') . '@' . (string)($from->host ?? '')
                : '';
            if (!filter_var($sender, FILTER_VALIDATE_EMAIL)) {
                continue;
            }
            $senderName = is_object($from)
                ? email_decode_header((string)($from->personal ?? ''))
                : '';
            $structure = imap_fetchstructure($connection, $messageNumber);
            $content = $structure
                ? email_imap_part_body($connection, $messageNumber, $structure)
                : ['body' => email_plain_body(imap_body($connection, $messageNumber, FT_PEEK)), 'attachments' => false];
            $customerId = null;
            if (column_exists('email_messages', 'customer_id')) {
                if (strcasecmp($sender, EMAIL_FROM_ADDRESS) !== 0) {
                    $customerId = email_customer_id_for_address($sender);
                }
                if ($customerId === null && strcasecmp($sender, EMAIL_FROM_ADDRESS) === 0) {
                    foreach (array_merge($header->to ?? [], $header->cc ?? []) as $recipient) {
                        if (!is_object($recipient)) {
                            continue;
                        }
                        $recipientAddress = (string)($recipient->mailbox ?? '') . '@' . (string)($recipient->host ?? '');
                        $customerId = email_customer_id_for_address($recipientAddress);
                        if ($customerId !== null) {
                            break;
                        }
                    }
                    if ($customerId === null && !empty($header->delivered_to)) {
                        preg_match('/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i', (string)$header->delivered_to, $deliveredMatch);
                        if (!empty($deliveredMatch[0])) {
                            $customerId = email_customer_id_for_address($deliveredMatch[0]);
                        }
                    }
                }
            }
            if ($structure) {
                $failureReport = email_imap_delivery_failure_references($connection, $messageNumber, $structure);
                foreach ($failureReport['message_ids'] as $failedMessageId) {
                    $updated = q("UPDATE email_messages
                                  SET status = 'delivery_failed'
                                  WHERE direction = 'outgoing'
                                    AND status = 'sent_to_server'
                                    AND provider_message_id = ?", [$failedMessageId]);
                    $deliveryFailures += $updated->rowCount();
                }
            }
            $providerId = 'imap:' . hash('sha256', $mailbox) . ':' . $uid;
            $messageId = isset($overview->message_id) ? trim((string)$overview->message_id) : null;
            if (is_string($messageId) && $messageId !== '') {
                $alreadyStored = q("SELECT id FROM email_messages
                                    WHERE direction = 'outgoing'
                                      AND (rfc_message_id = ? OR provider_message_id = ?)
                                    LIMIT 1", [$messageId, $messageId])->fetchColumn();
                if ($alreadyStored !== false) {
                    continue;
                }
            }
            $replyTo = isset($header->in_reply_to) ? trim((string)$header->in_reply_to) : null;
            $subject = email_decode_header((string)($overview->subject ?? ''));
            if (trim($subject) === '') {
                $subject = '(no subject)';
            }
            $createdAt = isset($overview->date) ? strtotime((string)$overview->date) : false;
            $insertSql = 'INSERT INTO email_messages
                (direction, sender_email, sender_name, recipient_email, subject, body, status, has_attachments, customer_id, provider_message_id, rfc_message_id, in_reply_to, created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)';
            if (DB_DRIVER === 'sqlite') {
                $insertSql .= ' ON CONFLICT(provider_message_id) DO NOTHING';
            } else {
                $insertSql .= ' ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id)';
            }
            $insert = q($insertSql, [
                    'incoming',
                    $sender,
                    mb_substr($senderName, 0, 120),
                    EMAIL_FROM_ADDRESS,
                    mb_substr($subject, 0, 255),
                    $content['body'],
                    'received',
                    $content['attachments'] ? 1 : 0,
                    $customerId,
                    $providerId,
                    $messageId !== '' ? mb_substr($messageId, 0, 255) : null,
                    $replyTo !== '' ? mb_substr($replyTo, 0, 255) : null,
                    $createdAt !== false ? date('Y-m-d H:i:s', $createdAt) : date('Y-m-d H:i:s'),
                ]);
            $added += $insert->rowCount() > 0 ? 1 : 0;
        }
        if (DB_DRIVER === 'sqlite') {
            q('INSERT INTO email_sync_state (mailbox, last_uid, updated_at) VALUES (?,?,CURRENT_TIMESTAMP)
               ON CONFLICT(mailbox) DO UPDATE SET last_uid = excluded.last_uid, updated_at = CURRENT_TIMESTAMP',
                [$mailbox, $largestUid]);
        } else {
            q('INSERT INTO email_sync_state (mailbox, last_uid, updated_at) VALUES (?,?,CURRENT_TIMESTAMP)
               ON DUPLICATE KEY UPDATE last_uid = VALUES(last_uid), updated_at = CURRENT_TIMESTAMP',
                [$mailbox, $largestUid]);
        }
        return ['success' => true, 'added' => $added, 'delivery_failures' => $deliveryFailures];
    } catch (Throwable $exception) {
        error_log('HomeEase IMAP synchronization failed: ' . $exception->getMessage());
        return ['success' => false, 'error' => 'Mailbox synchronization failed. Check the IMAP settings and server log.'];
    } finally {
        imap_close($connection);
    }
}
