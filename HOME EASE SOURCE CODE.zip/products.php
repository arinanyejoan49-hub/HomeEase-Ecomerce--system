<?php
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/card.php';

$cats = q('SELECT * FROM categories ORDER BY sort_order')->fetchAll();
$catSlug = is_string($_GET['cat'] ?? '') ? ($_GET['cat'] ?? '') : '';
$search = is_string($_GET['q'] ?? '') ? trim($_GET['q'] ?? '') : '';
$sort = $_GET['sort'] ?? 'popular';
$maxPrice = (int)($_GET['max'] ?? 0);
$brand = is_string($_GET['brand'] ?? '') ? ($_GET['brand'] ?? '') : '';

$where = ['p.is_active = 1'];
$params = [];
$current = null;
if ($catSlug !== '') {
    foreach ($cats as $c) {
        if ($c['slug'] === $catSlug) { $current = $c; }
    }
    if ($current) { $where[] = 'p.category_id = ?'; $params[] = $current['id']; }
}
if ($search !== '') {
    $where[] = '(p.name LIKE ? OR p.brand LIKE ? OR p.description LIKE ?)';
    $like = '%' . $search . '%';
    array_push($params, $like, $like, $like);
}
if ($maxPrice > 0) { $where[] = 'p.price <= ?'; $params[] = $maxPrice; }
if ($brand !== '') { $where[] = 'p.brand = ?'; $params[] = $brand; }

$orders = [
    'popular' => 'p.is_featured DESC, p.id ASC',
    'price_asc' => 'p.price ASC',
    'price_desc' => 'p.price DESC',
    'newest' => 'p.id DESC',
];
$orderBy = $orders[$sort] ?? $orders['popular'];

$products = q('SELECT p.*, c.icon FROM products p JOIN categories c ON c.id = p.category_id
               WHERE ' . implode(' AND ', $where) . ' ORDER BY ' . $orderBy, $params)->fetchAll();
$brands = q('SELECT DISTINCT brand FROM products WHERE is_active = 1 AND brand <> \'\' ORDER BY brand')->fetchAll(PDO::FETCH_COLUMN);

$title = $current ? $current['name'] : ($search !== '' ? 'Search: ' . $search : 'All products');
require __DIR__ . '/includes/header.php';
?>
<nav class="crumbs" aria-label="Breadcrumb"><a href="<?= e(url('index.php')) ?>">Home</a> › <a href="<?= e(url('products.php')) ?>">Shop</a><?= $current ? ' › ' . e($current['name']) : '' ?></nav>
<h1><?= $current ? e($current['icon'] . ' ' . $current['name']) : ($search !== '' ? 'Results for “' . e($search) . '”' : 'All products') ?></h1>

<form class="filters" method="get" action="<?= e(url('products.php')) ?>">
  <?php if ($search !== ''): ?><input type="hidden" name="q" value="<?= e($search) ?>"><?php endif; ?>
  <label>Category
    <select name="cat">
      <option value="">All</option>
      <?php foreach ($cats as $c): ?>
        <option value="<?= e($c['slug']) ?>" <?= $catSlug === $c['slug'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
      <?php endforeach; ?>
    </select>
  </label>
  <label>Brand
    <select name="brand">
      <option value="">All</option>
      <?php foreach ($brands as $b): ?>
        <option <?= $brand === $b ? 'selected' : '' ?>><?= e($b) ?></option>
      <?php endforeach; ?>
    </select>
  </label>
  <label>Max price
    <select name="max">
      <option value="0">Any</option>
      <?php foreach ([50000, 100000, 200000, 500000, 1000000] as $m): ?>
        <option value="<?= $m ?>" <?= $maxPrice === $m ? 'selected' : '' ?>>Up to <?= e(money($m)) ?></option>
      <?php endforeach; ?>
    </select>
  </label>
  <label>Sort by
    <select name="sort">
      <option value="popular" <?= $sort === 'popular' ? 'selected' : '' ?>>Popular</option>
      <option value="price_asc" <?= $sort === 'price_asc' ? 'selected' : '' ?>>Price: low to high</option>
      <option value="price_desc" <?= $sort === 'price_desc' ? 'selected' : '' ?>>Price: high to low</option>
      <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>Newest</option>
    </select>
  </label>
  <button class="btn small" type="submit">Apply</button>
  <a class="btn small ghost" href="<?= e(url('products.php')) ?>">Reset</a>
</form>

<p class="muted"><?= count($products) ?> product<?= count($products) === 1 ? '' : 's' ?> found</p>
<?php if (!$products): ?>
  <div class="empty">
    <p><?= $current ? e($current['name']) . ' has no products yet.' : 'No products match your filters.' ?></p>
    <a class="btn" href="<?= e(url('products.php')) ?>">See all products</a>
  </div>
<?php else: ?>
  <div class="grid"><?php foreach ($products as $p) product_card($p); ?></div>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
