<?php
require __DIR__ . '/includes/bootstrap.php';

$items = cart_items();
if (!$items) {
    flash('error', 'Your cart is empty.');
    redirect('cart.php');
}

function luhn_ok(string $n): bool
{
    $sum = 0;
    $alt = false;
    for ($i = strlen($n) - 1; $i >= 0; $i--) {
        $d = (int)$n[$i];
        if ($alt) { $d *= 2; if ($d > 9) { $d -= 9; } }
        $sum += $d;
        $alt = !$alt;
    }
    return $sum % 10 === 0;
}

function normalise_ug_phone(string $p): ?string
{
    $p = preg_replace('/[\s\-()]/', '', $p);
    if (preg_match('/^(?:\+?256|0)(7\d{8}|3\d{8})$/', $p, $m)) {
        return '+256' . $m[1];
    }
    return null;
}

$errors = [];
$old = [
    'name' => '', 'email' => '', 'phone' => '', 'address' => '', 'notes' => '',
    'zone' => $_SESSION['zone'] ?? 'kampala', 'method' => 'momo', 'network' => 'MTN', 'momo_phone' => '',
];
if (is_customer()) {
    $cu = current_customer();
    if ($cu) {
        $old['name'] = $cu['first_name'] . ' ' . $cu['last_name'];
        $old['email'] = $cu['email'];
        $old['phone'] = $cu['phone'];
        if (!empty($cu['address'])) { $old['address'] = $cu['address']; }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    foreach (['name' => 120, 'email' => 160, 'phone' => 30, 'address' => 255, 'notes' => 500, 'zone' => 20, 'method' => 10, 'network' => 10, 'momo_phone' => 30] as $k => $max) {
        $old[$k] = post($k, $max);
    }
    $zone = $old['zone'];
    if (!isset(ZONES[$zone])) { $errors[] = 'Please choose a delivery option.'; $zone = 'kampala'; }
    if (mb_strlen($old['name']) < 2) { $errors[] = 'Please enter your full name.'; }
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) { $errors[] = 'Please enter a valid email address.'; }
    $phone = normalise_ug_phone($old['phone']);
    if (!$phone) { $errors[] = 'Enter a valid Ugandan phone number, e.g. 0772 123456.'; }
    if ($zone !== 'pickup' && mb_strlen($old['address']) < 8) { $errors[] = 'Please enter a delivery address (area, street and landmark).'; }
    if ($zone === 'pickup' && $old['address'] === '') { $old['address'] = 'Store pickup'; }

    $method = $old['method'];
    $allowedMethods = pesajet_enabled() ? ['cod', 'momo'] : ['cod', 'momo', 'card'];
    if (!in_array($method, $allowedMethods, true)) { $errors[] = 'Please choose a payment method.'; }
    $livePay = false;   // true when a real PesaJet prompt must be sent after the order is saved
    $momoPhone = null;

    $payStatus = 'pay on delivery';
    $payRef = '';
    $last4 = '';

    if (!$errors && $method === 'momo') {
        $mp = normalise_ug_phone($old['momo_phone']);
        if (!$mp || !in_array($old['network'], ['MTN', 'Airtel'], true)) {
            $errors[] = 'Enter a valid mobile money number.';
        } elseif (pesajet_enabled()) {
            // Real payment: the order is saved as "awaiting payment" and a prompt is sent to the phone.
            $livePay = true;
            $momoPhone = $mp;
            $payStatus = 'awaiting payment';
        } elseif (substr($mp, -4) === '0000') {
            $errors[] = 'Simulated mobile money request was declined. Try another number.';
        } else {
            $payStatus = 'paid (simulated)';
            $payRef = strtoupper(substr($old['network'], 0, 3)) . '-SIM-' . strtoupper(bin2hex(random_bytes(4)));
        }
    }

    if (!$errors && $method === 'card') {
        // Card data is validated here and NEVER stored: only the last 4 digits are kept.
        $num = preg_replace('/\D/', '', (string)($_POST['card_number'] ?? ''));
        $exp = trim((string)($_POST['card_exp'] ?? ''));
        $cvc = preg_replace('/\D/', '', (string)($_POST['card_cvc'] ?? ''));
        $okExp = false;
        if (preg_match('/^(0[1-9]|1[0-2])\s*\/\s*(\d{2})$/', $exp, $m)) {
            $okExp = ((int)('20' . $m[2]) * 100 + (int)$m[1]) >= (int)date('Ym');
        }
        if (strlen($num) < 13 || strlen($num) > 19 || !luhn_ok($num)) {
            $errors[] = 'Card number is not valid. For the payment simulation, use 4242 4242 4242 4242.';
        } elseif (!$okExp) {
            $errors[] = 'Enter a valid, future expiry date as MM/YY.';
        } elseif (strlen($cvc) < 3 || strlen($cvc) > 4) {
            $errors[] = 'Enter the 3 or 4 digit security code.';
        } elseif ($num === '4000000000000002') {
            $errors[] = 'The simulated card payment was declined.';
        } elseif ($num !== '4242424242424242') {
            $errors[] = 'For the payment simulation, use card number 4242 4242 4242 4242.';
        } else {
            $payStatus = 'paid (simulated)';
            $payRef = 'CARD-SIM-' . strtoupper(bin2hex(random_bytes(4)));
            $last4 = substr($num, -4);
        }
    }

    if (!$errors) {
        $t = cart_totals($items, $zone, $_SESSION['coupon'] ?? '');
        $orderNo = 'HE-' . date('ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
        $pdo = db();
        try {
            $pdo->beginTransaction();
            q('INSERT INTO orders (order_no, user_id, customer_name, email, phone, address, zone, subtotal, discount, delivery_fee, total, coupon, payment_method, payment_status, payment_ref, card_last4, status, notes)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
              [$orderNo, is_customer() ? (int)$_SESSION['customer_id'] : null, $old['name'], strtolower($old['email']), $phone, $old['address'], $zone, $t['subtotal'], $t['discount'], $t['delivery'], $t['total'], $t['coupon'], $method, $payStatus, $payRef, $last4, ($method === 'cod' || $livePay) ? 'pending' : 'confirmed', $old['notes']]);
            $oid = (int)$pdo->lastInsertId();
            foreach ($items as $i) {
                $upd = q('UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?', [$i['qty'], $i['id'], $i['qty']]);
                if ($upd->rowCount() !== 1) {
                    throw new RuntimeException('Sorry, "' . $i['name'] . '" just went out of stock. Please update your cart.');
                }
                q('INSERT INTO order_items (order_id, product_id, name, price, qty) VALUES (?,?,?,?,?)', [$oid, $i['id'], $i['name'], $i['price'], $i['qty']]);
            }
            $pdo->commit();

            if ($livePay) {
                try {
                    $tx = pesajet_create_collection(
                        ['order_no' => $orderNo, 'total' => $t['total'], 'email' => strtolower($old['email'])],
                        $momoPhone,
                        $old['network']
                    );
                    if (!empty($tx['transactionId'])) {
                        q('UPDATE orders SET payment_ref = ? WHERE order_no = ?', [substr((string)$tx['transactionId'], 0, 40), $orderNo]);
                    }
                    // The prompt may already be resolved in the (rare) instant response.
                    if (!empty($tx['status'])) {
                        pesajet_apply_status($orderNo, (string)$tx['status'], (string)($tx['transactionId'] ?? ''), isset($tx['amount']) ? (int)$tx['amount'] : null);
                    }
                } catch (Throwable $ex) {
                    error_log('PesaJet create failed for ' . $orderNo . ': ' . $ex->getMessage());
                    pesajet_fail_order($orderNo, 'payment failed');
                    throw new RuntimeException('We could not send the mobile money prompt to your phone. You have not been charged. Please check the number and network, then try again.');
                }
            }

            unset($_SESSION['cart'], $_SESSION['coupon']);
            $_SESSION['last_order'] = $orderNo;
            redirect('order-success.php?no=' . urlencode($orderNo));
        } catch (RuntimeException $ex) {
            if ($pdo->inTransaction()) { $pdo->rollBack(); }
            $errors[] = $ex->getMessage();
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) { $pdo->rollBack(); }
            error_log('Checkout failed: ' . $ex->getMessage());
            $errors[] = 'Something went wrong placing your order. You have not been charged. Please try again.';
        }
    }
}

$zone = isset(ZONES[$old['zone']]) ? $old['zone'] : 'kampala';
$t = cart_totals($items, $zone, $_SESSION['coupon'] ?? '');
$title = 'Checkout';
require __DIR__ . '/includes/header.php';
?>
<h1>Checkout</h1>
<?php if (!pesajet_enabled()): ?>
<div class="simulation-banner"><strong>Payment simulation.</strong> Card and mobile-money payments are simulated; no real money is taken. For card simulation use <code>4242 4242 4242 4242</code>, any future expiry and any CVC. Mobile money accepts a valid number; numbers ending <code>0000</code> are declined.</div>
<?php endif; ?>

<?php if ($errors): ?>
  <div class="alert error" role="alert"><strong>Please fix the following:</strong><ul><?php foreach ($errors as $er): ?><li><?= e($er) ?></li><?php endforeach; ?></ul></div>
<?php endif; ?>

<form method="post" action="<?= e(url('checkout.php')) ?>" class="checkout-layout" autocomplete="on" novalidate>
  <?= csrf_field() ?>
  <div>
    <fieldset>
      <legend>1. Your details</legend>
      <label>Full name <input name="name" required maxlength="120" autocomplete="name" value="<?= e($old['name']) ?>"></label>
      <div class="two">
        <label>Email <input type="email" name="email" required maxlength="160" autocomplete="email" value="<?= e($old['email']) ?>"></label>
        <label>Phone <input type="tel" name="phone" required maxlength="30" autocomplete="tel" placeholder="0772 123456" value="<?= e($old['phone']) ?>"></label>
      </div>
    </fieldset>

    <fieldset>
      <legend>2. Delivery</legend>
      <label>Delivery option
        <select name="zone" id="zone">
          <?php foreach (ZONES as $k => $z): ?>
            <option value="<?= e($k) ?>" <?= $zone === $k ? 'selected' : '' ?>><?= e($z[0]) ?> (<?= $z[1] ? e(money($z[1])) : 'Free' ?>, <?= e($z[2]) ?>)</option>
          <?php endforeach; ?>
        </select>
      </label>
      <label id="addr-wrap">Delivery address <textarea name="address" rows="2" maxlength="255" placeholder="Area, street, building or landmark"><?= e($old['address']) ?></textarea></label>
      <label>Order notes (optional) <input name="notes" maxlength="500" value="<?= e($old['notes']) ?>"></label>
    </fieldset>

    <fieldset>
      <legend>3. Payment</legend>
      <div class="pay-options">
        <label class="pay"><input type="radio" name="method" value="momo" <?= $old['method'] === 'momo' ? 'checked' : '' ?>> 📱 Mobile money</label>
        <?php if (!pesajet_enabled()): ?>
        <label class="pay"><input type="radio" name="method" value="card" <?= $old['method'] === 'card' ? 'checked' : '' ?>> 💳 Card</label>
        <?php endif; ?>
        <label class="pay"><input type="radio" name="method" value="cod" <?= $old['method'] === 'cod' ? 'checked' : '' ?>> 💵 Pay on delivery</label>
      </div>
      <div class="pay-panel" data-panel="momo">
        <?php if (pesajet_enabled()): ?><p class="muted small">After you place the order, a payment prompt is sent to this number. Approve it with your mobile money PIN to complete payment.</p><?php endif; ?>
        <div class="two">
          <label>Network <select name="network"><option <?= $old['network'] === 'MTN' ? 'selected' : '' ?>>MTN</option><option <?= $old['network'] === 'Airtel' ? 'selected' : '' ?>>Airtel</option></select></label>
          <label>Mobile money number <input type="tel" name="momo_phone" placeholder="0772 123456" value="<?= e($old['momo_phone']) ?>"></label>
        </div>
        <?php if (!pesajet_enabled()): ?><p class="muted small">An approval request is simulated instantly. Nothing is charged.</p><?php endif; ?>
      </div>
      <?php if (!pesajet_enabled()): ?>
      <div class="pay-panel" data-panel="card">
        <label>Card number <input name="card_number" inputmode="numeric" autocomplete="off" placeholder="4242 4242 4242 4242" maxlength="23"></label>
        <div class="two">
          <label>Expiry (MM/YY) <input name="card_exp" autocomplete="off" placeholder="12/29" maxlength="7"></label>
          <label>CVC <input name="card_cvc" inputmode="numeric" autocomplete="off" placeholder="123" maxlength="4"></label>
        </div>
        <p class="muted small">🔒 Card details are checked and discarded. We only keep the last 4 digits for your receipt.</p>
      </div>
      <?php endif; ?>
      <div class="pay-panel" data-panel="cod">
        <p>Pay cash or mobile money to our rider when you receive and check your order. Not available for upcountry courier orders over UGX 1,000,000.</p>
      </div>
    </fieldset>
  </div>

  <aside class="summary">
    <h2>Your order</h2>
    <ul class="mini-items">
      <?php foreach ($items as $i): ?>
        <li class="order-item">
          <span class="order-item-product"><?= product_media($i, 'order-item-image') ?><span><?= e($i['name']) ?> × <?= (int)$i['qty'] ?></span></span>
          <b class="order-item-price"><?= e(money($i['line'])) ?></b>
        </li>
      <?php endforeach; ?>
    </ul>
    <dl class="totals">
      <div><dt>Subtotal</dt><dd><?= e(money($t['subtotal'])) ?></dd></div>
      <?php if ($t['discount']): ?><div class="good"><dt>Discount (<?= e($t['coupon']) ?>)</dt><dd>-<?= e(money($t['discount'])) ?></dd></div><?php endif; ?>
      <div><dt>Delivery</dt><dd><?= $t['delivery'] ? e(money($t['delivery'])) : 'Free' ?></dd></div>
      <div class="grand"><dt>Total</dt><dd><?= e(money($t['total'])) ?></dd></div>
    </dl>
    <button class="btn block" type="submit">Place order</button>
    <p class="muted small">By placing your order you agree to our <a href="<?= e(url('terms.php')) ?>">terms</a> and <a href="<?= e(url('returns.php')) ?>">returns policy</a>.</p>
  </aside>
</form>
<?php require __DIR__ . '/includes/footer.php'; ?>
