<?php
require __DIR__ . '/../includes/bootstrap.php';
require __DIR__ . '/../includes/card.php';
$title = 'Recently Viewed';
$here = 'customer/recently-viewed.php';
$ids = $_SESSION['recently_viewed'] ?? [];
$items = [];
if ($ids) {
    $in = implode(',', array_fill(0, count($ids), '?'));
    $rows = q("SELECT p.*, c.icon FROM products p JOIN categories c ON c.id = p.category_id WHERE p.id IN ($in) AND p.is_active = 1", $ids)->fetchAll();
    // preserve order
    $map = [];
    foreach ($rows as $r) { $map[$r['id']] = $r; }
    foreach ($ids as $id) { if (isset($map[$id])) $items[] = $map[$id]; }
}
require __DIR__ . '/../includes/header.php';
?>
<h1>Recently Viewed</h1>
<?php if (!$items): ?>
  <p class="muted">No recently viewed products.</p>
<?php else: ?>
  <div class="grid"><?php foreach ($items as $p) product_card($p); ?></div>
<?php endif; ?>
<p><a class="btn small ghost" href="<?= e(url('customer/dashboard.php')) ?>">Back</a></p>
<?php require __DIR__ . '/../includes/footer.php'; ?>