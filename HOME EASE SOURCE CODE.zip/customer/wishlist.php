<?php
require __DIR__ . '/../includes/bootstrap.php';
require_customer();
require __DIR__ . '/../includes/card.php';
$title = 'My Wishlist';
$here = 'customer/wishlist.php';
$user = current_customer();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = post('action', 20);
    $id = (int)($_POST['id'] ?? 0);
    if ($action === 'remove') { wishlist_remove($id); flash('success', 'Removed.'); }
    elseif ($action === 'tocart') {
        cart_add($id, 1);
        wishlist_remove($id);
        flash('success', 'Moved to cart.');
    }
    redirect('customer/wishlist.php');
}
$items = wishlist_items();
require __DIR__ . '/../includes/header.php';
?>
<h1>My Wishlist</h1>
<?php if (!$items): ?>
  <div class="empty"><p>Your wishlist is empty.</p><a class="btn" href="<?= e(url('products.php')) ?>">Start shopping</a></div>
<?php else: ?>
  <p class="muted"><?= count($items) ?> saved item<?= count($items) === 1 ? '' : 's' ?></p>
  <div class="grid">
  <?php foreach ($items as $p): ?>
    <article class="card product">
      <a class="media" href="<?= e(url('product.php?slug=' . $p['slug'])) ?>"><?= product_media($p) ?></a>
      <div class="body">
        <h3><a href="<?= e(url('product.php?slug=' . $p['slug'])) ?>"><?= e($p['name']) ?></a></h3>
        <p class="price"><strong><?= e(money($p['price'])) ?></strong></p>
        <form method="post" style="display:inline;">
          <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
          <button class="btn small" name="action" value="tocart" type="submit">Move to Cart</button>
          <button class="btn small danger" name="action" value="remove" type="submit">Remove</button>
        </form>
      </div>
    </article>
  <?php endforeach; ?>
  </div>
<?php endif; ?>
<p><a class="btn small ghost" href="<?= e(url('customer/dashboard.php')) ?>">Back</a></p>
<?php require __DIR__ . '/../includes/footer.php'; ?>