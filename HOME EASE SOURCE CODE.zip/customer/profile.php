<?php
require __DIR__ . '/../includes/bootstrap.php';
require_customer();
$title = 'My Profile';
$here = 'customer/profile.php';
$user = current_customer();
require __DIR__ . '/../includes/header.php';
?>
<h1>My Profile</h1>
<div class="account-panel">
  <table class="data">
    <tbody>
      <tr><td><b>Name</b></td><td><?= e($user['first_name'] . ' ' . $user['last_name']) ?></td></tr>
      <tr><td><b>Username</b></td><td><?= e($user['username']) ?></td></tr>
      <tr><td><b>Email</b></td><td><?= e($user['email']) ?></td></tr>
      <tr><td><b>Phone</b></td><td><?= e($user['phone']) ?></td></tr>
      <tr><td><b>Country</b></td><td><?= e($user['country']) ?></td></tr>
      <tr><td><b>District</b></td><td><?= e($user['district'] ?? '-') ?></td></tr>
      <tr><td><b>Address</b></td><td><?= e($user['address'] ?? '-') ?></td></tr>
      <tr><td><b>Member since</b></td><td><?= e(date('j M Y', strtotime($user['created_at']))) ?></td></tr>
    </tbody>
  </table>
  <div style="margin-top:14px;">
    <a class="btn" href="<?= e(url('customer/edit-profile.php')) ?>">Edit Profile</a>
    <a class="btn small ghost" href="<?= e(url('customer/change-password.php')) ?>">Change Password</a>
  </div>
</div>
<p><a class="btn small ghost" href="<?= e(url('customer/dashboard.php')) ?>">Back</a></p>
<?php require __DIR__ . '/../includes/footer.php'; ?>