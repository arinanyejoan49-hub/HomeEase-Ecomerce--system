<?php
require __DIR__ . '/../includes/bootstrap.php';
require_customer();
$title = 'Returns & Refunds';
$here = 'customer/returns.php';
$user = current_customer();
$errors = [];
$values = ['order_id'=>0,'reason'=>''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $values['order_id'] = (int)($_POST['order_id'] ?? 0);
    $values['reason'] = post('reason', 500);
    if ($values['order_id'] < 1) $errors[] = 'Select an order.';
    if ($values['reason'] === '') $errors[] = 'Reason is required.';
    // verify ownership
    if (empty($errors)) {
        $order = table_exists('orders') && column_exists('orders', 'user_id')
            ? q('SELECT id FROM orders WHERE id = ? AND user_id = ?', [$values['order_id'], (int)$user['id']])->fetch()
            : false;
        if (!$order) $errors[] = 'Order not found.';
    }
    if (empty($errors) && table_exists('return_requests')) {
        q('INSERT INTO return_requests (order_id, user_id, reason) VALUES (?,?,?)', [$values['order_id'], (int)$user['id'], $values['reason']]);
        flash('success', 'Return request submitted.');
        redirect('customer/returns.php');
    }
}
$orders = table_exists('orders') && column_exists('orders', 'user_id')
    ? q('SELECT id, order_no, created_at, total FROM orders WHERE user_id = ? ORDER BY id DESC', [(int)$user['id']])->fetchAll()
    : [];
$hasRefundStatus = table_exists('return_requests') && column_exists('return_requests', 'refund_status');
$returns = table_exists('return_requests') ? q('SELECT rr.*, o.order_no FROM return_requests rr JOIN orders o ON o.id = rr.order_id WHERE rr.user_id = ? ORDER BY rr.created_at DESC', [(int)$user['id']])->fetchAll() : [];
require __DIR__ . '/../includes/header.php';
?>
<h1>Returns & Refunds</h1>
<?php if ($errors): ?><div class="alert error"><ul><?php foreach($errors as $e) echo '<li>'.e($e).'</li>'; ?></ul></div><?php endif; ?>
<div class="panel" style="margin-bottom:18px;">
  <h2>Request a Return</h2>
  <?php if (empty($orders)): ?>
    <p class="muted">No orders available.</p>
  <?php else: ?>
  <form method="post" class="form-grid">
    <?= csrf_field() ?>
    <label>Order
      <select name="order_id" required>
        <?php foreach ($orders as $o): ?>
          <option value="<?= (int)$o['id'] ?>" <?= $values['order_id']==$o['id']?'selected':'' ?>><?= e($o['order_no']) ?> (<?= e(date('j M Y', strtotime($o['created_at']))) ?>)</option>
        <?php endforeach; ?>
      </select>
    </label>
    <label class="full">Reason <textarea name="reason" rows="3" required maxlength="500"><?= e($values['reason']) ?></textarea></label>
    <div class="full"><button class="btn" type="submit">Submit Request</button></div>
  </form>
  <?php endif; ?>
</div>
<?php if (!$returns): ?>
  <p class="muted">No return requests yet.</p>
<?php else: ?>
<div class="table-wrap">
<table class="data">
  <thead><tr><th>Date</th><th>Order</th><th>Status</th><?php if ($hasRefundStatus): ?><th>Refund follow-up</th><?php endif; ?><th>Reason</th><th>Admin note</th><th>Admin reply</th></tr></thead>
  <tbody>
  <?php foreach ($returns as $r): ?>
    <tr>
      <td><?= e(date('j M Y', strtotime($r['created_at']))) ?></td>
      <td><?= e($r['order_no']) ?></td>
      <td><span class="pill <?= e($r['status']) ?>"><?= e($r['status']) ?></span></td>
      <?php if ($hasRefundStatus): ?><td><?= e(str_replace('_', ' ', $r['refund_status'])) ?></td><?php endif; ?>
      <td><?= e($r['reason']) ?></td>
      <td><?= $r['admin_note'] ? e($r['admin_note']) : '<span class="muted">-</span>' ?></td>
      <td><?= !empty($r['admin_reply']) ? nl2br(e($r['admin_reply'])) : '<span class="muted">Awaiting response</span>' ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php endif; ?>
<p><a class="btn small ghost" href="<?= e(url('customer/dashboard.php')) ?>">Back</a></p>
<?php require __DIR__ . '/../includes/footer.php'; ?>