<?php
require __DIR__ . '/../includes/bootstrap.php';
require_customer();
$title = 'Account Settings';
$here = 'customer/settings.php';
$user = current_customer();
if (!table_exists('customer_settings')) {
    q('CREATE TABLE IF NOT EXISTS customer_settings (user_id INT PRIMARY KEY, email_notifications TINYINT(1) NOT NULL DEFAULT 1, promo_notifications TINYINT(1) NOT NULL DEFAULT 1, preferred_contact VARCHAR(20) NOT NULL DEFAULT \'email\', FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
}
$settings = q('SELECT * FROM customer_settings WHERE user_id = ?', [(int)$user['id']])->fetch();
if (!$settings) {
    q('INSERT INTO customer_settings (user_id) VALUES (?)', [(int)$user['id']]);
    $settings = q('SELECT * FROM customer_settings WHERE user_id = ?', [(int)$user['id']])->fetch();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $emailN = isset($_POST['email_notifications']) ? 1 : 0;
    $promoN = isset($_POST['promo_notifications']) ? 1 : 0;
    $contact = post('preferred_contact', 20);
    if (!in_array($contact, ['email','phone','whatsapp'], true)) $contact = 'email';
    q('UPDATE customer_settings SET email_notifications=?, promo_notifications=?, preferred_contact=? WHERE user_id=?',
        [$emailN, $promoN, $contact, (int)$user['id']]);
    flash('success', 'Settings saved.');
    redirect('customer/settings.php');
}
require __DIR__ . '/../includes/header.php';
?>
<h1>Account Settings</h1>
<div class="panel">
  <form method="post" class="form-grid">
    <?= csrf_field() ?>
    <label class="check"><input type="checkbox" name="email_notifications" <?= $settings['email_notifications'] ? 'checked' : '' ?>> Email notifications for orders</label>
    <label class="check"><input type="checkbox" name="promo_notifications" <?= $settings['promo_notifications'] ? 'checked' : '' ?>> Promotional communications</label>
    <label>Preferred Contact
      <select name="preferred_contact">
        <option value="email" <?= $settings['preferred_contact']==='email'?'selected':'' ?>>Email</option>
        <option value="phone" <?= $settings['preferred_contact']==='phone'?'selected':'' ?>>Phone</option>
        <option value="whatsapp" <?= $settings['preferred_contact']==='whatsapp'?'selected':'' ?>>WhatsApp</option>
      </select>
    </label>
    <div class="full"><button class="btn" type="submit">Save Settings</button></div>
  </form>
</div>
<p><a class="btn small ghost" href="<?= e(url('customer/dashboard.php')) ?>">Back</a></p>
<?php require __DIR__ . '/../includes/footer.php'; ?>