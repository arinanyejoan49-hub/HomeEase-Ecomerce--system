<?php
require __DIR__ . '/../includes/bootstrap.php';
require_customer();

$title = 'Edit Profile';
$desc = 'Update your account information.';
$here = 'customer/edit-profile.php';

$user = current_customer();
$errors = [];
$values = [
    'first_name' => $user['first_name'],
    'last_name'  => $user['last_name'],
    'username'   => $user['username'],
    'email'      => $user['email'],
    'phone'      => $user['phone'],
    'gender'     => $user['gender'] ?? '',
    'date_of_birth' => $user['date_of_birth'] ?? '',
    'country'    => $user['country'],
    'district'   => $user['district'] ?? '',
    'address'    => $user['address'] ?? '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $values['first_name'] = trim($_POST['first_name'] ?? '');
    $values['last_name']  = trim($_POST['last_name'] ?? '');
    $values['username']   = trim($_POST['username'] ?? '');
    $values['email']      = strtolower(trim($_POST['email'] ?? ''));
    $values['phone']      = trim($_POST['phone'] ?? '');
    $values['gender']     = $_POST['gender'] ?? '';
    $values['date_of_birth'] = $_POST['date_of_birth'] ?? '';
    $values['country']    = trim($_POST['country'] ?? '');
    $values['district']   = trim($_POST['district'] ?? '');
    $values['address']    = trim($_POST['address'] ?? '');

    if ($values['first_name'] === '') { $errors['first_name'] = 'First name is required.'; }
    elseif (mb_strlen($values['first_name']) < 2 || mb_strlen($values['first_name']) > 100) { $errors['first_name'] = 'Invalid first name.'; }

    if ($values['last_name'] === '') { $errors['last_name'] = 'Last name is required.'; }
    elseif (mb_strlen($values['last_name']) < 2 || mb_strlen($values['last_name']) > 100) { $errors['last_name'] = 'Invalid last name.'; }

    if ($values['username'] === '') { $errors['username'] = 'Username is required.'; }
    elseif (!preg_match('/^[a-zA-Z0-9_]{3,50}$/', $values['username'])) { $errors['username'] = 'Invalid username.'; }
    else {
        $dup = q('SELECT id FROM users WHERE username = ? AND id <> ?', [$values['username'], (int)$user['id']])->fetch();
        if ($dup) { $errors['username'] = 'Username is already taken.'; }
    }

    if ($values['email'] === '') { $errors['email'] = 'Email is required.'; }
    elseif (!filter_var($values['email'], FILTER_VALIDATE_EMAIL)) { $errors['email'] = 'Invalid email.'; }
    else {
        $dup = q('SELECT id FROM users WHERE email = ? AND id <> ?', [$values['email'], (int)$user['id']])->fetch();
        if ($dup) { $errors['email'] = 'Email is already registered.'; }
    }

    if ($values['phone'] === '') { $errors['phone'] = 'Phone is required.'; }
    elseif (!preg_match('/^\+?[0-9\s\-()]{7,20}$/', $values['phone'])) { $errors['phone'] = 'Invalid phone number.'; }

    if ($values['country'] === '') { $errors['country'] = 'Country is required.'; }

    if ($values['gender'] !== '' && !in_array($values['gender'], ['male', 'female', 'other', 'prefer_not_to_say'])) {
        $errors['gender'] = 'Invalid gender.';
    }
    if ($values['date_of_birth'] !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $values['date_of_birth'])) {
        $errors['date_of_birth'] = 'Invalid date of birth.';
    }

    if (empty($errors)) {
        try {
            q('UPDATE users SET first_name=?, last_name=?, username=?, email=?, phone=?, gender=?, date_of_birth=?, country=?, district=?, address=?, updated_at=CURRENT_TIMESTAMP WHERE id=?',
                [$values['first_name'], $values['last_name'], $values['username'], $values['email'], $values['phone'],
                 $values['gender'] ?: null, $values['date_of_birth'] ?: null, $values['country'],
                 $values['district'] ?: null, $values['address'] ?: null, (int)$user['id']]);
            flash('success', 'Profile updated successfully.');
            redirect('customer/dashboard.php');
        } catch (Throwable $e) {
            error_log('Profile update failed: ' . $e->getMessage());
            $errors['_general'] = 'Update failed. Please try again.';
        }
    }
}
require __DIR__ . '/../includes/header.php';
?>
<h1>Edit Profile</h1>
<p class="lead">Update your account information.</p>

<?php if (!empty($errors['_general'])): ?>
  <div class="alert error" role="alert"><?= e($errors['_general']) ?></div>
<?php endif; ?>

<form method="post" class="auth-form" novalidate>
  <?= csrf_field() ?>

  <div class="form-grid">
    <div class="form-field">
      <label for="first_name">First Name <span class="required">*</span></label>
      <input type="text" id="first_name" name="first_name" maxlength="100"
             value="<?= e($values['first_name']) ?>" <?= isset($errors['first_name']) ? 'aria-invalid="true"' : '' ?>>
      <?php if (isset($errors['first_name'])): ?><span class="field-error"><?= e($errors['first_name']) ?></span><?php endif; ?>
    </div>
    <div class="form-field">
      <label for="last_name">Last Name <span class="required">*</span></label>
      <input type="text" id="last_name" name="last_name" maxlength="100"
             value="<?= e($values['last_name']) ?>" <?= isset($errors['last_name']) ? 'aria-invalid="true"' : '' ?>>
      <?php if (isset($errors['last_name'])): ?><span class="field-error"><?= e($errors['last_name']) ?></span><?php endif; ?>
    </div>
    <div class="form-field">
      <label for="username">Username <span class="required">*</span></label>
      <input type="text" id="username" name="username" maxlength="50"
             value="<?= e($values['username']) ?>" <?= isset($errors['username']) ? 'aria-invalid="true"' : '' ?>>
      <?php if (isset($errors['username'])): ?><span class="field-error"><?= e($errors['username']) ?></span><?php endif; ?>
    </div>
    <div class="form-field">
      <label for="email">Email Address <span class="required">*</span></label>
      <input type="email" id="email" name="email" maxlength="150"
             value="<?= e($values['email']) ?>" <?= isset($errors['email']) ? 'aria-invalid="true"' : '' ?>>
      <?php if (isset($errors['email'])): ?><span class="field-error"><?= e($errors['email']) ?></span><?php endif; ?>
    </div>
    <div class="form-field">
      <label for="phone">Phone Number <span class="required">*</span></label>
      <input type="tel" id="phone" name="phone" maxlength="20"
             value="<?= e($values['phone']) ?>" <?= isset($errors['phone']) ? 'aria-invalid="true"' : '' ?>>
      <?php if (isset($errors['phone'])): ?><span class="field-error"><?= e($errors['phone']) ?></span><?php endif; ?>
    </div>
    <div class="form-field">
      <label for="country">Country <span class="required">*</span></label>
      <input type="text" id="country" name="country" maxlength="100"
             value="<?= e($values['country']) ?>" <?= isset($errors['country']) ? 'aria-invalid="true"' : '' ?>>
      <?php if (isset($errors['country'])): ?><span class="field-error"><?= e($errors['country']) ?></span><?php endif; ?>
    </div>
    <div class="form-field">
      <label for="district">District or City</label>
      <input type="text" id="district" name="district" maxlength="100"
             value="<?= e($values['district']) ?>" <?= isset($errors['district']) ? 'aria-invalid="true"' : '' ?>>
      <?php if (isset($errors['district'])): ?><span class="field-error"><?= e($errors['district']) ?></span><?php endif; ?>
    </div>
    <div class="form-field full">
      <label for="address">Delivery Address</label>
      <textarea id="address" name="address" rows="3"><?= e($values['address']) ?></textarea>
      <?php if (isset($errors['address'])): ?><span class="field-error"><?= e($errors['address']) ?></span><?php endif; ?>
    </div>
    <div class="form-field">
      <label for="gender">Gender</label>
      <select id="gender" name="gender">
        <option value=""><?= $values['gender'] === '' ? 'selected' : '' ?>>Prefer not to say</option>
        <option value="male" <?= $values['gender'] === 'male' ? 'selected' : '' ?>>Male</option>
        <option value="female" <?= $values['gender'] === 'female' ? 'selected' : '' ?>>Female</option>
        <option value="other" <?= $values['gender'] === 'other' ? 'selected' : '' ?>>Other</option>
      </select>
    </div>
    <div class="form-field">
      <label for="date_of_birth">Date of Birth</label>
      <input type="date" id="date_of_birth" name="date_of_birth" value="<?= e($values['date_of_birth']) ?>">
    </div>
  </div>

  <div class="form-actions">
    <a class="btn small ghost" href="<?= e(url('customer/dashboard.php')) ?>">Cancel</a>
    <button type="submit" class="btn">Save Changes</button>
  </div>
</form>

<?php require __DIR__ . '/../includes/footer.php'; ?>