<?php
// Customer sidebar. Expects $here to be set.
$hasCustomerEmailLink = table_exists('email_messages') && column_exists('email_messages', 'customer_id');
$unreadCustomerReplies = column_exists('messages', 'customer_id') && $hasCustomerEmailLink
    ? (int)q("SELECT COUNT(*) FROM email_messages e
        WHERE e.direction = 'outgoing' AND e.is_read = 0
          AND (e.customer_id = ? OR e.contact_message_id IN (
            SELECT m.id FROM messages m WHERE m.customer_id = ?
          ))", [(int)$_SESSION['customer_id'], (int)$_SESSION['customer_id']])->fetchColumn()
    : (column_exists('messages', 'customer_id') && table_exists('email_messages')
        ? (int)q("SELECT COUNT(*) FROM email_messages e
            JOIN messages m ON m.id = e.contact_message_id
            WHERE m.customer_id = ? AND e.direction = 'outgoing' AND e.is_read = 0", [(int)$_SESSION['customer_id']])->fetchColumn()
        : 0);
$customerIcon = static function (string $name): string {
    $paths = [
        'home' => '<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
        'products' => '<path d="M3 7h18l-2 13H5L3 7Z"/><path d="M8 7a4 4 0 0 1 8 0"/>',
        'wishlist' => '<path d="M20.8 8.6c0 4.2-8.8 10-8.8 10s-8.8-5.8-8.8-10A4.6 4.6 0 0 1 12 6.4a4.6 4.6 0 0 1 8.8 2.2Z"/>',
        'recent' => '<path d="M2 12s3.6-6 10-6 10 6 10 6-3.6 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
        'coupon' => '<path d="M3 7V4h18v3a3 3 0 0 0 0 6v3h-6"/><path d="M3 7a3 3 0 0 1 0 6v3h6"/><path d="M12 4v2m0 4v2m0 4v2"/>',
        'cart' => '<circle cx="9" cy="20" r="1"/><circle cx="18" cy="20" r="1"/><path d="M2 3h2l2.5 12h12l2-9H5"/>',
        'orders' => '<path d="M4 4h16v16H4z"/><path d="M8 8h8M8 12h8M8 16h5"/>',
        'track' => '<path d="M3 6h12v11H3zM15 10h4l3 3v4h-7z"/><circle cx="7.5" cy="18" r="2"/><circle cx="18.5" cy="18" r="2"/>',
        'returns' => '<path d="M4 7v6h6"/><path d="M5 13a8 8 0 1 0 2-6"/>',
        'profile' => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
        'address' => '<path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
        'reviews' => '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9z"/>',
        'notifications' => '<path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/>',
        'support' => '<path d="M21 11.5a8.5 8.5 0 0 1-12.4 7.6L3 21l1.9-5.7A8.5 8.5 0 1 1 21 11.5Z"/>',
        'email' => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
        'settings' => '<circle cx="12" cy="12" r="3"/><path d="m19.4 15 .1.1 1.4 1.1-1.4 2.4-1.7-.7a8 8 0 0 1-1.7 1l-.3 1.8h-2.8l-.3-1.8a8 8 0 0 1-1.7-1l-1.7.7-1.4-2.4L7.3 15a8 8 0 0 1 0-2l-1.4-1.1 1.4-2.4 1.7.7a8 8 0 0 1 1.7-1l.3-1.8h2.8l.3 1.8a8 8 0 0 1 1.7 1l1.7-.7 1.4 2.4-1.4 1.1a8 8 0 0 1-.1 2Z"/>',
        'security' => '<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 1 1 8 0v3m-4 4v3"/>',
        'logout' => '<path d="M10 17l5-5-5-5m5 5H3"/><path d="M12 3h7a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-7"/>',
    ];
    return '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ($paths[$name] ?? '') . '</svg>';
};
$customerMenu = [
    'Overview' => [
        ['customer/dashboard.php', 'Dashboard Home', 'home'],
    ],
    'Shopping' => [
        ['products.php', 'Browse Products', 'products'],
        ['customer/wishlist.php', 'My Wishlist', 'wishlist'],
        ['customer/recently-viewed.php', 'Recently Viewed', 'recent'],
        ['customer/coupons.php', 'Coupons & Offers', 'coupon'],
        ['cart.php', 'My Cart', 'cart'],
    ],
    'Orders' => [
        ['customer/orders.php', 'My Orders', 'orders'],
        ['track.php', 'Track Orders', 'track'],
        ['customer/returns.php', 'Returns & Refunds', 'returns'],
    ],
    'Account' => [
        ['customer/profile.php', 'My Profile', 'profile'],
        ['customer/addresses.php', 'My Addresses', 'address'],
        ['customer/reviews.php', 'Reviews & Ratings', 'reviews'],
        ['customer/notifications.php', 'Notifications', 'notifications'],
        ['customer/emails.php', 'Emails & Messages', 'email'],
        ['customer/support.php', 'Customer Support', 'support'],
    ],
    'Settings' => [
        ['customer/settings.php', 'Account Settings', 'settings'],
        ['customer/change-password.php', 'Security & Password', 'security'],
        ['logout.php', 'Logout', 'logout'],
    ],
];
?>
<aside class="customer-sidebar">
  <div class="cs-brand">
    <span class="logo"><svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z" fill="#FF7900"/></svg></span>
    <strong><?= e(SITE_NAME) ?></strong>
  </div>
  <nav>
    <?php foreach ($customerMenu as $section => $links): ?>
      <div class="cs-section"><?= e($section) ?></div>
      <?php foreach ($links as [$href, $label, $icon]): ?>
        <?php
          $active = false;
          $base = basename($href);
          if ($base === 'products.php') {
              $active = ($here === 'products.php');
          } else {
              $active = ($here === $href);
          }
        ?>
        <a href="<?= e(url($href)) ?>" class="cs-link <?= $active ? 'on' : '' ?>">
          <span class="cs-icon"><?= $customerIcon($icon) ?></span>
          <span><?= e($label) ?></span>
          <?php if ($href === 'customer/emails.php' && !empty($unreadCustomerReplies)): ?><span class="cs-badge"><?= (int)$unreadCustomerReplies ?></span><?php endif; ?>
        </a>
      <?php endforeach; ?>
    <?php endforeach; ?>
  </nav>
</aside>