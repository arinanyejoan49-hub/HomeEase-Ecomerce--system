<?php
require __DIR__ . '/../includes/bootstrap.php';
require_customer();

$title = 'My Orders';
$desc = 'View your order history.';
$here = 'customer/orders.php';

$user = current_customer();
$orders = [];
if (table_exists('orders') && column_exists('orders', 'user_id')) {
    $orders = q('SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC', [(int)$user['id']])->fetchAll();
}

require __DIR__ . '/../includes/header.php';
?>
<h1>My Orders</h1>
<p class="lead">Your order history, <?= e($user['first_name']) ?>.</p>

<?php if (!$orders): ?>
  <p class="muted">You have not placed any orders yet.</p>
  <p><a class="btn" href="<?= e(url('products.php')) ?>">Browse products</a></p>
<?php else: ?>
<div class="table-wrap">
<table class="data">
  <thead><tr><th>Order</th><th>Product</th><th>Date</th><th>Items</th><th>Total</th><th>Payment</th><th>Status</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($orders as $o): 
        $ic = (int)q('SELECT COUNT(*) FROM order_items WHERE order_id = ?', [(int)$o['id']])->fetchColumn();
        $firstItem = q('SELECT oi.name, p.slug, p.image FROM order_items oi LEFT JOIN products p ON p.id = oi.product_id WHERE oi.order_id = ? ORDER BY oi.id LIMIT 1', [(int)$o['id']])->fetch();
  ?>
    <tr>
      <td><a href="<?= e(url('customer/order.php?id=' . $o['id'])) ?>"><?= e($o['order_no']) ?></a></td>
      <td><?= $firstItem ? product_media($firstItem, 'admin-product-image') : '<span class="muted">—</span>' ?></td>
      <td><?= e(date('j M Y', strtotime($o['created_at']))) ?></td>
      <td><?= $ic ?></td>
      <td><?= e(money($o['total'])) ?></td>
      <td><?= e($o['payment_method']) ?><br><small class="muted"><?= e(payment_status_label($o['payment_status'])) ?></small></td>
      <td><span class="pill <?= e($o['status']) ?>"><?= e(order_statuses()[$o['status']] ?? $o['status']) ?></span></td>
      <td><a class="btn small" href="<?= e(url('track.php')) ?>">Track</a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php endif; ?>

<p><a class="btn small ghost" href="<?= e(url('customer/dashboard.php')) ?>">Back to account</a></p>

<?php require __DIR__ . '/../includes/footer.php'; ?>