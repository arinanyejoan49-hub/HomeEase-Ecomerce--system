<?php
require __DIR__ . '/../includes/bootstrap.php';
require_customer();
$title = 'Coupons & Offers';
$here = 'customer/coupons.php';
require __DIR__ . '/../includes/header.php';
?>
<h1>Coupons & Offers</h1>
<p class="muted">Apply these codes at checkout.</p>
<div class="table-wrap">
<table class="data">
  <thead><tr><th>Code</th><th>Discount</th><th>How to use</th></tr></thead>
  <tbody>
  <?php foreach (COUPONS as $code => $pct): ?>
    <tr>
      <td><strong><?= e($code) ?></strong></td>
      <td><?= (int)$pct ?>% off subtotal</td>
      <td>Enter at checkout. Minimum order and eligibility rules apply on the server.</td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<p><a class="btn small ghost" href="<?= e(url('customer/dashboard.php')) ?>">Back</a></p>
<?php require __DIR__ . '/../includes/footer.php'; ?>