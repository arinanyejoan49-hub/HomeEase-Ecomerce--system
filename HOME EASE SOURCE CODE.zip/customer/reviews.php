<?php
require __DIR__ . '/../includes/bootstrap.php';
require_customer();
$title = 'My Reviews';
$here = 'customer/reviews.php';
$user = current_customer();
$errors = [];
$values = ['product_id'=>0,'rating'=>5,'title'=>'','body'=>''];

// Only account-linked orders establish review eligibility; guest orders use order tracking.
$eligible = [];
if (table_exists('orders') && table_exists('order_items') && column_exists('orders', 'user_id')) {
    $eligible = q("SELECT DISTINCT p.id, p.name FROM products p JOIN order_items oi ON oi.product_id = p.id JOIN orders o ON o.id = oi.order_id WHERE o.user_id = ? AND o.status IN ('delivered','confirmed','dispatched')", [(int)$user['id']])->fetchAll();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $values['product_id'] = (int)($_POST['product_id'] ?? 0);
    $values['rating'] = (int)($_POST['rating'] ?? 0);
    $values['title'] = post('title', 160);
    $values['body'] = post('body', 2000);
    if ($values['product_id'] < 1) $errors[] = 'Select a product.';
    if ($values['rating'] < 1 || $values['rating'] > 5) $errors[] = 'Rating must be 1-5.';
    if ($values['body'] === '') $errors[] = 'Review text is required.';
    if (empty($errors)) {
        $isEligible = table_exists('orders') && table_exists('order_items') && column_exists('orders', 'user_id')
            ? q("SELECT 1 FROM order_items oi JOIN orders o ON o.id = oi.order_id WHERE oi.product_id = ? AND o.user_id = ? AND o.status IN ('delivered','confirmed','dispatched') LIMIT 1", [$values['product_id'], (int)$user['id']])->fetch()
            : false;
        if (!$isEligible) $errors[] = 'You can only review a product from an order linked to your account.';
    }
    // duplicate check
    if (empty($errors) && table_exists('reviews')) {
        $dup = q('SELECT 1 FROM reviews WHERE user_id = ? AND product_id = ?', [(int)$user['id'], $values['product_id']])->fetch();
        if ($dup) $errors[] = 'You already reviewed this product.';
    }
    if (empty($errors) && table_exists('reviews')) {
        q('INSERT INTO reviews (product_id, user_id, rating, title, body) VALUES (?,?,?,?,?)',
            [$values['product_id'], (int)$user['id'], $values['rating'], $values['title'] ?: null, $values['body']]);
        flash('success', 'Review submitted.');
        redirect('customer/reviews.php');
    }
}

$reviews = table_exists('reviews') ? q('SELECT r.*, p.name FROM reviews r JOIN products p ON p.id = r.product_id WHERE r.user_id = ? ORDER BY r.created_at DESC', [(int)$user['id']])->fetchAll() : [];
require __DIR__ . '/../includes/header.php';
?>
<h1>My Reviews</h1>
<div class="panel" style="margin-bottom:18px;">
  <h2>Write a Review</h2>
  <?php if ($errors): ?><div class="alert error"><ul><?php foreach($errors as $e) echo '<li>'.e($e).'</li>'; ?></ul></div><?php endif; ?>
  <?php if (empty($eligible)): ?>
    <p class="muted">You can review products you have purchased.</p>
  <?php else: ?>
  <form method="post" class="form-grid">
    <?= csrf_field() ?>
    <label>Product
      <select name="product_id" required>
        <?php foreach ($eligible as $p): ?>
          <option value="<?= (int)$p['id'] ?>" <?= $values['product_id']==$p['id']?'selected':'' ?>><?= e($p['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <label>Rating (1-5) <input type="number" name="rating" min="1" max="5" required value="<?= (int)$values['rating'] ?>"></label>
    <label class="full">Title <input name="title" maxlength="160" value="<?= e($values['title']) ?>"></label>
    <label class="full">Review <textarea name="body" rows="4" required maxlength="2000"><?= e($values['body']) ?></textarea></label>
    <div class="full"><button class="btn" type="submit">Submit Review</button></div>
  </form>
  <?php endif; ?>
</div>
<?php if (!$reviews): ?>
  <p class="muted">No reviews yet.</p>
<?php else: ?>
<div class="table-wrap">
<table class="data">
  <thead><tr><th>Product</th><th>Rating</th><th>Review</th><th>Status</th><th>Date</th></tr></thead>
  <tbody>
  <?php foreach ($reviews as $r): ?>
    <tr>
      <td><?= e($r['name']) ?></td>
      <td><?= (int)$r['rating'] ?>/5</td>
      <td><?= e($r['title']) ?><br><small class="muted"><?= e(mb_substr($r['body'],0,120)) ?></small></td>
      <td><?= e($r['status']) ?></td>
      <td><?= e(date('j M Y', strtotime($r['created_at']))) ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php endif; ?>
<p><a class="btn small ghost" href="<?= e(url('customer/dashboard.php')) ?>">Back</a></p>
<?php require __DIR__ . '/../includes/footer.php'; ?>