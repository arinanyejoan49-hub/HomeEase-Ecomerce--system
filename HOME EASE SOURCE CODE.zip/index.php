<?php
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/card.php';
$title = SITE_NAME;
$featured = q('SELECT p.*, c.icon FROM products p JOIN categories c ON c.id = p.category_id
               WHERE p.is_active = 1 AND p.is_featured = 1 ORDER BY p.id LIMIT 8')->fetchAll();
$popularIds = array_map('intval', array_column($featured, 'id'));
$featuredExclusion = $popularIds
    ? ' AND p.id NOT IN (' . implode(',', array_fill(0, count($popularIds), '?')) . ')'
    : '';
$featuredCandidates = q(
    'SELECT p.*, c.icon, c.name AS category_name
     FROM products p JOIN categories c ON c.id = p.category_id
     WHERE p.is_active = 1 AND p.is_featured = 1' . $featuredExclusion . '
     ORDER BY p.id DESC',
    $popularIds
)->fetchAll();
$featuredProducts = [];
$featuredImageUrls = [];
foreach ($featuredCandidates as $product) {
    $imageUrl = product_image_url($product);
    if (str_ends_with($imageUrl, '/assets/images/product-image-unavailable.svg')
        || isset($featuredImageUrls[$imageUrl])) {
        continue;
    }

    $featuredImageUrls[$imageUrl] = true;
    $featuredProducts[] = $product;
    if (count($featuredProducts) === 8) {
        break;
    }
}
$deals = q('SELECT p.*, c.icon FROM products p JOIN categories c ON c.id = p.category_id
            WHERE p.is_active = 1 AND p.old_price IS NOT NULL AND p.old_price > p.price ORDER BY (p.old_price - p.price) * 1.0 / p.old_price DESC LIMIT 4')->fetchAll();
$catCounts = q('SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id AND p.is_active = 1) AS n FROM categories c ORDER BY sort_order')->fetchAll();
$mainSlugs = ['kitchen', 'cooking', 'cooling', 'laundry', 'student', 'power'];
$mainCats = [];
foreach ($catCounts as $c) { if (in_array($c['slug'], $mainSlugs, true)) { $mainCats[] = $c; } }
usort($mainCats, function ($a, $b) use ($mainSlugs) { return array_search($a['slug'], $mainSlugs, true) <=> array_search($b['slug'], $mainSlugs, true); });
require __DIR__ . '/includes/header.php';
?>
<section class="home-hero" aria-label="HomeEase featured collections">
  <div class="hero-slides" id="home-hero-slides" aria-live="off">
    <article class="hero-slide is-active" role="group" aria-roledescription="slide" aria-label="1 of 4" aria-hidden="false">
      <div class="hero-copy">
        <p class="hero-kicker">Your home, made better</p>
        <h1>Everything Your Home Needs</h1>
        <p class="hero-description">Discover quality home appliances and everyday essentials designed to make life easier, more comfortable, and more convenient.</p>
        <div class="hero-actions">
          <a class="hero-button hero-button-primary" href="<?= e(url('products.php')) ?>">Shop Now</a>
          <a class="hero-button hero-button-secondary" href="<?= e(url('categories.php')) ?>">Explore Categories</a>
        </div>
      </div>
      <div class="hero-visual">
        <img src="<?= e(url('assets/images/hero/home-interior.jpg')) ?>" alt="Bright contemporary home interior with comfortable living and dining spaces" fetchpriority="high">
      </div>
    </article>
    <article class="hero-slide" role="group" aria-roledescription="slide" aria-label="2 of 4" aria-hidden="true" inert>
      <div class="hero-copy">
        <p class="hero-kicker">Kitchen essentials</p>
        <h2>Make Every Kitchen Moment Better</h2>
        <p class="hero-description">Explore modern kitchen appliances that combine convenience, performance, and style.</p>
        <div class="hero-actions">
          <a class="hero-button hero-button-primary" href="<?= e(url('products.php?cat=kitchen')) ?>">Shop Kitchen Appliances</a>
          <a class="hero-button hero-button-secondary" href="<?= e(url('products.php')) ?>">View Products</a>
        </div>
      </div>
      <div class="hero-visual">
        <img src="<?= e(url('assets/images/hero/modern-kitchen.jpg')) ?>" alt="Modern kitchen with bright counters and fitted appliances" loading="lazy">
      </div>
    </article>
    <article class="hero-slide" role="group" aria-roledescription="slide" aria-label="3 of 4" aria-hidden="true" inert>
      <div class="hero-copy">
        <p class="hero-kicker">More time for what matters</p>
        <h2>Less Work. More Living.</h2>
        <p class="hero-description">Discover practical laundry and cleaning appliances that help simplify your daily household tasks.</p>
        <div class="hero-actions">
          <a class="hero-button hero-button-primary" href="<?= e(url('products.php?cat=cleaning')) ?>">Explore Cleaning Appliances</a>
          <a class="hero-button hero-button-secondary" href="<?= e(url('products.php')) ?>">Shop Now</a>
        </div>
      </div>
      <div class="hero-visual">
        <img src="<?= e(url('assets/images/hero/laundry-room.jpg')) ?>" alt="Bright laundry room with a front-loading washing machine" loading="lazy">
      </div>
    </article>
    <article class="hero-slide" role="group" aria-roledescription="slide" aria-label="4 of 4" aria-hidden="true" inert>
      <div class="hero-copy">
        <p class="hero-kicker">Your home, connected</p>
        <h2>Comfort, Technology and Convenience</h2>
        <p class="hero-description">Find electronics and household essentials that make your home more enjoyable and comfortable.</p>
        <div class="hero-actions">
          <a class="hero-button hero-button-primary" href="<?= e(url('categories.php')) ?>">Discover More</a>
          <a class="hero-button hero-button-secondary" href="<?= e(url('products.php')) ?>">Browse Products</a>
        </div>
      </div>
      <div class="hero-visual">
        <img src="<?= e(url('assets/images/hero/smart-living-room.jpg')) ?>" alt="Elegant modern living room with contemporary furnishings and home technology" loading="lazy">
      </div>
    </article>
  </div>
  <div class="hero-controls" aria-label="Featured collection controls">
    <div class="hero-indicators" role="group" aria-label="Choose a featured collection">
      <button class="hero-indicator is-active" type="button" aria-label="Show slide 1: Everything Your Home Needs" aria-current="true"></button>
      <button class="hero-indicator" type="button" aria-label="Show slide 2: Make Every Kitchen Moment Better" aria-current="false"></button>
      <button class="hero-indicator" type="button" aria-label="Show slide 3: Less Work. More Living." aria-current="false"></button>
      <button class="hero-indicator" type="button" aria-label="Show slide 4: Comfort, Technology and Convenience" aria-current="false"></button>
    </div>
    <div class="hero-arrows">
      <button class="hero-arrow" type="button" data-hero-prev aria-label="Previous featured collection">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg>
      </button>
      <button class="hero-arrow" type="button" data-hero-next aria-label="Next featured collection">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>
      </button>
    </div>
  </div>
</section>
<section>
  <h2>Shop by main category</h2>
  <div class="cat-grid">
    <?php foreach ($mainCats as $c): ?>
      <a class="cat" href="<?= e(url('products.php?cat=' . $c['slug'])) ?>">
        <span class="ico"><?= e($c['icon']) ?></span>
        <b><?= e($c['name']) ?></b>
        <small><?= (int)$c['n'] ?> products</small>
      </a>
    <?php endforeach; ?>
  </div>
</section>



<section class="perks" aria-label="Why shop with us">
  <div><b><svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M9 16.17l-1.41-1.41L5 14.17l6 6 14-14 1.41 1.41L9 19l-7-7z"/></svg> Genuine &amp; warranted</b><span>12 to 24 months on every appliance</span></div>
  <div><b><svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M21 10V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14l7-3.73 7 3.73V10c0-1.1.9-2 2-2z"/></svg> Fast delivery</b><span>1 to 2 days within Kampala</span></div>
  <div><b><svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1c0 1.1.9 2 2 2s2-.9 2-2v-1c0-1.1.9-2 2-2v-1c0-1.1.9-2 2-2v-6.54l.21.79c.13.58.21 1.17.21 1.79 0 4.08-3.05 7.44-7 7.93z"/></svg> Pay your way</b><span>MTN, Airtel, card or cash on delivery</span></div>
  <div><b><svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-1px;"><path d="M5 5h14v12H5zm0-2h14c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H5c-1.1 0-2-.9-2-2V5c0-1.1.9-2 2-2zm0 14l4-4 4 4H5z"/></svg> 7-day returns</b><span>If it arrives faulty, we fix it</span></div>
</section>

<section>
  <h2>Shop by category</h2>
  <div class="cat-grid">
    <?php foreach ($catCounts as $c): $categoryMedia = category_media($c); ?>
      <a class="cat" href="<?= e(url('products.php?cat=' . $c['slug'])) ?>">
        <?php if ($categoryMedia !== ''): ?>
          <?= $categoryMedia ?>
        <?php else: ?>
          <span class="ico"><?= e($c['icon']) ?></span>
        <?php endif; ?>
        <b><?= e($c['name']) ?></b>
        <small><?= (int)$c['n'] ?> products</small>
      </a>
    <?php endforeach; ?>
  </div>
</section>

<section>
  <div class="section-head"><h2>Popular picks</h2><a href="<?= e(url('products.php')) ?>">View all →</a></div>
  <div class="grid"><?php foreach ($featured as $p) product_card($p); ?></div>
</section>

<?php if ($deals): ?>
<section>
  <div class="section-head"><h2>Best deals</h2></div>
  <div class="grid"><?php foreach ($deals as $p) product_card($p); ?></div>
</section>
<?php endif; ?>

<section class="featured-products-section" aria-labelledby="featured-products-heading">
  <div class="featured-heading">
    <span class="featured-accent" aria-hidden="true"></span>
    <div>
      <h2 id="featured-products-heading">Featured Products</h2>
      <p>Discover our handpicked home essentials for everyday comfort.</p>
    </div>
  </div>
  <?php if ($featuredProducts): ?>
    <div class="grid featured-products-grid">
      <?php foreach ($featuredProducts as $p) product_card($p, true); ?>
    </div>
  <?php else: ?>
    <div class="empty featured-empty">
      <p>We’re refreshing our featured selection. Explore all our home appliances in the meantime.</p>
      <a class="btn small" href="<?= e(url('products.php')) ?>">Browse all products</a>
    </div>
  <?php endif; ?>
</section>

<section class="promo">
  <div>
    <h2>Student? Save 10% today.</h2>
    <p>Enter <strong>STUDENT10</strong> in your cart. Our Student Starter Bundle covers a whole hostel kitchen for one low price.</p>
  </div>
  <a class="btn" href="<?= e(url('product.php?slug=student-starter-bundle')) ?>">See the bundle</a>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
