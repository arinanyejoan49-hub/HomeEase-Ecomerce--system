<?php
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require __DIR__ . '/../includes/bootstrap.php';

$name = trim($argv[1] ?? '');
$email = strtolower(trim($argv[2] ?? ''));
if ($name === '' || mb_strlen($name) > 80 || !filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 160) {
    fwrite(STDERR, "Usage: php tools/create-admin.php \"Administrator name\" admin@example.com\n");
    exit(1);
}
if (!table_exists('admins')) {
    fwrite(STDERR, "The admins table is missing. Import sql/schema.sql into the selected database first.\n");
    exit(1);
}
if (q('SELECT 1 FROM admins WHERE email = ?', [$email])->fetchColumn()) {
    fwrite(STDERR, "An administrator with that email already exists; no account was changed.\n");
    exit(1);
}

fwrite(STDOUT, "Administrator password (12+ characters, upper/lowercase and a number): ");
$password = rtrim((string)fgets(STDIN), "\r\n");
fwrite(STDOUT, "Confirm password: ");
$confirmation = rtrim((string)fgets(STDIN), "\r\n");
if (
    strlen($password) < 12
    || !preg_match('/[A-Z]/', $password)
    || !preg_match('/[a-z]/', $password)
    || !preg_match('/[0-9]/', $password)
    || !hash_equals($password, $confirmation)
) {
    fwrite(STDERR, "Password confirmation failed or the password does not meet the requirements.\n");
    exit(1);
}

q(
    'INSERT INTO admins (name, email, password_hash) VALUES (?, ?, ?)',
    [$name, $email, password_hash($password, PASSWORD_DEFAULT)]
);
fwrite(STDOUT, "Administrator account created. Sign in at the shared HomeEase login page.\n");
